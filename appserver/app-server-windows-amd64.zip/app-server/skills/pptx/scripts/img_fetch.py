"""
img_fetch — 官网图片采集（Browser Python API 驱动）。

在 ``python_cell_exec`` 中调用 :func:`collect`，一次完成开页、滚动采集、下载、
校验去重和入库：

    import os, sys
    sys.path.insert(0, os.path.join(os.getenv("SKILL_PATH"), "pptx", "scripts"))
    import img_fetch
    print(await img_fetch.collect(url="https://example.com", ppt_dir="<ppt-dir>"))

补抓明确 URL 时调用 ``await img_fetch.download(...)``；产物与去重口径和
collect 完全一致。
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import io
import json
import os
import re
import sys
import threading
import time
import warnings
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlparse

# 硬丢弃线：剔除不适合幻灯片使用的图标和缩略图
_MIN_WIDTH = 800
_MIN_SHORT_EDGE = 400

_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)
_MAX_BYTES = 20 * 1024 * 1024
_HTTP_TIMEOUT = (5, 20)          # (连接, 单次读取)
_DOWNLOAD_DEADLINE_S = 45        # 单张图整体上限，防慢速服务器逐块拖死
# 并发数对齐浏览器同域并发。注意并发不增加带宽只摊分带宽：窄带链路上它省的是
# 每张图的握手与 TTFB，不是传输时间，所以单张超时不能压太紧，否则大图必被误杀
_WORKERS = 6

# 每步滚动 0.9 屏。scrollTo 是瞬间跳转，IntersectionObserver 只看跳转后的相交状态、
# 不看路径，所以只要相邻两次视口区间首尾相接就不会漏内容；1.0 恰好无缝，取 0.9 留一成重叠。
_STEP_RATIO = 0.9

# 自适应等待：跳转后每 _POLL_MS 检查一次 DOM 是否还在变，稳定即进入下一步，
# 上限 _MAX_WAIT_MS（退化后就是从前的固定等待）。注意只看 DOM 结构、不等字节下载完——
# 我们要的是 URL，字节由 Python 侧自己下，等下载完反而更慢。
_POLL_MS = 50
_MAX_WAIT_MS = 500

# 边滚边采：每滚 _BURST_STEPS 步采集一次 DOM 与新增 Resource Timing 记录，
# 连续 _STALL_ROUNDS 段没采到新 URL 就停。判据就是产出本身（候选集合是否还在变大）。
_BURST_STEPS = 10
_BURST_MS = 12000  # 单段 JS 上限；execute_script 受 run_coroutine_threadsafe(timeout=60) 约束
_MAX_BURSTS = 15
_STALL_ROUNDS = 2
_SCROLL_BUDGET_S = 45

# collect() 全流程预算。超出即停并如实汇报剩余量，可再次调用继续
# （同 ppt_dir 自动续编号 + 跨次去重，重跑是安全的）
_TOTAL_BUDGET_S = 150

_MAX_DOWNLOAD = 24
_INPAGE_BATCH = 8
_DHASH_THRESHOLD = 5
_COLOR_MAE_THRESHOLD = 12

_JUNK_RE = re.compile(
    r"(logo|icon|sprite|favicon|qrcode|qr[-_]code|avatar|placeholder|"
    r"watermark|loading|blank|spacer|pixel|1x1)",
    re.I,
)
_SKIP_EXT_RE = re.compile(r"\.(svg|ico)(\?|#|$)", re.I)
_THUMB_PARAM_RE = re.compile(r"(resize[,_/]?w[_,=](\d{1,3})\b)|([?&](w|width)=(\d{1,3})\b)", re.I)
_SENTINEL_RE = re.compile(r"__IMGF_BEGIN__(.*?)__IMGF_END__", re.S)

_SOURCE_PRIORITY = {
    "img/srcset": 0,
    "img": 1,
    "background": 1,
    "preload": 2,
    "meta": 2,
    "img/lazy": 3,
    "poster": 3,
    "jsonld": 4,
    # Resource Timing 没有元素尺寸和语义上下文，只作为 DOM 采集的兜底来源。
    "performance": 4,
}


class ImgFetchError(RuntimeError):
    """采集流程中断（页面打不开、浏览器不可用等）。"""


class _Budget:
    """全流程时间预算。到点即停，已完成的部分照常入库并如实汇报剩余量。"""

    def __init__(self, seconds: float):
        self.total = seconds
        self.deadline = time.time() + seconds
        self.started = time.time()

    def left(self) -> float:
        return max(0.0, self.deadline - time.time())

    def expired(self) -> bool:
        return time.time() >= self.deadline

    def elapsed(self) -> float:
        return time.time() - self.started


# ═══════════════════════════════════════════════════════════════════════════════
# 浏览器层：JS payload
# ═══════════════════════════════════════════════════════════════════════════════

# 工具函数必须挂 globalThis：多次 evaluate 共用全局作用域，顶层 const 二次声明会抛错
_JS_PRELUDE = r"""
globalThis.__abs = function (u) { try { return new URL(u, location.href).href; } catch (e) { return ""; } };
// Resource Timing 默认缓冲区较小。状态挂在页面全局，跨多次 evaluate 增量读取，
// 避免每个滚动分段重复序列化、回传已经处理过的历史请求。
globalThis.__imgfPerfSeen = globalThis.__imgfPerfSeen || new Set();
globalThis.__imgfPerfCursor = Number.isFinite(globalThis.__imgfPerfCursor)
  ? globalThis.__imgfPerfCursor : 0;
try { performance.setResourceTimingBufferSize(5000); } catch (e) {}
globalThis.__scrollRoot = function () {
  const de = document.scrollingElement || document.documentElement;
  if (de.scrollHeight > de.clientHeight + 200) return de;
  const els = document.querySelectorAll('body *');
  let best = null, bestArea = 0;
  for (let i = 0; i < els.length && i < 4000; i++) {
    const el = els[i];
    if (el.scrollHeight <= el.clientHeight + 200) continue;
    const r = el.getBoundingClientRect();
    const area = r.width * r.height;
    if (area > bestArea) { bestArea = area; best = el; }
  }
  return best || de;
};
"""

_JS_PROBE = _JS_PRELUDE + r"""
(() => {
  const root = __scrollRoot();
  const isDoc = root === (document.scrollingElement || document.documentElement);
  const view = isDoc ? window.innerHeight : root.clientHeight;
  return "__IMGF_BEGIN__" + JSON.stringify({
    url: location.href,
    title: document.title || "",
    ready: document.readyState,
    scrollHeight: root.scrollHeight,
    viewHeight: view,
    scrollable: root.scrollHeight > view + 200,
    innerScroller: !isDoc,
    imgCount: document.images ? document.images.length : 0,
    carousel: document.querySelectorAll(
      '[class*="swiper"],[class*="carousel"],[class*="slider"],[class*="banner"]'
    ).length,
  }) + "__IMGF_END__";
})()
"""

_JS_SCROLL = _JS_PRELUDE + r"""
(async () => {
  const root = __scrollRoot();
  const isDoc = root === (document.scrollingElement || document.documentElement);
  const view = isDoc ? window.innerHeight : root.clientHeight;
  const deadline = Date.now() + __MAX_MS__;
  document.querySelectorAll('img[loading="lazy"]').forEach((i) => {
    try { i.loading = 'eager'; } catch (e) {}
  });
  // 「有 src 的图片数」不能省：最常见的懒加载是给已存在的 <img> 换 src，节点数不动
  const domSignature = () => {
    const imgs = document.images;
    let withSrc = 0;
    for (let i = 0; i < imgs.length; i++) {
      if (imgs[i].currentSrc || imgs[i].src) withSrc++;
    }
    return imgs.length + '|' + withSrc + '|' + root.scrollHeight;
  };

  let y = __START_Y__, steps = 0, grew = 0, waitedTotal = 0;
  let h = root.scrollHeight, done = false;
  while (steps < __MAX_STEPS__ && Date.now() < deadline) {
    y = Math.min(y + Math.max(200, Math.floor(view * __STEP_RATIO__)), root.scrollHeight);
    if (isDoc) window.scrollTo(0, y); else root.scrollTop = y;
    window.dispatchEvent(new Event('scroll'));
    window.dispatchEvent(new Event('resize'));

    let waited = 0, stable = 0, prev = domSignature();
    while (waited < __MAX_WAIT_MS__) {
      await new Promise((r) => setTimeout(r, __POLL_MS__));
      waited += __POLL_MS__;
      const sig = domSignature();
      if (sig === prev) { if (++stable >= 2) break; }
      else { stable = 0; prev = sig; }
    }
    waitedTotal += waited;

    steps++;
    const nh = root.scrollHeight;
    if (nh > h + 50) { grew++; h = nh; }
    if (y >= h - view - 5) { done = true; break; }
  }
  return "__IMGF_BEGIN__" + JSON.stringify({
    done: done, nextY: y, steps: steps, grew: grew,
    scrollHeight: h, imgCount: document.images ? document.images.length : 0,
    avgWaitMs: steps ? Math.round(waitedTotal / steps) : 0,
  }) + "__IMGF_END__";
})()
"""

_JS_COLLECT = _JS_PRELUDE + r"""
(() => {
  const out = [];
  const seen = new Set();
  const push = (u, w, h, src, alt, ctx) => {
    const abs = __abs(u);
    if (!abs || abs.slice(0, 5) === 'blob:') return false;
    if (abs.slice(0, 5) === 'data:' && abs.length < 6000) return false;
    const key = abs.slice(0, 2000);
    if (seen.has(key)) return false;
    seen.add(key);
    out.push({
      url: abs, w: w || 0, h: h || 0, src: src,
      alt: (alt || '').slice(0, 80), ctx: ctx || '',
    });
    return true;
  };
  // 在一组 srcset 内挑分辨率最高的一档。
  // 密度描述符（2x/3x）本身不含宽度，必须用"元素显示宽度 × 密度"折算成真实宽度估算；
  // 早先把 2x 直接当成宽度 2000，那个虚构值会在后续排序里碾压真实测量值。
  const pickSrcset = (ss, baseWidth) => {
    let best = null;
    (ss || '').split(',').forEach((part) => {
      const t = part.trim().split(/\s+/);
      if (!t[0]) return;
      let w = 0;
      const d = t[1] || '';
      if (/^\d+w$/.test(d)) w = parseInt(d, 10);
      else if (/^[\d.]+x$/.test(d)) w = Math.round((baseWidth || 0) * parseFloat(d));
      else w = Math.round(baseWidth || 0);  // 无描述符即 1x
      if (!best || w > best.w) best = { u: t[0], w: w };
    });
    return best;
  };

  // 复刻浏览器对 <picture> 的选择规则：自上而下取第一个 media 成立的 <source>。
  // 不能把各组混在一起比大小——不同断点的 "2x" 互不可比，混比的结果是永远选中
  // 排在最前的那组，而移动优先的写法里最前面恰恰是最小的图。
  const matchedSource = (pic) => {
    const sources = pic.querySelectorAll('source[srcset]');
    for (let i = 0; i < sources.length; i++) {
      const media = sources[i].getAttribute('media');
      if (!media) return sources[i];  // 无 media 视为恒成立
      try {
        if (window.matchMedia(media).matches) return sources[i];
      } catch (e) { /* 非法 media 跳过 */ }
    }
    return sources.length ? sources[sources.length - 1] : null;
  };
  const ctxOf = (el) => {
    let n = el, text = '';
    for (let i = 0; i < 4 && n; i++, n = n.parentElement) {
      const hd = n.querySelector && n.querySelector('h1,h2,h3,h4');
      if (hd && hd.innerText) { text = hd.innerText.trim(); if (text) break; }
    }
    return text.replace(/\s+/g, ' ').slice(0, 60);
  };

  // 1) <img>：srcset 取生效那组的最高档，另收 currentSrc/src 与 data-* 懒加载属性
  document.querySelectorAll('img').forEach((im) => {
    const ctx = ctxOf(im);
    const alt = im.getAttribute('alt') || '';
    const nw = im.naturalWidth || 0, nh = im.naturalHeight || 0;
    // 显示宽度用于把密度描述符折算成真实宽度；隐藏的轮播帧没有布局（rect=0），
    // 退回已加载文件的真实像素宽
    const baseWidth = Math.round(im.getBoundingClientRect().width) || nw || 0;
    let picked = null;
    const pic = im.closest('picture');
    if (pic) {
      const src = matchedSource(pic);
      if (src) picked = pickSrcset(src.getAttribute('srcset'), baseWidth);
    }
    const own = pickSrcset(im.getAttribute('srcset'), baseWidth);
    if (own && (!picked || own.w > picked.w)) picked = own;
    if (picked) push(picked.u, picked.w, 0, 'img/srcset', alt, ctx);
    if (im.currentSrc) push(im.currentSrc, nw, nh, 'img', alt, ctx);
    else if (im.src) push(im.src, nw, nh, 'img', alt, ctx);
    ['data-src', 'data-original', 'data-lazy-src', 'data-echo', 'data-url', 'data-image'].forEach((a) => {
      const v = im.getAttribute(a);
      if (v) push(v, 0, 0, 'img/lazy', alt, ctx);
    });
  });

  // 2) CSS 背景图：官网首屏大 KV 常是背景而非 <img>，只扫 img 必漏
  const els = document.querySelectorAll('body *');
  for (let i = 0; i < els.length && i < 6000; i++) {
    const el = els[i];
    const r = el.getBoundingClientRect();
    if (r.width < 200 || r.height < 150) continue;
    let bg = '';
    try { bg = getComputedStyle(el).backgroundImage || ''; } catch (e) { continue; }
    if (!bg || bg === 'none') continue;
    (bg.match(/url\((['"]?)(.*?)\1\)/g) || []).forEach((raw) => {
      const u = raw.replace(/^url\((['"]?)/, '').replace(/(['"]?)\)$/, '');
      push(u, Math.round(r.width), Math.round(r.height), 'background', '', ctxOf(el));
    });
  }

  // 3) video poster / og:image / preload / JSON-LD
  document.querySelectorAll('video[poster]').forEach((v) => {
    push(v.getAttribute('poster'), 0, 0, 'poster', '', ctxOf(v));
  });
  document.querySelectorAll(
    'meta[property="og:image"],meta[name="og:image"],meta[name="twitter:image"]'
  ).forEach((m) => push(m.getAttribute('content'), 0, 0, 'meta', '', ''));
  document.querySelectorAll('link[rel="preload"][as="image"]').forEach((l) => {
    // preload 没有对应的渲染元素，拿不到显示宽度：只认 w 描述符，密度档记为未知
    const ss = pickSrcset(l.getAttribute('imagesrcset'), 0);
    if (ss) push(ss.u, ss.w, 0, 'preload', '', '');
    if (l.getAttribute('href')) push(l.getAttribute('href'), 0, 0, 'preload', '', '');
  });
  document.querySelectorAll('script[type="application/ld+json"]').forEach((s) => {
    let data;
    try { data = JSON.parse(s.textContent); } catch (e) { return; }
    const walk = (o, depth) => {
      if (!o || depth > 6 || typeof o !== 'object') return;
      if (Array.isArray(o)) { o.forEach((v) => walk(v, depth + 1)); return; }
      Object.keys(o).forEach((k) => {
        const v = o[k];
        if (/^(image|thumbnailUrl|contentUrl)$/i.test(k)) {
          (Array.isArray(v) ? v : [v]).forEach((x) => {
            const u = typeof x === 'string' ? x : (x && x.url);
            if (u) push(u, 0, 0, 'jsonld', '', '');
          });
        } else walk(v, depth + 1);
      });
    };
    walk(data, 0);
  });

  // 4) Resource Timing：补齐 Shadow DOM、伪元素、Canvas/JS 动态渲染等
  // DOM 查询看不到、但浏览器实际请求过的图片。同 URL 已由上面的 DOM 采集命中时，
  // push() 会直接去重，因此不会形成第二条下载任务。
  let perfScanned = 0, perfAdded = 0;
  try {
    const entries = performance.getEntriesByType('resource') || [];
    let start = Number(globalThis.__imgfPerfCursor) || 0;
    // 页面若主动 clearResourceTimings()，长度会回退；从头读但仍由全局 URL 集合去重。
    if (start > entries.length) start = 0;
    perfScanned = Math.max(0, entries.length - start);
    for (let i = start; i < entries.length; i++) {
      const e = entries[i];
      const u = e && e.name ? String(e.name) : '';
      if (!u || globalThis.__imgfPerfSeen.has(u)) continue;
      const kind = String(e.initiatorType || '').toLowerCase();
      // img 可覆盖无扩展名图片；扩展名分支覆盖 CSS 背景及 JS 动态请求。
      // 不把所有 fetch/xhr 都送去下载，否则 JS、JSON、字体会挤占 max_download。
      const imageLike = kind === 'img' || kind === 'image' ||
        /\.(?:avif|bmp|gif|jpe?g|png|tiff?|webp)(?:$|[?@#])/i.test(u);
      if (!imageLike) continue;
      globalThis.__imgfPerfSeen.add(u);
      if (push(u, 0, 0, 'performance', '', '')) perfAdded++;
    }
    globalThis.__imgfPerfCursor = entries.length;
  } catch (e) { /* 个别受限页面没有 Resource Timing；保留 DOM 结果 */ }

  // 5) 站内链接：供模型判断是否还有更深的产品详情页没进
  const links = [];
  const lseen = new Set();
  document.querySelectorAll('a[href]').forEach((a) => {
    const href = __abs(a.getAttribute('href'));
    if (!href || !/^https?:/.test(href)) return;
    if (href.split('#')[0] === location.href.split('#')[0]) return;
    try { if (new URL(href).hostname !== location.hostname) return; } catch (e) { return; }
    if (lseen.has(href) || lseen.size >= 60) return;
    lseen.add(href);
    links.push({
      url: href,
      text: (a.innerText || a.getAttribute('title') || '').trim().replace(/\s+/g, ' ').slice(0, 40),
    });
  });

  let cookie = '';
  try { cookie = document.cookie || ''; } catch (e) {}  // 部分上下文读 cookie 会抛 SecurityError

  return "__IMGF_BEGIN__" + JSON.stringify({
    page: location.href, title: document.title || '',
    cookie: cookie, images: out, links: links,
    performance: { scanned: perfScanned, added: perfAdded },
  }) + "__IMGF_END__";
})()
"""

# 直连被 CDN 防盗链拒绝时的兜底：在页面上下文里 fetch，天然带 cookie 与 referer
_JS_INPAGE_FETCH = r"""
(async () => {
  const urls = __URLS__;
  const out = [];
  const deadline = Date.now() + 25000;
  for (const u of urls) {
    if (Date.now() > deadline) { out.push({ url: u, err: 'timeout' }); continue; }
    try {
      // 别加 credentials:'include'：CDN 普遍返回 ACAO:*，带凭证的跨域请求会被整个拒收；
      // 默认 same-origin 已能让同源图片带上 cookie，两头都对
      const r = await fetch(u);
      if (!r.ok) { out.push({ url: u, err: 'HTTP ' + r.status }); continue; }
      const b = await r.blob();
      if (b.size > 4194304) { out.push({ url: u, err: 'too large' }); continue; }
      const b64 = await new Promise((res, rej) => {
        const fr = new FileReader();
        fr.onload = () => res(String(fr.result));
        fr.onerror = () => rej(new Error('read fail'));
        fr.readAsDataURL(b);
      });
      out.push({ url: u, data: b64 });
    } catch (e) { out.push({ url: u, err: String(e).slice(0, 80) }); }
  }
  return "__IMGF_BEGIN__" + JSON.stringify(out) + "__IMGF_END__";
})()
"""


# ═══════════════════════════════════════════════════════════════════════════════
# 浏览器层：调用
# ═══════════════════════════════════════════════════════════════════════════════

def _load_browser_api():
    """加载 Browser skill 的异步 Python API。"""
    skill_path = os.getenv("SKILL_PATH")
    if not skill_path:
        raise ImgFetchError("环境变量 SKILL_PATH 缺失，无法加载 browser skill")
    scripts = str(Path(skill_path) / "browser" / "scripts")
    if scripts not in sys.path:
        sys.path.insert(0, scripts)
    try:
        import api as browser_api
    except ImportError as e:
        raise ImgFetchError(
            f"加载 Browser Python API 失败：{e}；请在 python_cell_exec 中调用"
        ) from e
    return browser_api


async def _eval_json(browser_api, target_id: str, script: str) -> Any:
    response = await browser_api.execute_script(script, target_id=target_id)
    raw = response.get("result") or ""
    m = _SENTINEL_RE.search(raw)
    if not m:
        raise ImgFetchError(f"页面脚本执行失败：{raw[:400]}")
    return json.loads(m.group(1))


async def _open_page(
    browser_api, url: str, budget: "_Budget | None" = None
) -> tuple[dict, str]:
    """新建页面并量一次形态；后续操作固定使用返回的 targetId。"""
    try:
        nav = await browser_api.navigate(
            url,
            with_snapshot=False,
            with_screenshot=False,
        )
    except Exception as e:
        raise ImgFetchError(f"打开页面失败：{type(e).__name__}: {e}") from e
    target_id = nav.get("targetId") or ""
    if not target_id:
        raise ImgFetchError("打开页面失败：Browser API 未返回 targetId")

    probe = await _eval_json(browser_api, target_id, _JS_PROBE)
    href = probe.get("url", "")
    if href.startswith("chrome-error") or href.startswith("about:"):
        raise ImgFetchError(f"页面未能打开（{href}）：请确认 URL 是否正确或稍后重试")
    # 重营销的官网首屏常在 load 之后才由 JS 注入内容，此时快照只有壳
    if probe.get("ready") != "complete" or probe.get("imgCount", 0) == 0:
        if budget is None or budget.left() > 3:
            await asyncio.sleep(3)
            probe = await _eval_json(browser_api, target_id, _JS_PROBE)
    return probe, target_id


def _hint_area(cand: dict) -> int:
    """候选的面积估算。只有宽度时按 16:9 折算高度。
    """
    w, h = int(cand.get("w") or 0), int(cand.get("h") or 0)
    if w and h:
        return w * h
    return round(w * w * 9 / 16) if w else 0


def _merge_harvest(images: dict, links: dict, harvest: dict) -> None:
    """把一次采集并入累积结果；同一 URL 保留尺寸信息更充分的那条。"""
    for cand in harvest.get("images", []):
        url = cand.get("url")
        if not url:
            continue
        old = images.get(url)
        if old is None or _hint_area(cand) > _hint_area(old):
            images[url] = cand
    for link in harvest.get("links", []):
        url = link.get("url")
        if url and url not in links:
            links[url] = link


async def _scroll_and_collect(
    browser_api, target_id: str, probe: dict, budget: "_Budget | None" = None
) -> tuple[dict, dict]:
    """边滚边采：每滚一段采集一次并取并集，连续若干段没有新 URL 就停。"""
    harvest = await _eval_json(browser_api, target_id, _JS_COLLECT)
    images: dict[str, dict] = {}
    links: dict[str, dict] = {}
    _merge_harvest(images, links, harvest)

    stat = {
        "segments": 0,
        "steps": 0,
        "grew": 0,
        "done": True,
        "stalled": False,
        "scrollHeight": probe.get("scrollHeight", 0),
        "before": len(images),
        "avg_wait_ms": 0,
        "performance_scanned": int(harvest.get("performance", {}).get("scanned", 0)),
        "performance_added": int(harvest.get("performance", {}).get("added", 0)),
    }

    def finish() -> tuple[dict, dict]:
        harvest["images"] = list(images.values())
        harvest["links"] = list(links.values())
        return harvest, stat

    if not probe.get("scrollable"):
        return finish()

    started = time.time()
    y, stall = 0, 0
    waits: list[int] = []
    for _ in range(_MAX_BURSTS):
        js = (
            _JS_SCROLL.replace("__MAX_MS__", str(_BURST_MS))
            .replace("__MAX_STEPS__", str(_BURST_STEPS))
            .replace("__START_Y__", str(int(y)))
            .replace("__STEP_RATIO__", str(_STEP_RATIO))
            .replace("__MAX_WAIT_MS__", str(_MAX_WAIT_MS))
            .replace("__POLL_MS__", str(_POLL_MS))
        )
        r = await _eval_json(browser_api, target_id, js)
        stat["segments"] += 1
        stat["steps"] += int(r.get("steps", 0))
        stat["grew"] += int(r.get("grew", 0))
        stat["scrollHeight"] = int(r.get("scrollHeight", stat["scrollHeight"]))
        stat["done"] = bool(r.get("done"))
        waits.append(int(r.get("avgWaitMs", 0)))

        before = len(images)
        harvest = await _eval_json(browser_api, target_id, _JS_COLLECT)
        _merge_harvest(images, links, harvest)
        perf = harvest.get("performance", {})
        stat["performance_scanned"] += int(perf.get("scanned", 0))
        stat["performance_added"] += int(perf.get("added", 0))
        stall = stall + 1 if len(images) == before else 0

        if stat["done"]:
            break
        # 连续 _STALL_ROUNDS 段无新增才停：中段夹一大块纯文字时不至于误判
        if stall >= _STALL_ROUNDS:
            stat["stalled"] = True
            break
        if time.time() - started > _SCROLL_BUDGET_S:
            break
        # 给下载阶段留出至少一半总预算，滚动不许把时间吃光
        if budget is not None and budget.left() < budget.total * 0.5:
            break
        y = int(r.get("nextY", y))

    stat["avg_wait_ms"] = round(sum(waits) / len(waits)) if waits else 0
    return finish()


# ═══════════════════════════════════════════════════════════════════════════════
# 候选筛选与排序
# ═══════════════════════════════════════════════════════════════════════════════

def _url_path(url: str) -> str:
    try:
        return unquote(urlparse(url).path)
    except ValueError:
        return url


def _is_junk(url: str, w: int, h: int) -> str:
    """返回丢弃原因，空串表示保留。"""
    if url.startswith("data:"):
        return ""
    if _SKIP_EXT_RE.search(url):
        return "矢量图/图标"
    path = _url_path(url)
    if _JUNK_RE.search(path):
        return "命名疑似图标/装饰"
    if _THUMB_PARAM_RE.search(url):
        return "CDN 缩略参数"
    if w and h and (w < 200 or h < 150):
        return "渲染尺寸过小"
    return ""


def _rank_candidates(images: list[dict]) -> tuple[list[dict], dict[str, int]]:
    kept: list[dict] = []
    dropped: dict[str, int] = {}
    for c in images:
        url = c.get("url", "")
        if not url:
            continue
        reason = _is_junk(url, int(c.get("w") or 0), int(c.get("h") or 0))
        if reason:
            dropped[reason] = dropped.get(reason, 0) + 1
            continue
        kept.append(c)

    kept.sort(key=lambda c: (-_hint_area(c), _SOURCE_PRIORITY.get(c.get("src", ""), 5)))
    return kept, dropped


def _rank_links(links: list[dict], keyword: str | None) -> list[dict]:
    """挑出像产品/详情页的站内链接，供模型决定是否再抓一层。"""
    hint = re.compile(
        r"(product|detail|models?|series|spec|gallery|news|press|media|车型|产品|详情)", re.I
    )
    kw = (keyword or "").strip().lower()
    scored = []
    for l in links:
        url, text = l.get("url", ""), l.get("text", "")
        score = 0
        if kw and (kw in url.lower() or kw in text.lower()):
            score += 3
        if hint.search(_url_path(url)) or hint.search(text):
            score += 1
        if score:
            scored.append((score, l))
    scored.sort(key=lambda x: -x[0])
    return [l for _, l in scored[:8]]


# ═══════════════════════════════════════════════════════════════════════════════
# 下载与校验
# ═══════════════════════════════════════════════════════════════════════════════

def _decode_data_uri(url: str) -> bytes:
    head, _, payload = url.partition(",")
    if ";base64" in head:
        return base64.b64decode(payload)
    return unquote(payload).encode("utf-8", "ignore")


_local = threading.local()


def _session():
    """每线程一个 Session：并发下载时复用连接，省掉重复 TLS 握手。"""
    sess = getattr(_local, "session", None)
    if sess is None:
        import requests

        sess = requests.Session()
        _local.session = sess
    return sess


def _http_get(url: str, referer: str, cookie: str = "") -> tuple[bytes, str]:
    headers = {
        "User-Agent": _UA,
        "Referer": referer,
        "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Sec-Fetch-Dest": "image",
        "Sec-Fetch-Mode": "no-cors",
        "Sec-Fetch-Site": "cross-site",
    }
    if cookie:
        headers["Cookie"] = cookie
    try:
        resp = _session().get(
            url, headers=headers, timeout=_HTTP_TIMEOUT, allow_redirects=True, stream=True
        )
    except Exception as e:  # 网络层异常统一转成失败原因
        return b"", f"请求失败：{type(e).__name__}"
    deadline = time.time() + _DOWNLOAD_DEADLINE_S
    try:
        with resp:
            if resp.status_code != 200:
                return b"", f"HTTP {resp.status_code}"
            ctype = (resp.headers.get("Content-Type") or "").lower()
            if ctype and not ctype.startswith("image/") and "octet-stream" not in ctype:
                return b"", f"非图片响应（{ctype.split(';')[0]}）"
            buf = bytearray()
            # 流式读取也会抛（中途 ReadTimeout / 断连），try 收窄会让一张图带走整轮成果
            for chunk in resp.iter_content(65536):
                if time.time() > deadline:  # 单次读取超时管不住"每块都及时、但整体极慢"
                    return b"", f"下载超时（超过 {_DOWNLOAD_DEADLINE_S}s）"
                buf.extend(chunk)
                if len(buf) > _MAX_BYTES:
                    return b"", "文件超过 20MB"
    except Exception as e:
        return b"", f"读取中断：{type(e).__name__}"
    return bytes(buf), ""


# 带 cookie 重试只对鉴权类拒绝有意义；超时/连不上再来一次纯属浪费预算
_AUTH_FAIL_RE = re.compile(r"HTTP (401|403)")


def _fetch_one(url: str, referer: str, cookie: str) -> tuple[bytes, str]:
    if url.startswith("data:"):
        try:
            return _decode_data_uri(url), ""
        except Exception:
            return b"", "data URI 解码失败"
    data, err = _http_get(url, referer)
    if data:
        return data, ""
    if cookie and _AUTH_FAIL_RE.search(err):
        data, err2 = _http_get(url, referer, cookie)
        if data:
            return data, ""
        err = err2 or err
    return b"", err


async def _fetch_in_page(
    browser_api,
    target_id: str,
    urls: list[str],
    budget: "_Budget | None" = None,
) -> tuple[dict[str, bytes], dict[str, str]]:
    """直连失败后的兜底，返回（取回的字节, 各 URL 的失败原因）。

    失败原因带回去写进报告。
    """
    out: dict[str, bytes] = {}
    errors: dict[str, str] = {}
    for i in range(0, len(urls), _INPAGE_BATCH):
        if budget is not None and budget.left() < 10:
            for url in urls[i:]:
                errors.setdefault(url, "时间预算不足，未执行")
            break
        batch = urls[i : i + _INPAGE_BATCH]
        js = _JS_INPAGE_FETCH.replace("__URLS__", json.dumps(batch))
        try:
            rows = await _eval_json(browser_api, target_id, js)
        except Exception as e:
            for url in batch:
                errors.setdefault(url, f"页内脚本执行失败：{type(e).__name__}")
            continue
        for row in rows:
            url = row.get("url", "")
            data_uri = row.get("data")
            if not data_uri:
                errors[url] = str(row.get("err") or "未知错误")[:80]
                continue
            try:
                out[url] = _decode_data_uri(data_uri)
            except Exception:
                errors[url] = "base64 解码失败"
    return out, errors


@contextmanager
def _quiet_pil():
    """屏蔽 PIL 的调色板/透明度告警，避免污染返回给模型的报告。"""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        yield


def _open_image(data: bytes):
    from PIL import Image

    Image.open(io.BytesIO(data)).verify()  # verify 会消费流，之后必须重新打开
    return Image.open(io.BytesIO(data))


def _signature(im) -> dict:
    """近似重复判定用的指纹：dHash + 8×8 颜色缩略 + 宽高比。

    只用 dHash 会误伤白底产品图这类低细节图——纯色/近纯色图的 dHash 几乎全 0，
    彼此汉明距离为 0，会把不同产品判成同一张。故补两道：颜色签名区分"同构不同色"，
    宽高比区分"构图相近但版式不同"；dHash 熵过低时直接放弃近似判定，只认 md5。
    """
    from PIL import Image

    g = im.convert("L").resize((9, 8), Image.LANCZOS)
    px = list(g.getdata())
    bits = 0
    for row in range(8):
        base = row * 9
        for col in range(8):
            bits = (bits << 1) | (1 if px[base + col] > px[base + col + 1] else 0)
    thumb = im.convert("RGB").resize((8, 8), Image.LANCZOS).tobytes()
    w, h = im.size
    return {
        "dhash": str(bits),
        "sig": base64.b64encode(thumb).decode("ascii"),
        "ar": round(w / h, 4) if h else 0.0,
    }


def _near_dup(a: dict, b: dict) -> bool:
    try:
        ha, hb = int(a["dhash"]), int(b["dhash"])
        ar_a, ar_b = float(a.get("ar") or 0), float(b.get("ar") or 0)
    except (KeyError, TypeError, ValueError):
        return False
    # dHash 位差过小说明图像本身近乎无纹理，此时判定不可信
    ones = bin(ha).count("1")
    if ones < 8 or ones > 56:
        return False
    if bin(ha ^ hb).count("1") > _DHASH_THRESHOLD:
        return False
    if ar_a and ar_b and abs(ar_a - ar_b) / max(ar_a, ar_b) > 0.05:
        return False
    try:
        pa = base64.b64decode(a["sig"])
        pb = base64.b64decode(b["sig"])
    except (KeyError, TypeError, ValueError):
        return True
    if len(pa) != len(pb) or not pa:
        return True
    mae = sum(abs(x - y) for x, y in zip(pa, pb)) / len(pa)
    return mae <= _COLOR_MAE_THRESHOLD


def _persist(im, data: bytes, dest_dir: Path, stem: str) -> tuple[Path, str]:
    """JPEG/PNG 原样落盘；webp/avif 等转码，避免后续 HTML→PPTX 环节不认。"""
    fmt = (im.format or "").upper()
    if fmt == "JPEG":
        path = dest_dir / f"{stem}.jpg"
        path.write_bytes(data)
        return path, "JPEG"
    if fmt == "PNG":
        path = dest_dir / f"{stem}.png"
        path.write_bytes(data)
        return path, "PNG"
    has_alpha = im.mode in ("RGBA", "LA") or (im.mode == "P" and "transparency" in im.info)
    if has_alpha:
        path = dest_dir / f"{stem}.png"
        im.convert("RGBA").save(path, "PNG")
        return path, f"{fmt}→PNG"
    path = dest_dir / f"{stem}.jpg"
    im.convert("RGB").save(path, "JPEG", quality=92)
    return path, f"{fmt}→JPEG"


# ═══════════════════════════════════════════════════════════════════════════════
# 记录（仅内部账本；面向模型的素材清单由 pptx skill 自行决定格式并撰写）
# ═══════════════════════════════════════════════════════════════════════════════

def _record_paths(ppt_dir: Path) -> tuple[Path, Path]:
    return ppt_dir / "assets", ppt_dir / "official_assets.json"


def _load_records(json_path: Path) -> list[dict]:
    if not json_path.exists():
        return []
    try:
        return json.loads(json_path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []


def _next_index(records: list[dict], assets_dir: Path, prefix: str) -> int:
    used = {int(r["id"].rsplit("_", 1)[-1]) for r in records if r.get("id", "").startswith(prefix)}
    for p in assets_dir.glob(f"{prefix}_*"):
        m = re.search(rf"{re.escape(prefix)}_(\d+)", p.stem)
        if m:
            used.add(int(m.group(1)))
    return max(used) + 1 if used else 1


# 账本只留溯源信息与精确去重所需的 md5。
_PERSISTED_FIELDS = ("id", "url", "page", "w", "h", "alt", "ctx", "md5")


def _write_records(records: list[dict], json_path: Path) -> None:
    """只写内部账本：跨次去重与编号续接依赖它，模型不读。

    素材清单（official_assets.md）由 pptx skill 按自己的格式撰写，脚本不生成，
    避免脚本与提示词各持一份格式、改一处漏一处。
    """
    slim = [{k: r[k] for k in _PERSISTED_FIELDS if k in r} for r in records]
    json_path.write_text(json.dumps(slim, ensure_ascii=False, indent=2), encoding="utf-8")


def _load_disk_signatures(assets_dir: Path, prefix: str) -> list[dict]:
    """从已入库的图片重算感知指纹，替代把指纹存进账本。"""
    sigs: list[dict] = []
    for path in sorted(assets_dir.glob(f"{prefix}_*")):
        if path.suffix.lower() not in (".jpg", ".jpeg", ".png"):
            continue
        try:
            with _quiet_pil():
                sigs.append(_signature(_open_image(path.read_bytes())))
        except Exception:
            continue  # 坏文件不该阻断本轮采集
    return sigs


# ═══════════════════════════════════════════════════════════════════════════════
# 主流程
# ═══════════════════════════════════════════════════════════════════════════════

async def _ingest(
    candidates: list[dict],
    referer: str,
    ppt_dir: Path,
    prefix: str,
    min_width: int,
    browser_api=None,
    target_id: str = "",
    page_cookie: str = "",
    budget: "_Budget | None" = None,
) -> tuple[list[dict], list[str], dict[str, int], int]:
    """下载 → 校验 → 去重 → 落盘，返回（新增记录, 失败明细, 丢弃统计, 因超预算跳过数）。"""
    assets_dir, json_path = _record_paths(ppt_dir)
    assets_dir.mkdir(parents=True, exist_ok=True)

    records = _load_records(json_path)
    known_md5 = {r["md5"] for r in records if r.get("md5")}
    known_sigs = _load_disk_signatures(assets_dir, prefix)
    index = _next_index(records, assets_dir, prefix)

    added: list[dict] = []
    failures: list[str] = []
    dropped: dict[str, int] = {}
    retry_urls: list[str] = []
    pending: dict[str, dict] = {}
    direct_errors: dict[str, str] = {}

    def bump(reason: str) -> None:
        dropped[reason] = dropped.get(reason, 0) + 1

    def consume(cand: dict, data: bytes) -> None:
        nonlocal index
        url = cand["url"]
        md5 = hashlib.md5(data).hexdigest()
        if md5 in known_md5:
            bump("内容重复")
            return
        try:
            im = _open_image(data)
        except Exception:
            failures.append(f"{_short(url)} → 非有效图片")
            return
        w, h = im.size
        if w < min_width or min(w, h) < _MIN_SHORT_EDGE:
            bump(f"尺寸不足（{w}×{h}）")
            return
        with _quiet_pil():
            sig = _signature(im)
        if any(_near_dup(sig, k) for k in known_sigs):
            bump("与已入库图近似重复")
            return
        stem = f"{prefix}_{index:02d}"
        try:
            with _quiet_pil():
                path, fmt_note = _persist(im, data, assets_dir, stem)
        except Exception as e:
            failures.append(f"{_short(url)} → 保存失败（{type(e).__name__}）")
            return
        known_md5.add(md5)
        known_sigs.append(sig)
        added.append(
            {
                "id": stem,
                "file": str(path),
                "w": w,
                "h": h,
                "format": fmt_note,
                "url": url,
                "page": referer,
                "alt": cand.get("alt", ""),
                "ctx": cand.get("ctx", ""),
                "md5": md5,
            }
        )
        index += 1

    # 下载并发、校验落盘串行：后者串行是为了编号与去重结果可复现
    skipped = 0

    def fetch_task(cand: dict) -> tuple[dict, bytes, str]:
        # 兜底：worker 里任何未预料的异常都不得逃逸到线程池，否则整轮成果作废
        try:
            data, err = _fetch_one(cand["url"], referer, page_cookie)
        except Exception as e:
            return cand, b"", f"异常：{type(e).__name__}"
        return cand, data, err

    # 不用 with：上下文退出会 wait=True 等所有任务跑完，预算就只挡得住入库、
    # 挡不住下载。这里显式 shutdown(cancel_futures=True)，未启动的直接取消，
    # 已在跑的最多再持续单张上限的时间。
    pool = ThreadPoolExecutor(max_workers=_WORKERS)
    futures = [pool.submit(fetch_task, c) for c in candidates]
    try:
        for fut in futures:
            left = budget.left() if budget is not None else None
            if left is not None and left <= 0:
                skipped += 1
                continue
            try:
                wrapped = asyncio.wrap_future(fut)
                if left is None:
                    cand, data, err = await wrapped
                else:
                    cand, data, err = await asyncio.wait_for(wrapped, timeout=left)
            except TimeoutError:
                skipped += 1
                continue
            url = cand["url"]
            if data:
                consume(cand, data)
            elif browser_api is not None and target_id and not url.startswith("data:"):
                retry_urls.append(url)
                pending[url] = cand
                direct_errors[url] = err  # 兜底若也失败，报告要能说出直连当初败在哪
            else:
                failures.append(f"{_short(url)} → {err}")
    finally:
        pool.shutdown(wait=False, cancel_futures=True)

    if retry_urls and (budget is None or budget.left() > 10):
        recovered, inpage_errors = await _fetch_in_page(
            browser_api, target_id, retry_urls, budget
        )
        for url in retry_urls:
            data = recovered.get(url)
            if data:
                consume(pending[url], data)
            else:
                failures.append(
                    f"{_short(url)} → 直连：{direct_errors.get(url) or '未知'}"
                    f"；页内 fetch：{inpage_errors.get(url) or '未知'}"
                )
    elif retry_urls:
        failures.extend(
            f"{_short(u)} → 直连：{direct_errors.get(u) or '未知'}（时间预算不足，未做页内兜底）"
            for u in retry_urls
        )

    records.extend(added)
    _write_records(records, json_path)
    return added, failures, dropped, skipped


def _short(url: str, limit: int = 72) -> str:
    return url if len(url) <= limit else url[: limit - 3] + "..."


async def collect(
    url: str,
    ppt_dir: str,
    prefix: str = "official",
    keyword: str | None = None,
    min_width: int = _MIN_WIDTH,
    max_download: int = _MAX_DOWNLOAD,
    budget_seconds: float = _TOTAL_BUDGET_S,
) -> str:
    """通过 Browser Python API 采集单个页面图片并入库。"""
    budget = _Budget(budget_seconds)
    # 官网图片采集固定使用 IAB；清空插件模式，避免 extension 路由优先抢占。
    os.environ["BROWSER_PLUGIN_MODE"] = ""
    browser_api = _load_browser_api()
    ppt_path = Path(ppt_dir)
    ppt_path.mkdir(parents=True, exist_ok=True)

    timing: dict[str, float] = {}
    t = time.time()
    probe, target_id = await _open_page(browser_api, url, budget)
    timing["打开页面"] = time.time() - t

    t = time.time()
    harvest, scroll = await _scroll_and_collect(
        browser_api, target_id, probe, budget
    )
    timing["滚动采集"] = time.time() - t

    candidates, pre_dropped = _rank_candidates(harvest.get("images", []))
    queued = candidates[:max_download]
    deferred = candidates[max_download:]

    t = time.time()
    added, failures, dropped, skipped = await _ingest(
        queued,
        referer=harvest.get("page", url),
        ppt_dir=ppt_path,
        prefix=prefix,
        min_width=min_width,
        browser_api=browser_api,
        target_id=target_id,
        page_cookie=harvest.get("cookie", ""),
        budget=budget,
    )
    timing["下载入库"] = time.time() - t
    for k, v in pre_dropped.items():
        dropped[k] = dropped.get(k, 0) + v

    suggested = _rank_links(harvest.get("links", []), keyword)
    return _report(
        probe, scroll, harvest, candidates, queued, deferred,
        added, failures, dropped, suggested, ppt_path, timing, budget, skipped,
    )


def _report(
    probe: dict,
    scroll: dict,
    harvest: dict,
    candidates: list[dict],
    queued: list[dict],
    deferred: list[dict],
    added: list[dict],
    failures: list[str],
    dropped: dict[str, int],
    suggested: list[dict],
    ppt_path: Path,
    timing: dict[str, float],
    budget: "_Budget | None",
    skipped: int,
) -> str:
    out: list[str] = []
    out.append(f"[页面] {harvest.get('title') or probe.get('title')} — {harvest.get('page')}")
    view = int(probe.get("viewHeight") or 0)
    if probe.get("scrollable"):
        shape = "长滚动页" + ("（内层滚动容器）" if probe.get("innerScroller") else "")
        span = max(1, int(view * _STEP_RATIO))
        # 总屏数按最终高度反算；页面回收 DOM 会让高度变小，故不得小于实际已滚屏数
        total_steps = max(1, -(-(scroll["scrollHeight"] - view) // span), scroll["steps"])
        if scroll.get("stalled"):
            why = f"，连续 {_STALL_ROUNDS} 段未采到新图，提前停止"
        elif scroll["done"]:
            why = "，已到底"
        else:
            why = "，未滚到底（超出预算）"
        out.append(
            f"[形态] {shape}：内容高 {scroll['scrollHeight']}px / 视口 {view}px，"
            f"已滚 {scroll['steps']}/{total_steps} 屏{why}"
            + (f"，滚动中内容增长 {scroll['grew']} 次" if scroll["grew"] else "")
        )
    else:
        out.append(f"[形态] 单屏页：内容高 {scroll['scrollHeight']}px / 视口 {view}px，无需滚动")
    if probe.get("carousel"):
        out.append(f"[轮播] 检测到 {probe['carousel']} 个轮播/横幅容器，非当前帧的图片已一并采集")

    harvested = len(harvest.get("images", []))
    perf_note = ""
    if scroll.get("performance_added"):
        perf_note = f"，其中 Performance API 补充 {scroll['performance_added']}"
    out.append(
        f"[采集] 候选 URL：滚动前 {scroll.get('before', 0)} → 最终 {harvested}"
        + perf_note
        + (f"，平均每步等待 {scroll['avg_wait_ms']}ms" if scroll.get("avg_wait_ms") else "")
    )

    drop_txt = "，".join(f"{k} {v}" for k, v in sorted(dropped.items(), key=lambda x: -x[1])) or "无"
    out.append(
        f"[候选] 过滤后 {len(candidates)} → 本次下载 {len(queued)}（丢弃：{drop_txt}）"
    )
    out.append(f"[入库] 新增 {len(added)} 张，失败 {len(failures)} 张 → {ppt_path / 'assets'}")
    if timing:
        out.append("[耗时] " + "，".join(f"{k} {v:.1f}s" for k, v in timing.items()))
    if skipped:
        out.append(
            f"[预算] 已达 {budget.total:.0f}s 时间预算，还有 {skipped} 张未处理。"
            f"如需继续，对同一 URL 再调用一次 collect（自动续编号并跳过已入库的图）。"
        )

    if added:
        out.append("")
        # 文件名必须给全：素材清单由模型据此自行撰写
        out.append("| 图片 ID | 文件名 | 尺寸 | 格式 | 来源上下文 |")
        out.append("|---|---|---|---|---|")
        for r in added:
            out.append(
                f"| {r['id']} | {Path(r['file']).name} | {r['w']}×{r['h']} | "
                f"{r['format']} | {(r['ctx'] or r['alt'] or '—')} |"
            )
    else:
        out.append("本次没有图片入库。")

    if failures:
        out.append("")
        out.append("下载失败：")
        out.extend(f"  - {f}" for f in failures[:10])
        if len(failures) > 10:
            out.append(f"  - …另有 {len(failures) - 10} 条")

    if deferred:
        out.append("")
        out.append(f"未入库候选（超出本次下载上限，可指名补抓，共 {len(deferred)} 条，列前 15）：")
        for c in deferred[:15]:
            hint = f" {c['w']}×{c['h']}" if c.get("w") and c.get("h") else ""
            out.append(f"  - {_short(c['url'])}{hint}")

    if suggested:
        out.append("")
        out.append("疑似更深的产品/详情页（若本页图片不足，可对其再跑一次 collect）：")
        for l in suggested:
            out.append(f"  - {l['text'] or '(无锚文本)'} → {l['url']}")
    return "\n".join(out)


async def download(
    urls: list[str],
    ppt_dir: str,
    referer: str = "",
    prefix: str = "official",
    min_width: int = _MIN_WIDTH,
) -> str:
    """按指定 URL 补抓（不经浏览器），用于把报告里"未入库候选"中的某张收进来。"""
    ppt_path = Path(ppt_dir)
    ppt_path.mkdir(parents=True, exist_ok=True)
    candidates = [{"url": u, "w": 0, "h": 0, "src": "manual", "alt": "", "ctx": ""} for u in urls]
    added, failures, dropped, _ = await _ingest(
        candidates, referer or (urls[0] if urls else ""), ppt_path, prefix, min_width
    )
    lines = [f"[入库] 新增 {len(added)} 张，失败 {len(failures)} 张 → {ppt_path / 'assets'}"]
    for r in added:
        lines.append(f"  {r['id']}  {r['w']}×{r['h']}  {r['format']}")
    if dropped:
        lines.append("丢弃：" + "，".join(f"{k} {v}" for k, v in dropped.items()))
    lines.extend(f"  失败：{f}" for f in failures)
    return "\n".join(lines)
