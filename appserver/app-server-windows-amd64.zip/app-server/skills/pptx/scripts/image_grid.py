"""
Image Grid — 图片等比压缩 + 自适应网格拼接。

将传入的图片等比压缩（不裁剪，保持原始宽高比），
按自适应网格排列拼接为一张大图。

网格布局规则（3×3 为上限）：
  图片数 | 布局
  -------|------
    1    | 1×1
    2    | 1×2
    3    | 1×3
    4    | 2×2
    5~6  | 2×3
    7~9  | 3×3

用法：
    pptx_cli.py image-grid <images...> -o <output> [--gap G] [--background-color COLOR]
"""

from __future__ import annotations

import math
from pathlib import Path
from typing import Any

from PIL import Image

# 画布总尺寸（1920×1080 = 1280×720 的 1.5 倍）
_GRID_WIDTH = 1920
_GRID_HEIGHT = 1080
_MAX_IMAGES = 9


def _optimal_grid(n: int) -> tuple[int, int]:
    """根据图片数量 n 计算最优行列数（3×3 为上限）。"""
    if n <= 0:
        return 1, 1
    if n <= 3:
        return 1, n  # 1~3 张单行排列
    # 4~9 张：寻找最接近方形的布局
    cols = math.ceil(math.sqrt(n))
    rows = math.ceil(n / cols)
    return rows, cols


def make_image_grid(
    image_paths: list[str],
    output_path: str,
    gap: int = 10,
    background_color: str = "#FFFFFF",
) -> dict[str, Any]:
    """
    将图片等比压缩后拼接为自适应网格。

    参数：
        image_paths      - 图片路径列表（最多 9 张，不足时从左上角开始排列，空位留白）
        output_path      - 输出图片保存路径（扩展名决定格式，推荐 .png）
        gap              - 单元格间距（像素，默认 10）
        background_color - 背景色 HEX（默认 #FFFFFF）

    返回：
        成功: {"success": True, "path": "...", "size_kb": ..., "rows": ..., "cols": ...}
        失败: {"error": "..."}
    """
    if not image_paths:
        return {"error": "未传入图片路径"}

    if len(image_paths) > _MAX_IMAGES:
        return {"error": f"最多支持 {_MAX_IMAGES} 张图片，传入 {len(image_paths)} 张"}

    # 解析背景色
    bg_color = background_color.lstrip("#")
    try:
        bg_rgb = tuple(int(bg_color[i : i + 2], 16) for i in (0, 2, 4))
    except (ValueError, IndexError):
        return {"error": f"无效的背景色: {background_color}"}

    n = len(image_paths)
    rows, cols = _optimal_grid(n)

    # 计算单元格尺寸（gap 只出现在单元格之间）
    # 水平：gap | cell | gap | cell | gap | ... | gap
    # 垂直：gap | cell | gap | cell | gap | ... | gap
    cell_w = (_GRID_WIDTH - (cols + 1) * gap) // cols
    cell_h = (_GRID_HEIGHT - (rows + 1) * gap) // rows
    if cell_w <= 0 or cell_h <= 0:
        return {"error": f"gap 过大，无法容纳单元格（cell_w={cell_w}, cell_h={cell_h}）"}

    # 创建画布
    canvas = Image.new("RGB", (_GRID_WIDTH, _GRID_HEIGHT), bg_rgb)

    for i, img_path in enumerate(image_paths):
        row, col = divmod(i, cols)

        # 打开图片，统一转为 RGBA 以便合成
        try:
            img = Image.open(img_path)
        except Exception as e:
            return {"error": f"无法打开图片 {img_path}: {e}"}

        # 转为 RGBA 确保后续合成正确处理透明通道
        if img.mode != "RGBA":
            img = img.convert("RGBA")

        # 等比缩放（不裁剪，保持原始宽高比，适配到 cell_w × cell_h 内）
        img.thumbnail((cell_w, cell_h), Image.LANCZOS)

        # 计算居中粘贴位置：外缘 gap + 列/行偏移 + 单元格内居中偏移
        x = gap + col * (cell_w + gap) + (cell_w - img.width) // 2
        y = gap + row * (cell_h + gap) + (cell_h - img.height) // 2

        # 合成：RGBA 图层铺到 RGB 画布上，透明部分透出背景色
        paste_layer = Image.new("RGBA", img.size, bg_rgb + (255,))
        paste_layer.alpha_composite(img)
        canvas.paste(paste_layer, (x, y), paste_layer)

    # 保存
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(out, quality=95)
    size_kb = round(out.stat().st_size / 1024, 1)

    return {
        "success": True,
        "path": str(out),
        "size_kb": size_kb,
        "rows": rows,
        "cols": cols,
    }