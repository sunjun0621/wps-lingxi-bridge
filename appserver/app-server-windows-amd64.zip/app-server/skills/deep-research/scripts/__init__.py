"""
Deep Research Skill - 深度研究工具集（双图版 / DualGraph）

使用方式：
    import sys
    sys.path.insert(0, "cooffice/skills/deep-research/scripts")

本 Skill 为纯 Agent 行为指令驱动，无独立脚本逻辑。
"""
