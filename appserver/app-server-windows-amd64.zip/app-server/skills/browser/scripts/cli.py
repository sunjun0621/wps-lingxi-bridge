#!/usr/bin/env python3
"""Browser skill CLI — 通过 bash 调用现有 browser.py API。"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

_SCRIPTS_DIR = Path(__file__).resolve().parent
if str(_SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS_DIR))

import browser  # noqa: E402


def _is_failure(result: str) -> bool:
    if not isinstance(result, str):
        return True
    # 只看首行：stdout 含完整快照（含 Page Text），正文里的「失败：」「超时」
    # 不能改退出码。与 browser._make_error_message 对齐：
    #   "{action} 失败：\n..."
    #   "{action} 超时"
    first = result.split("\n", 1)[0]
    if first.endswith(" 超时") or first.endswith(" 失败"):
        return True
    if " 失败：" in first:
        return True
    # 「未执行（unsupported）」是正常未执行结果（旧版插件契约不符），
    # 与 browser._make_error_message 的 ProviderTargetContractError
    # 分支对齐，退出码保持 0。
    if first.endswith(" 未执行（unsupported）："):
        return False
    return False


def _print_result(result: str) -> int:
    text = result if isinstance(result, str) else str(result)
    print(text)
    return 1 if _is_failure(text) else 0


def _parse_files(values: list[str] | None) -> list[str]:
    if not values:
        return []
    files: list[str] = []
    for item in values:
        for part in item.split(","):
            part = part.strip()
            if part:
                files.append(part)
    return files


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="browser",
        description="Browser skill CLI（包装 browser.py 公开 API）",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("tabs_list", help="列出 Provider 页面 Target")

    p_tabs_close = sub.add_parser("tabs_close", help="关闭一个或多个页面 Target")
    p_tabs_close.add_argument("--target-id", action="append", required=True)

    p_tabs_activate = sub.add_parser(
        "tabs_activate", help="将页面 Target 切换到前台"
    )
    p_tabs_activate.add_argument("--target-id", required=True)

    p_tabs_mark = sub.add_parser("tabs_mark", help="标记页面生命周期")
    p_tabs_mark.add_argument("--target-id", required=True)
    p_tabs_mark.add_argument(
        "--disposition", choices=("deliverable", "handoff"), required=True
    )

    p_nav = sub.add_parser("navigate", help="打开页面")
    p_nav.add_argument("--url", required=True)
    p_nav.add_argument("--target-id")

    p_click = sub.add_parser("click", help="点击元素")
    p_click.add_argument("--target-id")
    p_click.add_argument("--element-index", type=int, required=True)

    p_fill = sub.add_parser("fill", help="填写输入框")
    p_fill.add_argument("--target-id")
    p_fill.add_argument("--element-index", type=int, required=True)
    p_fill.add_argument("--text", required=True)
    p_fill.add_argument("--press-enter", action="store_true")

    p_upload = sub.add_parser("upload_files", help="上传本地文件到页面控件")
    p_upload.add_argument("--target-id")
    p_upload.add_argument("--element-index", type=int, required=True)
    p_upload.add_argument(
        "--files",
        action="append",
        required=True,
        help="文件路径，可重复；也支持逗号分隔",
    )

    p_select = sub.add_parser("select_option", help="下拉框选择")
    p_select.add_argument("--target-id")
    p_select.add_argument("--element-index", type=int, required=True)
    p_select.add_argument("--option-text")
    p_select.add_argument("--option-value")
    p_select.add_argument("--option-index", type=int)

    p_elements = sub.add_parser(
        "get_interactive_elements", help="刷新可交互元素列表"
    )
    p_elements.add_argument("--target-id")

    p_script = sub.add_parser("execute_script", help="执行 JS")
    p_script.add_argument("--target-id")
    p_script.add_argument("--script", required=True)

    p_shot = sub.add_parser("screenshot", help="截图")
    p_shot.add_argument("--target-id")
    p_shot.add_argument("--output", default="screenshot.jpg")
    p_shot.add_argument("--full-page", action="store_true")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        if args.command == "tabs_list":
            return _print_result(browser.tabs_list())
        if args.command == "tabs_close":
            return _print_result(browser.tabs_close(args.target_id))
        if args.command == "tabs_activate":
            return _print_result(browser.tabs_activate(args.target_id))
        if args.command == "tabs_mark":
            return _print_result(
                browser.tabs_mark(args.target_id, args.disposition)
            )
        if args.command == "navigate":
            return _print_result(browser.navigate(args.url, target_id=args.target_id))
        if args.command == "click":
            return _print_result(
                browser.click(args.element_index, target_id=args.target_id)
            )
        if args.command == "fill":
            return _print_result(
                browser.fill(
                    args.element_index,
                    args.text,
                    press_enter=args.press_enter,
                    target_id=args.target_id,
                )
            )
        if args.command == "upload_files":
            return _print_result(
                browser.upload_files(
                    args.element_index,
                    _parse_files(args.files),
                    target_id=args.target_id,
                )
            )
        if args.command == "select_option":
            specified = sum(
                1
                for v in (args.option_text, args.option_value, args.option_index)
                if v is not None
            )
            if specified != 1:
                print(
                    "select_option 失败：\n必须且只能指定 --option-text / --option-value / --option-index 之一",
                    file=sys.stderr,
                )
                return 1
            return _print_result(
                browser.select_option(
                    args.element_index,
                    option_text=args.option_text,
                    option_value=args.option_value,
                    option_index=args.option_index,
                    target_id=args.target_id,
                )
            )
        if args.command == "get_interactive_elements":
            return _print_result(
                browser.get_interactive_elements(target_id=args.target_id)
            )
        if args.command == "execute_script":
            return _print_result(
                browser.execute_script(args.script, target_id=args.target_id)
            )
        if args.command == "screenshot":
            return _print_result(
                browser.screenshot(
                    output=args.output,
                    full_page=args.full_page,
                    target_id=args.target_id,
                )
            )
    except Exception as e:
        print(f"{args.command} 失败：\n{e}", file=sys.stderr)
        return 1

    parser.error(f"未知命令: {args.command}")
    return 2


if __name__ == "__main__":
    sys.exit(main())
