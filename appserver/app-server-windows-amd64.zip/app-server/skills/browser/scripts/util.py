import asyncio
import logging
import os
import platform
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path
from typing import Any, Coroutine
import re

import core
from cdp_http import BrowserConnectionError, HTTPCDPClient, SessionEndedError, USER_STOP_HINT
from extensions.snapshot import SnapshotExtension


logger = logging.getLogger(__name__)

_LOCAL_CDP_HOST = "127.0.0.1"
_LOCAL_CDP_PORT = 9222
_LOCAL_CDP_ENDPOINT = f"http://{_LOCAL_CDP_HOST}:{_LOCAL_CDP_PORT}"
_LOCAL_CHROMIUM_READY_TIMEOUT = 45.0


def _log(msg: str) -> None:
    """统一日志，写到 stderr 被 sandbox Go 侧捕获"""
    ts = time.strftime("%H:%M:%S", time.localtime())
    sys.stderr.write(f"[BRWS-INIT] {ts} {msg}\n")
    sys.stderr.flush()


_loop: asyncio.AbstractEventLoop | None = None
_browser: core.Browser | None = None
_browser_mode: str | None = None  # "extension" / "in_app" / "cdp" / None
_last_route: str | None = None  # 上次选路标识，变化时清缓存

ASK_USER_STOP_HINT = USER_STOP_HINT

# Runtime contract probe result per route. A legacy plugin still answering
# with the plain CDP getTargets shape must keep the fallback workflow, so we
# verify the actual tabs_list payload once per route.
_tabs_contract_route: str | None = None
_tabs_contract_ok: bool = False


def extension_tabs_disabled() -> bool:
    return _current_route() == "extension" and (
        _tabs_contract_route == "extension" and not _tabs_contract_ok
    )


_GIT_BASH_ABS_RE = re.compile(r"^/([a-zA-Z])(?=/|$)")


def _normalize_user_output_path(
    raw: str,
    platform: str | None = None,
) -> tuple[str, str]:
    """Return the filesystem path and the path displayed to the user."""
    platform = os.name if platform is None else platform
    if platform != "nt":
        return raw, raw

    match = _GIT_BASH_ABS_RE.match(raw)
    if not match:
        return raw, raw

    drive = match.group(1).upper() + ":"
    tail = raw[2:].replace("/", "\\")
    return drive + (tail or "\\"), raw


def resolve_user_output_path(
    path: str | os.PathLike[str],
) -> tuple[Path, str]:
    """Resolve Git Bash-style Windows paths without exposing absolute paths."""
    raw = os.fspath(path)
    if not isinstance(raw, str):
        raise TypeError("截图输出路径必须是字符串路径")
    actual, display_path = _normalize_user_output_path(raw)
    return Path(actual), display_path


def _ensure_loop() -> None:
    """检测 _loop 是否存活，损坏时重建 loop 和后台线程，并重置 browser。"""
    global _loop, _browser
    if _loop is not None and not _loop.is_closed() and _loop.is_running():
        return
    _browser = None
    _loop = asyncio.new_event_loop()
    threading.Thread(target=_loop.run_forever, daemon=True).start()


def run_coroutine_threadsafe(coroutine: Coroutine, timeout: float = 60) -> Any:
    global _loop
    _ensure_loop()
    future = asyncio.run_coroutine_threadsafe(coroutine, _loop)
    return future.result(timeout)


def _parse_port(raw: str, name: str) -> int:
    try:
        port = int(raw)
    except ValueError as e:
        raise RuntimeError(f"{name} 不是合法端口: {raw!r}") from e
    if not (1 <= port <= 65535):
        raise RuntimeError(f"{name} 端口越界: {port}")
    return port


def _parse_browser_config(response: str) -> dict:
    """解析 __BRWS_REQ__ 响应，返回完整配置 dict"""
    return json.loads(response)


def _get_mode() -> str:
    """读取 browser.mode，由模型通过 browser.mode = "headless" 赋值。

    mode 只在设置它的那一轮有效：BROWSER_RUN_ID 跨轮变化时，若 mode 是
    上一轮设置的则重置为 extension（恢复插件）。
    """
    import browser as _browser_module

    mode = getattr(_browser_module, "mode", "extension")
    current_run = os.environ.get("BROWSER_RUN_ID", "")
    if current_run and mode != "extension":
        set_run = getattr(_browser_module, "_mode_set_run", "")
        if set_run and set_run != current_run:
            _browser_module.mode = "extension"
            mode = "extension"
    return mode


def _current_route() -> str:
    """返回当前选路标识，用于缓存失效判断。"""
    plugin_mode = os.environ.get("BROWSER_PLUGIN_MODE", "").strip()
    if plugin_mode == "extension":
        return "extension"
    in_app = os.environ.get("BROWSER_IN_APP_PORT", "").strip()
    if in_app:
        return f"in_app:{in_app}"
    browser_path = os.environ.get("BROWSER_EXECUTABLE_PATH", "").strip()
    if browser_path:
        return f"cdp:{browser_path}"
    return "unset"


def _probe_cdp(endpoint: str = _LOCAL_CDP_ENDPOINT, timeout: float = 1.5) -> bool:
    try:
        with urllib.request.urlopen(
            f"{endpoint}/json/version", timeout=timeout
        ) as resp:
            return resp.status == 200
    except Exception:
        return False


def _spoofed_chrome_ua() -> str:
    system = platform.system()
    if system == "Darwin":
        plat = "Macintosh; Intel Mac OS X 10_15_7"
    elif system == "Windows":
        plat = "Windows NT 10.0; Win64; x64"
    else:
        plat = "X11; Linux x86_64"
    return (
        f"Mozilla/5.0 ({plat}) AppleWebKit/537.36 (KHTML, like Gecko) "
        f"Chrome/146.0.0.0 Safari/537.36"
    )


def _local_chromium_args(exe: str) -> list[str]:
    disable_features = (
        "IsolateOrigins,site-per-process,NotificationTriggers,"
        "IdleDetection,AvoidUnnecessaryBeforeUnloadCheckSync,"
        "BoundaryEventDispatchTracksNodeRemoval,DestroyProfileOnBrowserClose,"
        "DialMediaRouteProvider,GlobalMediaControls,HttpsUpgrades,LensOverlay,"
        "MediaRouter,PaintHolding,ThirdPartyStoragePartitioning,Translate,"
        "AutoDeElevate,RenderDocument,OptimizationHints,AutomationControlled"
    )
    # 对齐 session.go localChromiumArgs，并固定 headless + 9222、无 user-data-dir
    return [
        "--remote-allow-origins=*",
        "--no-first-run",
        "--no-service-autorun",
        "--no-default-browser-check",
        "--homepage=about:blank",
        "--no-pings",
        "--password-store=basic",
        "--disable-infobars",
        "--disable-breakpad",
        "--disable-dev-shm-usage",
        "--disable-session-crashed-bubble",
        "--disable-search-engine-choice-screen",
        f"--disable-features={disable_features}",
        "--window-size=1280,800",
        "--disable-notifications",
        "--disable-field-trial-config",
        "--disable-background-networking",
        "--disable-background-timer-throttling",
        "--disable-backgrounding-occluded-windows",
        "--disable-back-forward-cache",
        "--disable-component-extensions-with-background-pages",
        "--disable-component-update",
        "--disable-default-apps",
        "--disable-extensions",
        "--allow-pre-commit-input",
        "--disable-hang-monitor",
        "--disable-ipc-flooding-protection",
        "--disable-popup-blocking",
        "--disable-prompt-on-repost",
        "--disable-renderer-backgrounding",
        "--force-color-profile=srgb",
        "--metrics-recording-only",
        "--use-mock-keychain",
        "--export-tagged-pdf",
        "--unsafely-disable-devtools-self-xss-warnings",
        "--edge-skip-compat-layer-relaunch",
        "--enable-automation",
        "--disable-sync",
        "--enable-unsafe-swiftshader",
        "--disable-trace-startup",
        "--disable-logging",
        "--no-sandbox",
        f"--remote-debugging-host={_LOCAL_CDP_HOST}",
        f"--remote-debugging-port={_LOCAL_CDP_PORT}",
        "--headless=new",
        f"--user-agent={_spoofed_chrome_ua()}",
    ]


def ensure_local_chromium_running(exe: str) -> str:
    """确保本地无头 Chromium 监听 127.0.0.1:9222；已可达则复用。"""
    if _probe_cdp():
        return _LOCAL_CDP_ENDPOINT

    if not exe or not Path(exe).exists():
        raise RuntimeError(f"BROWSER_EXECUTABLE_PATH 不可用: {exe!r}")

    args = _local_chromium_args(exe)
    subprocess.Popen(
        [exe, *args],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )

    deadline = time.monotonic() + _LOCAL_CHROMIUM_READY_TIMEOUT
    while time.monotonic() < deadline:
        if _probe_cdp():
            return _LOCAL_CDP_ENDPOINT
        time.sleep(0.2)
    raise RuntimeError(
        f"本地 Chromium 启动超时（{_LOCAL_CHROMIUM_READY_TIMEOUT:.0f}s），"
        f"未能在 {_LOCAL_CDP_ENDPOINT} 提供 CDP"
    )


async def _connect_http_cdp(
    session_id: str,
    port: int,
    mode_name: str,
    *,
    session_start: bool = False,
) -> core.Browser:
    def init_browser(browser: core.Browser) -> None:
        browser.register_extension("snapshot", SnapshotExtension)

    cdp_client = HTTPCDPClient(session_id=session_id, port=port)
    if session_start:
        # In-App 新实例：先 /cdp session_start，再发后续 CDP 命令
        brief = os.environ.get("BROWSER_BRIEF", "").strip()
        await cdp_client.session_start(brief)
    trial_browser = core.Browser(cdp_client)
    init_browser(trial_browser)
    try:
        healthy = await asyncio.wait_for(trial_browser.is_healthy(), timeout=5)
    except Exception as e:
        _log(f"get_browser: {mode_name} mode FAILED ({type(e).__name__}: {e})")
        if isinstance(e, SessionEndedError) or "session ended by plugin" in str(e):
            raise SessionEndedError(ASK_USER_STOP_HINT) from e
        raise BrowserConnectionError(
            f"{mode_name} 浏览器健康检查 Browser.getVersion 未通过。"
            f"原始错误: {type(e).__name__}: {e}"
        ) from e
    if not healthy:
        _log(f"get_browser: {mode_name} mode FAILED (health check returned False)")
        raise BrowserConnectionError(
            f"{mode_name} 浏览器健康检查 Browser.getVersion 未通过，未返回有效状态。"
        )
    return trial_browser


async def _ensure_page_target(browser: core.Browser) -> None:
    """跨 CLI 进程重连后恢复对已有 page 的附着。

    本地 CDP 需要 attachToTarget 才能发 Runtime/Page。
    内置浏览器则需要这次 attach 把 SESSION_ID 重新绑到已有 tab，
    否则跨轮次 fill/click 会报 no target tabId。
    """
    if getattr(browser, "_session_id", None):
        return
    attached = await browser.ensure_attached_to_page(
        load_url(), preferred_target_id=load_target_id()
    )
    if not attached:
        _log(
            "get_browser: CDP connected but no page target to attach; "
            "non-navigate ops will fail until navigate"
        )
        return
    persist_attached_page(browser)


async def get_browser(*, ensure_page_target: bool = True) -> core.Browser:
    def init_browser(browser: core.Browser) -> None:
        browser.register_extension("snapshot", SnapshotExtension)

    global _browser, _browser_mode, _last_route

    route = _current_route()
    if route != _last_route:
        _browser = None
        _browser_mode = None
        _last_route = route

    if _browser is not None:
        try:
            if await _browser.is_healthy():
                if ensure_page_target and _browser_mode in ("cdp", "in_app"):
                    await _ensure_page_target(_browser)
                return _browser
            # is_healthy 返回 False → 浏览器不可达，清缓存
            _browser = None
            _browser_mode = None
        except Exception as e:
            if isinstance(e, SessionEndedError) or "session ended by plugin" in str(e):
                _browser = None
                _browser_mode = None
                raise RuntimeError(ASK_USER_STOP_HINT) from e
            if _browser_mode in ("extension", "in_app"):
                _browser = None
                _browser_mode = None
                raise BrowserConnectionError(f"浏览器健康检查 Browser.getVersion 未通过: {e}") from e
            _log(
                f"get_browser: cached browser health check error ({type(e).__name__}: {e})"
            )
            _browser = None
            _browser_mode = None

    plugin_mode = os.environ.get("BROWSER_PLUGIN_MODE", "").strip()
    if plugin_mode == "extension":
        session_id = os.environ.get("SESSION_ID", "").strip()
        port_raw = os.environ.get("NATIVE_HOST_PORT", "").strip() or "38127"
        port = _parse_port(port_raw, "NATIVE_HOST_PORT")
        _browser = await _connect_http_cdp(session_id, port, "插件")
        _browser_mode = "extension"
        return _browser

    in_app_port = os.environ.get("BROWSER_IN_APP_PORT", "").strip()
    if in_app_port:
        session_id = os.environ.get("SESSION_ID", "").strip()
        port = _parse_port(in_app_port, "BROWSER_IN_APP_PORT")
        _browser = await _connect_http_cdp(
            session_id, port, "In-App", session_start=True
        )
        _browser_mode = "in_app"
        if ensure_page_target:
            await _ensure_page_target(_browser)
        return _browser

    browser_path = os.environ.get("BROWSER_EXECUTABLE_PATH", "").strip()
    if browser_path:
        endpoint = await asyncio.to_thread(ensure_local_chromium_running, browser_path)
        _browser = await core.Browser.create(endpoint)
        init_browser(_browser)
        _browser_mode = "cdp"
        if ensure_page_target:
            await _ensure_page_target(_browser)
        return _browser

    raise RuntimeError(
        "浏览器插件连接超时，native-host 可能未启动或已崩溃。请：\n"
        "1. 确认客户端（灵犀桌面端）正在运行\n"
        "2. 尝试关闭并重新打开浏览器插件开关\n"
        "3. 如无法解决，请关闭浏览器插件开关后重试"
    )


async def get_target_management_browser() -> core.Browser:
    """返回支持多标签扩展契约的 Provider Browser，且不自动 attach。

    旧版插件由真实调用自行报错（ProviderTargetContractError），不在入口
    拦截；探测结果只用于切换认证接管提示文案。
    """
    browser = await _get_target_management_browser_unchecked()
    await _ensure_tabs_contract_probed(browser)
    return browser


async def _get_target_management_browser_unchecked() -> core.Browser:
    route = _current_route()
    if route != "extension" and not route.startswith("in_app:"):
        raise RuntimeError(
            "当前浏览器连接不支持 tabs_list/tabs_close/tabs_activate/tabs_mark 多标签页命令"
        )
    return await get_browser(ensure_page_target=False)


async def _ensure_tabs_contract_probed(browser: core.Browser) -> None:
    """对插件路由做一次真实的 tabs_list 契约探测并缓存结果。

    旧版插件只返回普通 CDP getTargets 结构（targetInfos）而非 Provider
    targets 数组，get_provider_targets 会抛 ProviderTargetContractError；
    此时回退到「未执行（unsupported）」的兼容流程，避免把解析失败当作
    浏览器故障。In-App 宿主内建新契约，无需探测。
    """
    global _tabs_contract_route, _tabs_contract_ok
    route = _current_route()
    if route != "extension":
        return
    if _tabs_contract_route == route:
        return
    try:
        await browser.get_provider_targets()
        _tabs_contract_ok = True
    except core.ProviderTargetContractError:
        _tabs_contract_ok = False
        _log("get_target_management_browser: extension tabs contract probe FAILED")
    except Exception:
        # 连接/超时等临时错误不参与契约判定，交由原有错误路径处理
        raise
    _tabs_contract_route = route


def is_provider_browser_route() -> bool:
    """当前是否为 Extension/IAB Provider 路由。"""
    route = _current_route()
    return route == "extension" or route.startswith("in_app:")


async def _restore_last_url(browser: core.Browser) -> None:
    """从 url.txt 恢复上次 URL；无有效记录时跳过。"""
    url = load_url()
    if not url or url == "about:blank":
        return
    await browser.create_and_attach_target(url)
    await wait_dom_content_loaded(browser)


async def switch_to_new_tab_if_opened(
    browser: core.Browser,
    old_targets: list[dict[str, Any]],
    new_targets: list[dict[str, Any]],
) -> bool:
    old_target_ids = {}
    for target in old_targets:
        old_target_ids[target["targetId"]] = target
    for target in new_targets:
        if target["targetId"] not in old_target_ids:
            await browser.attach_to_target(target["targetId"])
            return True
    return False


async def _query_page_state(browser: core.Browser, script: str, timeout: float) -> Any:
    try:
        return await asyncio.wait_for(
            browser.evaluate(script, timeout=timeout, await_promise=False),
            timeout=timeout,
        )
    except TimeoutError as e:
        raise BrowserConnectionError(
            f"Runtime.evaluate 页面状态查询在 {timeout:.2f} 秒内未返回；底层操作可能仍在执行。"
        ) from e


async def wait_dom_content_loaded(browser: core.Browser) -> None:
    # Waiting for window.load inside an awaited Promise can hold the legacy
    # extension's command queue (including detach) long after HTTP times out.
    deadline = time.monotonic() + 15.0
    while (remaining := deadline - time.monotonic()) > 0:
        state = await _query_page_state(
            browser,
            "Object.defineProperty(navigator, 'webdriver', "
            "{ get: () => undefined, configurable: true }); document.readyState",
            timeout=min(2.0, remaining),
        )
        if state in ("interactive", "complete"):
            await wait_dom_stable(browser)
            return
        await asyncio.sleep(min(0.3, max(0.0, deadline - time.monotonic())))
    raise RuntimeError(
        "页面在 15 秒内仍未就绪，但浏览器通信正常。"
        f"TargetId: {browser.attached_target_id}。"
        "不要重复新建页面，可稍后对该 Target 刷新页面内容。"
    )


async def wait_dom_stable(
    browser: core.Browser,
    max_wait: float = 3.0,
    interval: float = 0.4,
    stable_rounds: int = 2,
) -> None:
    """等待 DOM 内容趋于稳定。

    `load` 事件只保证资源加载完成，但很多页面（如搜索结果）的正文是在 load
    之后才由 JS 异步注入的，此时抓快照只能拿到页面外壳。这里轮询页面内容规模
    （可见文本长度 + 可交互元素数），连续 `stable_rounds` 次不再变化即认为渲染
    完成；`max_wait` 秒兜底，避免长轮询/不断刷新的页面无限等待。
    """
    prev = -1
    stable = 0
    deadline = time.monotonic() + max_wait
    while (remaining := deadline - time.monotonic()) > 0:
        try:
            size = (
                await _query_page_state(
                    browser,
                    "(function(){"
                    "var t=document.body?document.body.innerText.length:0;"
                    "var n=document.querySelectorAll('a,button,input,select,textarea').length;"
                    "return t+n;})()",
                    timeout=min(1.0, remaining),
                )
                or 0
            )
        except (BrowserConnectionError, SessionEndedError):
            raise
        except Exception:
            return  # 导航中执行上下文失效等异常，停止等待，交由后续快照/重试兜底
        if size == prev:
            stable += 1
            if stable >= stable_rounds:
                return
        else:
            stable = 0
            prev = size
        await asyncio.sleep(min(interval, max(0.0, deadline - time.monotonic())))


class BrowserAutoSwitchTarget:
    def __init__(self, browser: core.Browser):
        self.browser = browser

    async def __aenter__(self):
        self.old_targets = await self.browser.get_targets()
        self.old_url = await self.browser.evaluate(
            "(function(){ return window.location.href; })()"
        )
        return self

    async def __aexit__(self, exc_type, exc, tb):
        await asyncio.sleep(0.2)
        new_targets = await self.browser.get_targets()
        if await switch_to_new_tab_if_opened(
            self.browser, self.old_targets, new_targets
        ):
            await asyncio.sleep(1)  # 等待新页面的 Runtime 初始化完成
            await wait_dom_content_loaded(self.browser)
        elif (
            await self.browser.evaluate(
                "(function(){ return window.location.href; })()"
            )
            != self.old_url
        ):
            # 同标签页内发生了导航（URL 变化），同样需等待加载完成，
            # 否则快照会在内容渲染前抓取，导致元素/文本为空。
            await wait_dom_content_loaded(self.browser)
        url = await self.browser.evaluate(
            "(function(){ return window.location.href; })()"
        )
        persist_attached_page(self.browser, url)
        return False


def _browser_state_dir() -> Path:
    workspace = Path(os.environ.get("WORKSPACE_DIR", "/tmp"))
    return (workspace / ".rundata" / "browser").resolve()


def _get_url_path() -> Path:
    return _browser_state_dir() / "url.txt"


def _get_target_id_path() -> Path:
    return _browser_state_dir() / "target_id.txt"


def save_url(url: str) -> None:
    path = _get_url_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(url, encoding="utf-8")
    except OSError as error:
        logger.warning(
            "Failed to persist browser URL state: %s",
            type(error).__name__,
        )


def load_url() -> str:
    try:
        return _get_url_path().read_text(encoding="utf-8").strip()
    except Exception:
        return "about:blank"


def save_target_id(target_id: str) -> None:
    value = str(target_id or "").strip()
    if not value:
        return
    path = _get_target_id_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(value, encoding="utf-8")
    except OSError as error:
        logger.warning(
            "Failed to persist browser target id: %s",
            type(error).__name__,
        )


def load_target_id() -> str:
    try:
        return _get_target_id_path().read_text(encoding="utf-8").strip()
    except Exception:
        return ""


def persist_attached_page(
    browser: core.Browser, url: str | None = None
) -> None:
    raw = getattr(browser, "_attached_target_id", "")
    if isinstance(raw, int):
        target_id = str(raw)
    elif isinstance(raw, str):
        target_id = raw.strip()
    else:
        target_id = ""
    if target_id:
        save_target_id(target_id)
    if url:
        save_url(url)
