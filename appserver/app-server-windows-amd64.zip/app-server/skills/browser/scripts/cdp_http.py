"""
HTTP CDP Client — 通过 native-host HTTP /cdp 接口转发 CDP 命令到 Chrome 插件。

与 cdp_use.client.CDPClient（WebSocket）接口兼容，Browser 类无感知切换。

用法：
    client = HTTPCDPClient(session_id="session-xxx")
    client = HTTPCDPClient(session_id="session-xxx", port=9223)  # in-app 等显式端口
    browser = Browser(client)  # 和 WS 模式一样使用
"""

import asyncio
import json
import os
import urllib.request
import urllib.error
from typing import Any

_DEFAULT_PORT = 38127
_TIMEOUT = 30  # 秒


def _default_native_host_port() -> int:
    return int(os.environ.get("NATIVE_HOST_PORT", _DEFAULT_PORT))


def _cdp_http_url(port: int) -> str:
    return f"http://127.0.0.1:{port}/cdp"


def _cdp_status_url(port: int) -> str:
    return f"http://127.0.0.1:{port}/status"


def _group_id() -> str:
    return os.environ.get("GROUP_ID", "").strip()


class SessionEndedError(RuntimeError):
    """用户停止/接管/关 tab 导致 session 被插件结束，非插件故障。"""

    pass


class BrowserConnectionError(RuntimeError):
    """Transport failure; do not enqueue more browser operations this run."""


class CDPCommandError(RuntimeError):
    def __init__(self, error: Any):
        self.code = _cdp_error_code(error)
        self.message = _cdp_error_message(error)
        super().__init__(f"CDP error: code={self.code} message={self.message}")


CONNECTION_RECOVERY_HINT = (
    "浏览器通信异常，本轮停止新的浏览器操作，不要换网址或连续重试。"
    "超时不代表底层操作已取消，也不能据此判断页面操作未完成。"
    "请用文字引导用户检查浏览器连接，插件模式可重载插件，恢复后再继续；"
    "不要自动关闭页面、重建含未保存输入的页面或切换浏览器。"
)


USER_STOP_HINT = "用户主动停止了浏览器操作。本轮对话不要再发起新的浏览器操作。当时正在进行的操作仍可能已经完成，不要据此判断该操作未完成。"


def _cdp_error_code(err: Any) -> int | None:
    if not isinstance(err, dict):
        return None
    try:
        return int(err.get("code"))
    except (TypeError, ValueError):
        return None


def _cdp_error_message(err: Any) -> str:
    if isinstance(err, dict):
        return str(err.get("message", err))
    return str(err)


def _raise_cdp_error(err: Any) -> None:
    msg = _cdp_error_message(err)
    if _cdp_error_code(err) == -32000 and msg.strip() == "user_stop":
        raise SessionEndedError(USER_STOP_HINT)
    if "session ended by plugin" in msg:
        raise SessionEndedError(msg)
    if _cdp_error_code(err) == -32005 and msg.startswith("session_unhealthy:"):
        raise BrowserConnectionError(f"CDP error: code=-32005 message={msg}")
    raise CDPCommandError(err)


def _urlopen_json(req: urllib.request.Request, timeout: float) -> Any:
    """urlopen + 读 JSON；HTTPError 时确保关闭底层连接。"""
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        # Read the error envelope before closing it: 503/504 alone loses the
        # native-host reason and CDP code needed to diagnose session failures.
        try:
            raw = e.read()
        finally:
            e.close()
        detail = ""
        try:
            envelope = json.loads(raw)
            error = envelope.get("error") if isinstance(envelope, dict) else None
            if error:
                detail = f"; code={_cdp_error_code(error)} message={_cdp_error_message(error)}"
        except (ValueError, UnicodeDecodeError):
            pass
        raise BrowserConnectionError(
            f"native-host HTTP error: {e.code} {e.reason}{detail}"
        ) from e


class _HTTPCDPMethod:
    """二级代理：send.Page.navigate → 发 CDP Page.navigate"""

    def __init__(self, client: "HTTPCDPClient", domain: str):
        self._client = client
        self._domain = domain

    def __getattr__(self, method: str) -> Any:
        full_method = f"{self._domain}.{method}"

        async def _send(params: dict = None, session_id: str = "") -> dict:
            return await self._client._send(full_method, params or {}, session_id)

        return _send


class _HTTPCDPSender:
    """一级代理：send.Page → 返回 _HTTPCDPMethod(client, "Page")"""

    def __init__(self, client: "HTTPCDPClient"):
        self._client = client

    def __getattr__(self, domain: str) -> _HTTPCDPMethod:
        return _HTTPCDPMethod(self._client, domain)


class HTTPCDPClient:
    """HTTP CDP 客户端——通过 native-host / in-app HTTP /cdp 接口转发 CDP 命令

    接口与 cdp_use.client.CDPClient 兼容：
    - .send.Domain.method(params={}, session_id="xxx") → async 返回 result dict
    - .start() → 空操作
    - .close() → 空操作
    """

    def __init__(self, session_id: str = "", port: int | None = None):
        self._session_id = session_id
        self._port = int(port) if port is not None else _default_native_host_port()
        self.send = _HTTPCDPSender(self)

    async def start(self) -> None:
        pass

    async def close(self) -> None:
        pass

    async def send_raw_method(self, method: str, params: dict | None = None) -> dict:
        """发送无 CDP domain 前缀的 Lingxi Provider 扩展命令。"""
        method = str(method or "").strip()
        if not method:
            raise ValueError("method 不能为空")
        return await self._send(method, params or {})

    async def session_start(self, brief: str = "") -> dict:
        """In-App：新会话先通过 /cdp 发送 session_start 注册会话。"""
        body_dict = {
            "session_id": self._session_id,
            "method": "session_start",
            "params": {"brief": brief},
        }
        group_id = _group_id()
        if group_id:
            body_dict["group_id"] = group_id
        body = json.dumps(body_dict, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(
            _cdp_http_url(self._port),
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            data = await asyncio.to_thread(_urlopen_json, req, _TIMEOUT)
        except (urllib.error.URLError, TimeoutError) as e:
            raise BrowserConnectionError(
                f"session_start: native-host unreachable: {e}"
            ) from e

        if isinstance(data, dict) and data.get("error"):
            _raise_cdp_error(data["error"])
        return data.get("result", data) if isinstance(data, dict) else {}

    async def _send(self, method: str, params: dict, session_id: str = "") -> dict:
        # native-host 路由用 self._session_id（宿主注入，session_start 时注册到插件）
        # session_id 参数是 core.Browser 的 CDP session_id（attachToTarget 返回），
        # 插件模式下 chrome.debugger.sendCommand 不需要它（已 attached 到 tab），
        # 但 native-host 发 cdp.command 给插件时必须带 self._session_id，
        # 插件用它查找 NativeSession 路由到正确的 tab
        body_dict = {
            "method": method,
            "params": params or {},
            "session_id": self._session_id,
        }
        group_id = _group_id()
        if group_id:
            body_dict["group_id"] = group_id
        # brief 从环境变量读（宿主每次 CLI/bash 调用注入），
        # 用于浏览器 tab group 标题实时更新
        brief = os.environ.get("BROWSER_BRIEF", "")
        if brief:
            body_dict["brief"] = brief

        body = json.dumps(body_dict, ensure_ascii=False).encode("utf-8")

        headers = {"Content-Type": "application/json"}

        req = urllib.request.Request(
            _cdp_http_url(self._port),
            data=body,
            headers=headers,
            method="POST",
        )

        timeout = 5 if method == "Browser.getVersion" else _TIMEOUT
        if method == "Runtime.evaluate" and isinstance(
            params.get("timeout"), (int, float)
        ):
            timeout = min(timeout, max(0.05, params["timeout"] / 1000))
        try:
            data = await asyncio.to_thread(_urlopen_json, req, timeout)
        except (urllib.error.URLError, TimeoutError) as e:
            raise BrowserConnectionError(
                f"{method}: native-host unreachable or timed out: {e}"
            ) from e
        except BrowserConnectionError as e:
            raise BrowserConnectionError(f"{method}: {e}") from e

        if data.get("error"):
            _raise_cdp_error(data["error"])

        return data.get("result", {})


def native_host_available(port: int | None = None) -> bool:
    """检查 native-host / HTTP CDP 端口是否可用"""
    p = int(port) if port is not None else _default_native_host_port()
    try:
        req = urllib.request.Request(_cdp_status_url(p), method="GET")
        data = _urlopen_json(req, 2)
        return isinstance(data, dict) and data.get("pluginConnected", False)
    except Exception:
        return False
