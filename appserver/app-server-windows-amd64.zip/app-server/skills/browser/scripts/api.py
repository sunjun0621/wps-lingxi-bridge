import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Awaitable, Callable, TypedDict

import core, util


_TARGET_DISPOSITIONS = frozenset(("deliverable", "handoff"))


def _normalize_target_id(target_id: str) -> str:
    if not isinstance(target_id, str):
        raise TypeError("targetId 必须是字符串")
    value = target_id.strip()
    if not value:
        raise ValueError("targetId 不能为空")
    return value


def _normalize_optional_target_id(target_id: str | None) -> str | None:
    if target_id is None:
        return None
    return _normalize_target_id(target_id)


def _normalize_target_ids(target_ids: list[str]) -> list[str]:
    if not isinstance(target_ids, list):
        raise TypeError("targetIds 必须是字符串列表")
    unique: list[str] = []
    seen: set[str] = set()
    for target_id in target_ids:
        value = _normalize_target_id(target_id)
        if value not in seen:
            seen.add(value)
            unique.append(value)
    if not unique:
        raise ValueError("tabs_close 至少需要一个 targetId")
    return unique


async def tabs_list() -> dict[str, list[core.ProviderTarget]]:
    browser = await util.get_target_management_browser()
    return {"targets": await browser.get_provider_targets()}


async def tabs_close(target_ids: list[str]) -> dict[str, Any]:
    normalized = _normalize_target_ids(target_ids)
    browser = await util.get_target_management_browser()
    return await browser.close_provider_targets(normalized)


async def tabs_activate(target_id: str) -> dict[str, Any]:
    normalized_target_id = _normalize_target_id(target_id)
    browser = await util.get_target_management_browser()
    targets = await browser.get_provider_targets()
    if not any(target["targetId"] == normalized_target_id for target in targets):
        # A previous run's temporary page may already have been cleaned up.
        # Do not attach, choose a replacement, or claim that activation worked.
        return {
            "targetId": normalized_target_id,
            "activated": False,
            "status": "target_unavailable",
        }
    await browser.activate_target(normalized_target_id)
    return {"targetId": normalized_target_id, "activated": True}


async def tabs_mark(target_id: str, disposition: str) -> dict[str, Any]:
    normalized_target_id = _normalize_target_id(target_id)
    if disposition not in _TARGET_DISPOSITIONS:
        raise ValueError("disposition 只能是 deliverable 或 handoff")
    browser = await util.get_target_management_browser()
    # A handoff target's lease belongs to the Run that attached it. Reattach in
    # the current Run before marking so cross-Run handoff pages can be retained.
    await browser.attach_to_target(normalized_target_id)
    return await browser.mark_provider_target(normalized_target_id, disposition)


@dataclass(frozen=True)
class _UploadFileInfo:
    path: str
    name: str
    size: int


def _normalize_upload_files(files: list[str]) -> list[_UploadFileInfo]:
    """Validate local upload paths and return stable absolute-path metadata."""

    if not isinstance(files, list):
        raise TypeError(
            'files 必须是文件路径字符串列表；单文件也请使用 ["/path/to/file"]'
        )

    if not files:
        raise ValueError("files 至少需要包含一个文件路径")

    normalized: list[_UploadFileInfo] = []
    for raw_path in files:
        if not isinstance(raw_path, str):
            raise TypeError("files 中的每一项都必须是文件路径字符串")
        if not raw_path.strip():
            raise ValueError("上传文件路径不能为空")

        candidate = Path(raw_path).expanduser()
        try:
            upload_path = candidate.absolute()
        except OSError as exc:
            raise OSError(f"无法检查上传文件路径：{candidate}：{exc}") from exc
        if not upload_path.exists():
            raise FileNotFoundError(f"上传文件不存在：{upload_path}")

        if not upload_path.is_file():
            raise ValueError(f"上传路径不是普通文件：{upload_path}")
        if not os.access(upload_path, os.R_OK):
            raise PermissionError(f"上传文件不可读：{upload_path}")

        size = upload_path.stat().st_size
        if size == 0:
            raise ValueError(f"上传文件大小为 0，可能尚未正确生成：{upload_path}")

        normalized.append(
            _UploadFileInfo(
                path=str(upload_path),
                name=upload_path.name,
                size=size,
            )
        )

    return normalized


async def _snapshot(browser: core.Browser) -> str:
    return await browser.call_extension("snapshot", "snapshot")


async def _display_screenshot(browser: core.Browser) -> None:
    try:
        data = await browser.screenshot(format="jpeg", quality=90, full_page=False)
        display(Image(data=data))  # type: ignore
    except Exception:
        pass


async def _get_page_action_browser(
    target_id: str | None,
    *,
    provider_target_required: bool,
) -> tuple[core.Browser, bool]:
    normalized_target_id = _normalize_optional_target_id(target_id)
    provider_mode = util.is_provider_browser_route()
    if provider_mode and provider_target_required and normalized_target_id is None:
        raise ValueError("Provider 页面操作必须指定 targetId")

    browser = await util.get_browser(
        ensure_page_target=not provider_mode and normalized_target_id is None
    )
    if normalized_target_id is not None:
        await browser.attach_to_target(normalized_target_id)
    return browser, provider_mode


def _actual_target_id(browser: core.Browser) -> str:
    target_id = browser.attached_target_id
    if not target_id:
        raise RuntimeError("浏览器未返回实际 targetId")
    return target_id


async def _run_with_optional_auto_switch(
    browser: core.Browser,
    provider_mode: bool,
    action: Callable[[], Awaitable[None]],
) -> None:
    if provider_mode:
        await action()
        return
    async with util.BrowserAutoSwitchTarget(browser):
        await action()


class NavigateResult(TypedDict):
    targetId: str
    snapshot: str | None


async def navigate(
    url: str,
    with_snapshot: bool = False,
    with_screenshot: bool = False,
    target_id: str | None = None,
) -> NavigateResult:
    browser, provider_mode = await _get_page_action_browser(
        target_id, provider_target_required=False
    )

    if target_id is None:
        await browser.create_and_attach_target(url)
    else:
        await browser.navigate_attached_target(url)
    await util.wait_dom_content_loaded(browser)
    if not provider_mode:
        util.persist_attached_page(browser, url)

    actual_target_id = _actual_target_id(browser)

    snapshot = None
    if with_snapshot:
        snapshot = await _snapshot(browser)
    if with_screenshot:
        await _display_screenshot(browser)

    return {"targetId": actual_target_id, "snapshot": snapshot}


class ClickResult(TypedDict):
    targetId: str
    snapshot: str | None


async def click(
    element_index: int,
    with_snapshot: bool = False,
    with_screenshot: bool = False,
    target_id: str | None = None,
) -> ClickResult:
    browser, provider_mode = await _get_page_action_browser(
        target_id, provider_target_required=True
    )

    await _run_with_optional_auto_switch(
        browser,
        provider_mode,
        lambda: browser.click_interactive_element(element_index),
    )
    actual_target_id = _actual_target_id(browser)

    snapshot = None
    if with_snapshot:
        snapshot = await _snapshot(browser)
    if with_screenshot:
        await _display_screenshot(browser)

    return {"targetId": actual_target_id, "snapshot": snapshot}


class FillResult(TypedDict):
    targetId: str
    snapshot: str | None


async def fill(
    element_index: int,
    text: str,
    press_enter: bool = False,
    with_snapshot: bool = False,
    with_screenshot: bool = False,
    target_id: str | None = None,
) -> FillResult:
    browser, provider_mode = await _get_page_action_browser(
        target_id, provider_target_required=True
    )

    await _run_with_optional_auto_switch(
        browser,
        provider_mode,
        lambda: browser.fill_interactive_element(element_index, text, press_enter),
    )
    actual_target_id = _actual_target_id(browser)

    snapshot = None
    if with_snapshot:
        snapshot = await _snapshot(browser)
    if with_screenshot:
        await _display_screenshot(browser)

    return {"targetId": actual_target_id, "snapshot": snapshot}


class UploadFilesResult(TypedDict):
    targetId: str
    snapshot: str | None
    selected_files: list[dict[str, Any]]
    target_source: str


async def upload_files(
    element_index: int,
    files: list[str],
    with_snapshot: bool = False,
    with_screenshot: bool = False,
    target_id: str | None = None,
) -> UploadFilesResult:
    requested = _normalize_upload_files(files)
    browser, provider_mode = await _get_page_action_browser(
        target_id, provider_target_required=True
    )

    async def upload() -> None:
        nonlocal selected_files, target
        paths = [item.path for item in requested]
        target = await browser.set_files_on_related_input(element_index, paths)
        if target is None:
            target = await browser.set_files_via_chooser(element_index, paths)
        # Upload components may synchronously consume the files and clear or
        # replace their input, so a persistent page FileList is not a valid
        # postcondition for either path.
        selected_files = [
            {"name": item.name, "size": item.size, "type": ""} for item in requested
        ]
        await util.wait_dom_stable(browser)

    target: dict[str, Any] | None = None
    selected_files: list[dict[str, Any]] = []
    await _run_with_optional_auto_switch(browser, provider_mode, upload)
    if target is None:
        raise RuntimeError("未找到文件上传目标")
    actual_target_id = _actual_target_id(browser)

    snapshot = None
    if with_snapshot:
        snapshot = await _snapshot(browser)
    if with_screenshot:
        await _display_screenshot(browser)

    return {
        "targetId": actual_target_id,
        "snapshot": snapshot,
        "selected_files": selected_files,
        "target_source": target["source"],
    }


class SelectOptionResult(TypedDict):
    targetId: str
    snapshot: str | None


async def select_option(
    element_index: int,
    option_text: str | None = None,
    option_value: str | None = None,
    option_index: int | None = None,
    with_snapshot: bool = False,
    with_screenshot: bool = False,
    target_id: str | None = None,
) -> SelectOptionResult:
    browser, provider_mode = await _get_page_action_browser(
        target_id, provider_target_required=True
    )

    async def select() -> None:
        label_j = json.dumps(option_text)
        val_j = json.dumps(option_value)
        idx_j = json.dumps(option_index)
        await browser.call_function_on_interactive_element(
            element_index,
            f"""function() {{
    this.scrollIntoView({{block: 'center', inline: 'nearest'}});
    const opts = Array.from(this.options);
    let idx = -1;
    const label = {label_j};
    const val = {val_j};
    const i = {idx_j};
    if (label !== null) {{
        idx = opts.findIndex(o => (o.text || '').trim() === label);
    }} else if (val !== null) {{
        idx = opts.findIndex(o => o.value === val);
    }} else if (i !== null && i !== undefined) {{
        idx = i;
    }}
    if (idx < 0 || idx >= opts.length) {{
        throw new Error('未找到匹配的 option 或索引无效');
    }}
    this.selectedIndex = idx;
    this.dispatchEvent(new Event('input', {{ bubbles: true }}));
    this.dispatchEvent(new Event('change', {{ bubbles: true }}));
}}""",
        )

    await _run_with_optional_auto_switch(browser, provider_mode, select)
    actual_target_id = _actual_target_id(browser)

    snapshot = None
    if with_snapshot:
        snapshot = await _snapshot(browser)
    if with_screenshot:
        await _display_screenshot(browser)

    return {"targetId": actual_target_id, "snapshot": snapshot}


class GetInteractiveElementsResult(TypedDict):
    targetId: str
    interactive_elements: list[dict]


async def get_interactive_elements(
    target_id: str | None = None,
) -> GetInteractiveElementsResult:
    browser, _ = await _get_page_action_browser(
        target_id, provider_target_required=True
    )
    interactive_elements = await browser.call_extension("snapshot", "extract_elements")
    return {
        "targetId": _actual_target_id(browser),
        "interactive_elements": interactive_elements,
    }


class ExecuteScriptResult(TypedDict):
    targetId: str
    result: str | None


async def execute_script(
    script: str, target_id: str | None = None
) -> ExecuteScriptResult:
    browser, provider_mode = await _get_page_action_browser(
        target_id, provider_target_required=True
    )

    result = None
    async def execute() -> None:
        nonlocal result
        try:
            result = await browser.evaluate(script)
        except core.EvaluateError as e:
            # 顶层 return 在裸表达式里非法；包进 IIFE 后重试，兼容 `return ...` 写法。
            # 仅在确实是 Illegal return 时重试，避免破坏裸表达式/自包 IIFE 的写法。
            if "Illegal return" in e.description:
                try:
                    result = await browser.evaluate(f"(function() {{\n{script}\n}})()")
                except core.EvaluateError as e2:
                    result = e2.description
            else:
                result = e.description

    await _run_with_optional_auto_switch(browser, provider_mode, execute)

    return {"targetId": _actual_target_id(browser), "result": result}


class ScreenshotResult(TypedDict):
    targetId: str
    data: bytes | None


async def screenshot(
    format: str = "jpeg",
    quality: int = 90,
    full_page: bool = False,
    target_id: str | None = None,
) -> ScreenshotResult:
    browser, _ = await _get_page_action_browser(
        target_id, provider_target_required=True
    )
    data = await browser.screenshot(format=format, quality=quality, full_page=full_page)
    return {"targetId": _actual_target_id(browser), "data": data}


class ExportToPdfResult(TypedDict):
    data: bytes | None


async def export_to_pdf() -> ExportToPdfResult:
    browser = await util.get_browser()
    data = await browser.export_to_pdf()
    return {"data": data}
