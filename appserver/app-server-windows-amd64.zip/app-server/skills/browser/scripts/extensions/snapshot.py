import os
import time
import asyncio
from pathlib import Path

import core

_EXTRACT_ELEMENTS_JS = (
    Path(__file__).with_name("extract_elements.js").read_text(encoding="utf-8")
)


class SnapshotExtension(core.Extension):
    MAX_TEXT_LEN = 10000
    MAX_ELEMENTS = 100

    def __init__(self, browser: core.Browser):
        super().__init__(browser)  # self.browser = browser

    async def extract_page_text(self) -> str:
        raw = await self.browser.evaluate(
            "(function(){ return document.body ? document.body.innerText : ''; })()"
        )
        result = []
        for line in str(raw or "").splitlines():
            s = line.strip()
            if not s or len(s) > 1000:
                continue
            alnum = sum(1 for c in s if c.isalnum() or "\u4e00" <= c <= "\u9fff")
            if alnum >= len(s) * 0.3:
                result.append(s)
        return "\n".join(result)

    async def extract_elements(self) -> str:
        # JS 采集可见元素和隐藏 file input 到交互元素数组，并返回描述列表
        descriptions: list[str] = (
            await self.browser.evaluate(_EXTRACT_ELEMENTS_JS) or []
        )
        return "\n".join(f"{i}[:] {desc}" for i, desc in enumerate(descriptions))

    def _save_text(self, text: str, prefix: str) -> str:
        workspace = Path(os.environ.get("WORKSPACE_DIR", "/tmp"))
        filename = f"{prefix}_{time.time_ns()}.txt"
        path = workspace / filename
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(text, encoding="utf-8")
        except Exception:
            path = Path("/tmp") / filename
            path.write_text(text, encoding="utf-8")
        return str(path)

    async def snapshot(self) -> str:
        page_text = await self.extract_page_text()
        elements = await self.extract_elements()
        # 元素与文本同时为空，通常是页面内容尚在异步渲染（如搜索结果懒加载），
        # 短暂等待后重试一次，避免快照抓到空页面、调用方被迫再手动刷新。
        if not page_text.strip() and not elements.strip():
            await asyncio.sleep(1)
            page_text = await self.extract_page_text()
            elements = await self.extract_elements()
        title = await self.browser.evaluate("document.title") or ""
        url = await self.browser.evaluate("location.href") or ""

        text_note = ""
        if len(page_text) > self.MAX_TEXT_LEN:
            saved = self._save_text(page_text, "page_text")
            text_note = f"\n[文本共 {len(page_text)} 字符，此处显示前 {self.MAX_TEXT_LEN} 字符，完整内容已保存至 {saved}]"
            page_text = page_text[: self.MAX_TEXT_LEN]

        elements_note = ""
        element_lines = elements.splitlines()
        if len(element_lines) > self.MAX_ELEMENTS:
            saved = self._save_text(elements, "page_elements")
            elements_note = f"\n[可交互元素共 {len(element_lines)} 个，此处显示前 {self.MAX_ELEMENTS} 个，完整列表已保存至 {saved}]"
            elements = "\n".join(element_lines[: self.MAX_ELEMENTS])

        return "\n".join(
            [
                "---",
                f"Title: {title}",
                f"URL: {url}",
                "---",
                "Interactive elements (index[:]info):",
                elements + elements_note,
                "---",
                "Page Text:",
                page_text + text_note,
            ]
        )
