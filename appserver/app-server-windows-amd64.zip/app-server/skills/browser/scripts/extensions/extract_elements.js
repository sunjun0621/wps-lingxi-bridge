(function() {
    var MAX_VISIBLE = 200;
    var MAX_HIDDEN_FILE_INPUTS = 20;
    window.__LINGXI_BROWSER__ = window.__LINGXI_BROWSER__ || {};
    var interactiveElements = [];
    var descriptions = [];

    function isVisible(el) {
        var rect = el.getBoundingClientRect();
        var style = window.getComputedStyle(el);
        return rect.width > 0
            && rect.height > 0
            && style.visibility !== 'hidden'
            && style.display !== 'none'
            && parseFloat(style.opacity || '1') > 0;
    }

    function normalizeText(value, maxLength) {
        return String(value || '')
            .replace(/\s+/g, ' ')
            .trim()
            .substring(0, maxLength);
    }

    function summarizeFileAccept(value) {
        var tokens = String(value || '')
            .split(',')
            .map(function(token) { return token.trim().toLowerCase(); })
            .filter(Boolean);
        var extensions = [];
        var categories = [];

        function addUnique(items, value) {
            if (value && items.indexOf(value) === -1) items.push(value);
        }

        tokens.forEach(function(token) {
            if (token.charAt(0) === '.') {
                addUnique(extensions, token);
            } else if (token === 'application/pdf') {
                addUnique(extensions, '.pdf');
            } else if (token.indexOf('word') !== -1 || token === 'application/msword') {
                addUnique(categories, 'document');
            } else if (token.indexOf('sheet') !== -1 || token.indexOf('excel') !== -1) {
                addUnique(categories, 'spreadsheet');
            } else if (token.indexOf('presentation') !== -1
                    || token.indexOf('powerpoint') !== -1) {
                addUnique(categories, 'presentation');
            } else if (token.indexOf('zip') !== -1
                    || token.indexOf('rar') !== -1
                    || token.indexOf('7z') !== -1) {
                addUnique(categories, 'archive');
            } else if (token.indexOf('image/') === 0) {
                addUnique(categories, 'image');
            } else if (token.indexOf('audio/') === 0) {
                addUnique(categories, 'audio');
            } else if (token.indexOf('video/') === 0) {
                addUnique(categories, 'video');
            } else if (token.indexOf('text/') === 0) {
                addUnique(categories, 'text');
            }
        });

        return extensions.concat(categories).join(',');
    }

    function fileInputContext(el) {
        var labels = el.labels ? Array.from(el.labels) : [];
        for (var i = 0; i < labels.length; i++) {
            var labelText = normalizeText(labels[i].innerText || labels[i].textContent, 60);
            if (labelText) return labelText;
        }

        var ariaLabel = normalizeText(el.getAttribute('aria-label'), 60);
        if (ariaLabel) return ariaLabel;

        var parent = el.parentElement;
        for (var depth = 0; parent && depth < 2; depth++, parent = parent.parentElement) {
            var parentText = normalizeText(parent.innerText || parent.textContent, 60);
            if (parentText) return parentText;
        }
        return '';
    }

    function describeElement(el, hiddenFileInput) {
        var tag = el.tagName.toLowerCase();
        var type = (el.getAttribute('type') || '').toLowerCase();
        var isFileInput = tag === 'input' && type === 'file';
        var parts = [tag];
        if (type && type !== tag) parts.push('type="' + type + '"');
        if (hiddenFileInput) parts.push('hidden');
        if (isFileInput && el.disabled) parts.push('disabled');
        if (isFileInput) {
            if (el.multiple) parts.push('multiple');
            var accept = summarizeFileAccept(el.getAttribute('accept'));
            if (accept) parts.push('accept="' + accept + '"');
            var id = el.getAttribute('id') || '';
            if (id) parts.push('id="' + normalizeText(id, 60) + '"');
        }
        var name = el.getAttribute('name') || '';
        if (name) parts.push('name="' + normalizeText(name, 60) + '"');
        var labelFor = el.getAttribute('for') || '';
        if (tag === 'label' && labelFor) {
            parts.push('for="' + normalizeText(labelFor, 60) + '"');
        }
        var ariaLabel = el.getAttribute('aria-label') || '';
        if (ariaLabel) parts.push('aria-label="' + normalizeText(ariaLabel, 60) + '"');
        var role = el.getAttribute('role') || '';
        if (role) parts.push('role="' + normalizeText(role, 30) + '"');
        var ariaControls = el.getAttribute('aria-controls') || '';
        if (ariaControls) {
            parts.push('aria-controls="' + normalizeText(ariaControls, 60) + '"');
        }
        var placeholder = el.getAttribute('placeholder') || '';
        if (placeholder) {
            parts.push('placeholder="' + normalizeText(placeholder, 40) + '"');
        }
        var href = el.getAttribute('href') || '';
        if (href) parts.push('href="' + normalizeText(href, 60) + '"');

        var display = '';
        if (tag === 'select') {
            var opts = Array.from(el.options).map(function(option) {
                return option.text.trim();
            });
            var selected = el.options[el.selectedIndex]
                ? el.options[el.selectedIndex].text.trim() : '';
            var optsStr = opts.slice(0, 10).join(' / ');
            if (opts.length > 10) optsStr += ' \u2026 (+' + (opts.length - 10) + ')';
            display = 'selected="' + selected + '" options=[' + optsStr + ']';
        } else if (isFileInput) {
            if (el.files && el.files.length) {
                display = Array.from(el.files).map(function(file) {
                    return file.name;
                }).join(', ').substring(0, 80);
            }
            var context = fileInputContext(el);
            if (context) parts.push('context="' + context + '"');
        } else if (tag === 'input' && el.value) {
            display = el.value.substring(0, 40);
        } else {
            display = normalizeText(el.innerText, 60);
        }

        var description = parts.join(' ');
        if (display) description += ' | ' + display;
        return description;
    }

    function appendElement(el, hiddenFileInput) {
        interactiveElements.push(el);
        descriptions.push(describeElement(el, hiddenFileInput));
    }

    var all = Array.from(
        document.querySelectorAll('a, button, input, select, textarea, label')
    );
    var visibleCount = 0;
    var hiddenFileInputCount = 0;
    for (var i = 0; i < all.length; i++) {
        var el = all[i];
        var tag = el.tagName.toLowerCase();
        var type = (el.getAttribute('type') || '').toLowerCase();
        var isFileInput = tag === 'input' && type === 'file';
        var visible = isVisible(el);

        if (isFileInput) {
            if (visible && visibleCount >= MAX_VISIBLE) continue;
            if (!visible && hiddenFileInputCount >= MAX_HIDDEN_FILE_INPUTS) continue;
            appendElement(el, !visible);
            if (visible) {
                visibleCount++;
            } else {
                hiddenFileInputCount++;
            }
            continue;
        }

        if (!visible || visibleCount >= MAX_VISIBLE) continue;
        if (tag === 'input' && type === 'hidden') continue;
        if (tag === 'label') {
            var controlled = el.control;
            var nestedFile = el.querySelector('input[type="file"]');
            var controlsFile = controlled
                && controlled.tagName === 'INPUT'
                && (controlled.getAttribute('type') || '').toLowerCase() === 'file';
            if (!controlsFile && !nestedFile) continue;
        }

        appendElement(el, false);
        visibleCount++;
    }

    window.__LINGXI_BROWSER__.interactiveElements = interactiveElements;
    return descriptions;
})()
