import json

import api
import core
import util
from cdp_http import BrowserConnectionError, CONNECTION_RECOVERY_HINT, SessionEndedError


# 保留 mode 属性供本地库调试；CLI 选路由宿主环境变量驱动（BROWSER_PLUGIN_MODE 等）。
mode: str = "extension"

_AUTH_HANDOFF_TEXT_REPLY_HINT = (
    "若页面出现登录、授权、验证码、扫码或人机验证，请立即停止自动化。"
    "先对明确的 TargetId 调用 "
    "tabs_mark --target-id <target> --disposition handoff 并确认成功，"
    "再直接用文字引导用户在当前页面手动完成；"
    "不要调用 ask_user_question，也不要自动操作认证流程。"
    "待用户以文字确认已完成后，重新调用 tabs_list 确认 Target，"
    "再调用 get_interactive_elements 刷新页面状态。"
)

_LEGACY_AUTH_HANDOFF_TEXT_REPLY_HINT = (
    "若页面出现登录、授权、验证码、扫码或人机验证，请立即停止自动化，"
    "直接用文字引导用户在当前页面手动完成；"
    "不要调用 ask_user_question，也不要自动操作认证流程。"
    "当前插件暂不支持标签管理，跳过 tabs_* 命令，不要声称已标记保留页面。"
    "待用户以文字确认已完成后，对此前明确的 TargetId 调用 "
    "get_interactive_elements，重新核对页面 URL、标题和元素后再继续；"
    "目标不存在或无法确认时停止，不要重建含未保存输入的页面。"
)


def _auth_handoff_text_reply_hint() -> str:
    """在支持 Target 交接的当前页面工作流中返回统一认证提示。"""
    if not util.is_provider_browser_route() or util._browser_mode not in (
        "extension",
        "in_app",
    ):
        return ""
    if util.extension_tabs_disabled():
        return _LEGACY_AUTH_HANDOFF_TEXT_REPLY_HINT
    return _AUTH_HANDOFF_TEXT_REPLY_HINT


def _append_runtime_hint(message: str) -> str:
    if hint := _auth_handoff_text_reply_hint():
        return f"{message}\n\n{hint}"
    return message


def _append_delivery_hint(message: str) -> str:
    """Remind IAB callers at the point of use, without changing page lifetime."""
    if util._browser_mode != "in_app" or not util._current_route().startswith("in_app:"):
        return message
    return (
        f"{message}\n\n页面交付提醒：如果此页面需要交给用户查看或继续操作，"
        "结束本轮前必须调用 tabs_mark --target-id <当前 TargetId> --disposition deliverable。"
        "标记成功且 Activated 为 true 后，才能声称页面已保留并展示。"
        "仅 tabs_activate 成功只表示已切到前台，不表示已保留；"
        "仅用于资料采集的临时页面无需标记。下一轮先 tabs_list 确认有效 Target，"
        "不要直接使用历史 TargetId。"
    )


def _run_action(action: str, coro):
    """执行浏览器操作；user_stop 与旧插件契约错误转为提示，本轮不再发起新操作"""
    try:
        return util.run_coroutine_threadsafe(coro)
    except SessionEndedError:
        return util.ASK_USER_STOP_HINT
    except core.ProviderTargetContractError as e:
        # 旧版插件不返回多标签契约：真实调用已失败，转为提示引导模型
        # 回退原有页面操作流程，不再发起 tabs_* 重试。
        return (
            f"{action} 未执行（unsupported）：\n"
            f"{e}\n"
            "当前插件版本暂不支持标签管理，本次未执行。"
            "请继续使用原有页面操作流程，不要重试 tabs_* 命令。"
        )


_UPLOAD_FILE_ACCESS_GUIDANCE = (
    "浏览器插件未开启“允许访问文件网址”，无法上传本地文件。\n"
    "请引导用户打开 chrome://extensions，进入当前浏览器插件的详情页，"
    "开启“允许访问文件网址”，然后重新建立浏览器会话并重试上传。\n"
    "以文字形式向用户说明上述操作步骤并请用户完成设置。\n"
    "权限开启前不要自动重试 upload_files，也不要改用 click()，"
    "否则可能弹出系统文件选择器。\n"
    '原始错误：{"code":-32000,"message":"Not allowed"}'
)


def _make_error_message(action: str, e: Exception) -> str:
    if isinstance(e, core.ProviderTargetContractError):
        # 旧版插件不返回多标签契约：命令已尝试真实执行并失败，引导模型
        # 回退原有页面操作流程，不要把契约错误当作浏览器故障重试。
        return (
            f"{action} 未执行（unsupported）：\n"
            f"{e}\n"
            f"当前插件版本暂不支持标签管理，本次未执行。请继续使用原有页面操作流程，不要重试 tabs_* 命令。"
        )
    if isinstance(e, BrowserConnectionError):
        return f"{action} 失败：\n{e}\n\n{CONNECTION_RECOVERY_HINT}"
    if isinstance(e, TimeoutError):
        return f"{action} 超时"
    error_text = str(e)
    if (
        action == "upload_files"
        and "-32000" in error_text
        and "Not allowed" in error_text
    ):
        return f"{action} 失败：\n{_UPLOAD_FILE_ACCESS_GUIDANCE}"
    extra_info = ""
    if (
        action != "navigate"
        and isinstance(e, RuntimeError)
        and len(e.args) > 0
        and isinstance(e.args[0], dict)
        and "code" in e.args[0]
        and e.args[0]["code"] == -32601  # 'action' wasn't found
    ):
        extra_info += f"\n浏览器可能已关闭，请先执行 navigate 操作打开浏览器，再重新执行 {action} 操作"
    return f"{action} 失败：\n{e}{extra_info}"


def _format_management_result(action: str, result: object) -> str:
    return f"{action} 成功：\n{json.dumps(result, ensure_ascii=False, indent=2)}"


def _single_line(value: object) -> str:
    return str(value).replace("\r", "\\r").replace("\n", "\\n")


def _markdown_code(value: object) -> str:
    text = _single_line(value)
    longest_run = current_run = 0
    for char in text:
        if char == "`":
            current_run += 1
            longest_run = max(longest_run, current_run)
        else:
            current_run = 0
    fence = "`" * (longest_run + 1)
    if text.startswith(("`", " ")) or text.endswith(("`", " ")):
        text = f" {text} "
    return f"{fence}{text}{fence}"


def _markdown_link(url: object) -> str:
    text = _single_line(url)
    label = text.replace("\\", "\\\\").replace("[", "\\[").replace("]", "\\]")
    destination = (
        text.replace("\\", "\\\\")
        .replace("(", "\\(")
        .replace(")", "\\)")
        .replace(" ", "%20")
    )
    return f"[{label}]({destination})"


def _format_tabs_list_result(result: object) -> str:
    if not isinstance(result, dict) or not isinstance(result.get("targets"), list):
        return _format_management_result("tabs_list", result)

    targets = result["targets"]
    lines = ["### Browser Pages", "", f"Total open pages: {len(targets)}"]
    for index, target in enumerate(targets, start=1):
        if not isinstance(target, dict):
            return _format_management_result("tabs_list", result)
        lines.extend(
            [
                "",
                f"#### Page {index}",
                "",
                f"- Target ID: {_markdown_code(target.get('targetId', ''))}",
                f"- Title: {_markdown_code(target.get('title', ''))}",
                f"- URL: {_markdown_link(target.get('url', ''))}",
                f"- Source: {_markdown_code(target.get('origin', ''))}",
                f"- Disposition: {_markdown_code(target.get('disposition', ''))}",
                f"- Is Current: {_markdown_code(str(target.get('is_current', False)).lower())}",
            ]
        )
    return "\n".join(lines)


def _format_tabs_mark_result(result: object) -> str:
    if not isinstance(result, dict):
        return _format_management_result("tabs_mark", result)

    lines = [
        "### Browser Page Marked",
        "",
        f"- Target ID: {_markdown_code(result.get('targetId', ''))}",
        f"- Disposition: {_markdown_code(result.get('disposition', ''))}",
        f"- Activated: {_markdown_code(str(result.get('activated', False)).lower())}",
    ]
    if "activationWarning" in result:
        lines.append(
            f"- Activation Warning: {_markdown_code(result.get('activationWarning', ''))}"
        )
    return "\n".join(lines)


def _format_tabs_close_result(result: object) -> str:
    if not isinstance(result, dict) or not isinstance(result.get("targets"), list):
        return _format_management_result("tabs_close", result)

    targets = result["targets"]
    if any(not isinstance(target, dict) for target in targets):
        return _format_management_result("tabs_close", result)
    successful = sum(target.get("success") is True for target in targets)
    failed = len(targets) - successful
    lines = [
        "### Browser Pages Close Result",
        "",
        f"- Overall Success: {_markdown_code(str(result.get('success') is True).lower())}",
        f"- Total Targets: {_markdown_code(len(targets))}",
        f"- Closed Successfully: {_markdown_code(successful)}",
        f"- Failed to Close: {_markdown_code(failed)}",
    ]
    for index, target in enumerate(targets, start=1):
        lines.extend(
            [
                "",
                f"#### Target {index}",
                "",
                f"- Target ID: {_markdown_code(target.get('targetId', ''))}",
                f"- Success: {_markdown_code(str(target.get('success') is True).lower())}",
            ]
        )
        if "error" in target:
            lines.append(f"- Error: {_markdown_code(target.get('error', ''))}")
    return "\n".join(lines)


def _format_tabs_activate_result(result: object) -> str:
    if not isinstance(result, dict):
        return _format_management_result("tabs_activate", result)

    if result.get("status") == "target_unavailable":
        return (
            "tabs_activate 未执行（target_unavailable）：\n"
            f"当前会话已无法访问 Target {_markdown_code(result.get('targetId', ''))}。"
            "未发送激活请求，也未切换其他页面。不要重试这个历史 TargetId；"
            "先 tabs_list 按 URL、标题确认当前有效页面。"
            "普通搜索结果可按用户需求重新打开，含未保存输入的页面不得直接重建。"
        )

    return "\n".join(
        [
            "### Browser Page Activated",
            "",
            f"- Target ID: {_markdown_code(result.get('targetId', ''))}",
            "- Activated: "
            f"{_markdown_code(str(result.get('activated', False)).lower())}",
        ]
    )


def tabs_list() -> str:
    action = "tabs_list"
    try:
        result = _run_action(action, api.tabs_list())
    except Exception as e:
        return _make_error_message(action, e)
    if isinstance(result, str):
        return result
    return _format_tabs_list_result(result)


def tabs_close(target_ids: list[str]) -> str:
    action = "tabs_close"
    try:
        result = _run_action(action, api.tabs_close(target_ids))
    except Exception as e:
        return _make_error_message(action, e)
    if isinstance(result, str):
        return result
    return _format_tabs_close_result(result)


def tabs_activate(target_id: str) -> str:
    action = "tabs_activate"
    try:
        result = _run_action(action, api.tabs_activate(target_id))
    except Exception as e:
        return _make_error_message(action, e)
    if isinstance(result, str):
        return result
    output = _format_tabs_activate_result(result)
    if isinstance(result, dict) and result.get("activated") is True:
        return _append_delivery_hint(output)
    return output


def tabs_mark(target_id: str, disposition: str) -> str:
    action = "tabs_mark"
    try:
        result = _run_action(action, api.tabs_mark(target_id, disposition))
    except Exception as e:
        return _make_error_message(action, e)
    if isinstance(result, str):
        return result
    return _format_tabs_mark_result(result)


def _snapshot_with_target_id(snapshot: str, target_id: str) -> str:
    """Place the target identity inside the snapshot header, above its title."""
    opening_delimiter = "---\n"
    target_line = f"TargetId: {target_id}\n"
    if snapshot.startswith(opening_delimiter):
        return f"{opening_delimiter}{target_line}{snapshot[len(opening_delimiter):]}"
    return f"{target_line}{snapshot}"


def _format_target_snapshot(action: str, result: dict) -> str:
    snapshot = _snapshot_with_target_id(result["snapshot"], result["targetId"])
    return _append_delivery_hint(f"{action} 成功：\n{snapshot}")


def navigate(url: str, target_id: str | None = None) -> str:
    action = "navigate"
    try:
        result = _run_action(
            action,
            api.navigate(
                url,
                target_id=target_id,
                with_snapshot=True,
                with_screenshot=True,
            ),
        )
    except Exception as e:
        return _make_error_message(action, e)
    if isinstance(result, str):
        return result
    return _append_runtime_hint(_format_target_snapshot(action, result))


def click(element_index: int, target_id: str | None = None) -> str:
    action = "click"
    try:
        result = _run_action(
            action,
            api.click(
                element_index,
                target_id=target_id,
                with_snapshot=True,
                with_screenshot=True,
            ),
        )
    except Exception as e:
        return _make_error_message(action, e)
    if isinstance(result, str):
        return result
    return _format_target_snapshot(action, result)


def fill(
    element_index: int,
    text: str,
    press_enter: bool = False,
    target_id: str | None = None,
) -> str:
    action = "fill"
    try:
        result = _run_action(
            action,
            api.fill(
                element_index,
                text,
                press_enter,
                target_id=target_id,
                with_snapshot=True,
                with_screenshot=True,
            ),
        )
    except Exception as e:
        return _make_error_message(action, e)
    if isinstance(result, str):
        return result
    return _format_target_snapshot(action, result)


def upload_files(
    element_index: int, files: list[str], target_id: str | None = None
) -> str:
    action = "upload_files"
    try:
        result: api.UploadFilesResult = util.run_coroutine_threadsafe(
            api.upload_files(
                element_index,
                files,
                target_id=target_id,
                with_snapshot=True,
                with_screenshot=True,
            )
        )
    except Exception as e:
        return _make_error_message(action, e)

    selected = ", ".join(str(item.get("name", "")) for item in result["selected_files"])
    snapshot = _snapshot_with_target_id(result["snapshot"], result["targetId"])
    return _append_delivery_hint(
        f"{action} 成功：\n"
        f"已将 {len(result['selected_files'])} 个文件放入页面上传控件：{selected}\n"
        "注意：本方法未点击提交按钮；页面可能在文件选择后自动上传。\n"
        f"{snapshot}"
    )


def select_option(
    element_index: int,
    option_text: str | None = None,
    option_value: str | None = None,
    option_index: int | None = None,
    target_id: str | None = None,
) -> str:
    action = "select_option"
    try:
        result = _run_action(
            action,
            api.select_option(
                element_index,
                option_text,
                option_value,
                option_index,
                target_id=target_id,
                with_snapshot=True,
                with_screenshot=True,
            ),
        )
    except Exception as e:
        return _make_error_message(action, e)
    if isinstance(result, str):
        return result
    return _format_target_snapshot(action, result)


def get_interactive_elements(target_id: str | None = None) -> str:
    action = "get_interactive_elements"
    try:
        result = _run_action(action, api.get_interactive_elements(target_id=target_id))
    except TimeoutError:
        return f"{action} 超时"
    except Exception as e:
        return f"{action} 失败：\n{e}"
    if isinstance(result, str):
        return result
    return _append_delivery_hint(
        f"{action} 成功：\nTargetId: {result['targetId']}\n---\n"
        f"{result['interactive_elements']}"
    )


def execute_script(script: str, target_id: str | None = None) -> str:
    action = "execute_script"
    try:
        result = _run_action(action, api.execute_script(script, target_id=target_id))
    except Exception as e:
        return _make_error_message(action, e)
    if isinstance(result, str):
        return result
    return _append_delivery_hint(
        f"{action} 成功：\nTargetId: {result['targetId']}\n---\n"
        f"{result['result']}"
    )


def screenshot(
    output: str = "screenshot.jpg",
    full_page: bool = False,
    target_id: str | None = None,
) -> str:
    action = "screenshot"
    data = None
    try:
        output_path, display_path = util.resolve_user_output_path(output)
        result = _run_action(
            action,
            api.screenshot(
                format={".jpg": "jpeg", ".jpeg": "jpeg", ".png": "png"}.get(
                    output_path.suffix.lower(), "jpeg"
                ),
                quality=90,
                full_page=full_page,
                target_id=target_id,
            ),
        )
    except Exception as e:
        return _make_error_message(action, e)
    if isinstance(result, str):
        return result
    output_path.parent.mkdir(parents=True, exist_ok=True)
    data = result["data"]
    output_path.write_bytes(data)

    try:
        display(Image(data=data))  # type: ignore
    except Exception:
        pass

    return _append_delivery_hint(
        f"{action} 成功：\nTargetId: {result['targetId']}\n---\n"
        f"截图已保存到 {display_path}"
    )


__all__ = [
    "tabs_list",
    "tabs_close",
    "tabs_activate",
    "tabs_mark",
    "navigate",
    "click",
    "fill",
    "upload_files",
    "select_option",
    "get_interactive_elements",
    "execute_script",
    "screenshot",
    "mode",
]
