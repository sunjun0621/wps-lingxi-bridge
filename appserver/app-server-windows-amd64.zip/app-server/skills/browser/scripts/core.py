from __future__ import annotations

import asyncio
import base64
import json
import mimetypes
from pathlib import Path
from typing import Any, Callable, Literal, TypedDict, cast

import httpx
from cdp_use.client import CDPClient

from cdp_http import SessionEndedError

_ACTIONS_JS = Path(__file__).with_name("actions.js").read_text(encoding="utf-8")


def _actions_expression(method: str, *args: Any) -> str:
    payload = ", ".join(json.dumps(arg, ensure_ascii=False) for arg in args)
    return f"({_ACTIONS_JS})().{method}({payload})"


FileInputSource = Literal[
    "self",
    "label",
    "ancestor_label",
    "descendant",
    "chooser",
]


class FileInputTarget(TypedDict):
    multiple: bool
    accept: str
    source: FileInputSource


class ProviderTargetContractError(RuntimeError):
    """Provider 响应不符合多标签扩展契约（例如旧版插件）。"""


class ProviderTarget(TypedDict):
    tabId: int
    targetId: str
    url: str
    title: str
    origin: str
    disposition: str
    leased: bool
    is_current: bool
    guestState: str


def _file_name(path: str) -> str:
    return path.replace("\\", "/").rsplit("/", 1)[-1]


def _parse_file_accept(accept: str) -> list[str]:
    tokens: list[str] = []
    for raw_token in accept.split(","):
        token = raw_token.strip().lower()
        if not token or token in tokens:
            continue
        if token.startswith(".") and len(token) > 1 and not any(
            char.isspace() for char in token
        ):
            tokens.append(token)
            continue
        if (
            token.count("/") == 1
            and ";" not in token
            and not any(char.isspace() for char in token)
        ):
            media_type, subtype = token.split("/", 1)
            if media_type and subtype:
                tokens.append(token)
    return tokens


def _matches_file_accept(path: str, tokens: list[str]) -> bool:
    name = _file_name(path).lower()
    guessed_type, _ = mimetypes.guess_type(name, strict=False)
    guessed_type = guessed_type.lower() if guessed_type else ""

    for token in tokens:
        if token.startswith("."):
            if name.endswith(token):
                return True
        elif token == "*/*":
            return True
        elif token.endswith("/*"):
            if guessed_type.startswith(token[:-1]):
                return True
        elif guessed_type == token:
            return True
    return False


def validate_file_input_files(
    files: list[str], *, multiple: bool, accept: str
) -> None:
    """Validate a complete file selection before handing it to Chrome."""

    if len(files) > 1 and not multiple:
        raise ValueError(
            f"当前上传控件不支持多文件，但收到了 {len(files)} 个文件"
        )

    tokens = _parse_file_accept(accept)
    if not tokens:
        return

    rejected = [
        _file_name(path) for path in files if not _matches_file_accept(path, tokens)
    ]
    if rejected:
        rejected_list = "\n".join(f"- {name}" for name in rejected)
        raise ValueError(
            f'以下文件不符合上传控件 accept="{accept}"：\n'
            f"{rejected_list}\n"
            "当前未向页面设置任何文件"
        )


class EvaluateError(Exception):
    def __init__(self, description: str):
        self.description = description

    def __str__(self):
        return self.description


class Extension:
    def __init__(self, browser: Browser):
        self.browser = browser

    async def call(self, action: str, *args: Any, **kwargs: Any) -> Any:
        handler = getattr(self, action, None)
        if handler is None:
            raise ValueError(f"Action {action} not found")
        return await handler(*args, **kwargs)


class Browser:
    _FILE_CHOOSER_CANCEL_GRACE_SECONDS = 0.5

    def __init__(self, cdp: CDPClient):
        self._cdp = cdp
        self._session_id: str = ""
        self._attached_target_id: str = ""
        self._extensions: dict[str, Extension] = {}
        self._upload_lock = asyncio.Lock()
        self._file_chooser_waiter: asyncio.Future[dict[str, Any]] | None = None
        self._file_chooser_session_id: str | None = None
        self._file_chooser_cancel_support: bool | None = None
        self._file_chooser_cancel_disable_task: asyncio.Task[None] | None = None
        page_registration = getattr(getattr(cdp, "register", None), "Page", None)
        self._supports_file_chooser = bool(
            page_registration is not None
            and hasattr(page_registration, "fileChooserOpened")
            and hasattr(getattr(cdp, "send", None), "Page")
            and hasattr(cdp.send.Page, "setInterceptFileChooserDialog")
        )
        if self._supports_file_chooser:
            page_registration.fileChooserOpened(self._on_file_chooser_opened)

    @classmethod
    async def create(cls, cdp_endpoint: str) -> Browser:
        """创建浏览器实例"""

        async with httpx.AsyncClient() as client:
            r = await client.get(f"{cdp_endpoint}/json/version", timeout=10)
        r.raise_for_status()
        ws_url = r.json()["webSocketDebuggerUrl"]
        cdp = CDPClient(ws_url)
        await cdp.start()
        return cls(cdp)

    @staticmethod
    def with_dom(fn: Callable) -> Callable:
        """使用 DOM 域装饰器"""

        async def wrapper(self, *args: Any, **kwargs: Any) -> Any:
            await self._cdp.send.DOM.enable(params={}, session_id=self._session_id)
            try:
                ret = await fn(self, *args, **kwargs)
            finally:
                await self._cdp.send.DOM.disable(params={}, session_id=self._session_id)
            return ret

        return wrapper

    async def is_healthy(self) -> bool:
        """健康检查；保留原始错误，不能把所有异常误报为标签已关闭。"""
        await self._cdp.send.Browser.getVersion(params={})
        return True

    async def attach_to_target(self, target_id: str) -> None:
        if self._session_id:
            await self._cdp.send.Target.detachFromTarget(
                params={"sessionId": self._session_id}
            )
            self._session_id = ""
            self._attached_target_id = ""
        ret = await self._cdp.send.Target.attachToTarget(
            params={"targetId": target_id, "flatten": True}
        )
        self._session_id = ret["sessionId"]
        self._attached_target_id = str(target_id)

    @property
    def attached_target_id(self) -> str:
        return self._attached_target_id

    async def activate_target(self, target_id: str) -> None:
        await self._cdp.send.Target.activateTarget(params={"targetId": target_id})

    @staticmethod
    def _target_matches_id(target: dict[str, Any], preferred_id: str) -> bool:
        if not preferred_id:
            return False
        return preferred_id in (
            str(target.get("targetId") or ""),
            str(target.get("tabId") or ""),
        )

    async def ensure_attached_to_page(
        self, preferred_url: str = "", preferred_target_id: str = ""
    ) -> bool:
        """若尚无 page session，则 attach 到已有 page target。

        CLI 每轮是新进程：Browser.create 只连上浏览器级 CDP WebSocket，
        Runtime/Page/DOM 等域必须先 Target.attachToTarget。navigate 会创建并
        attach；跨进程的 click/fill 等需在此恢复附着。
        内置浏览器同样需要这次 attach，才能把 SESSION_ID 重新绑到已有 tab。
        """
        if self._session_id:
            return True
        targets = await self.get_targets()
        if not targets:
            return False
        chosen: dict[str, Any] | None = None
        preferred_id = str(preferred_target_id or "").strip()
        if preferred_id:
            for t in targets:
                if self._target_matches_id(t, preferred_id):
                    chosen = t
                    break
        preferred = (preferred_url or "").strip()
        if chosen is None and preferred and preferred != "about:blank":
            for t in targets:
                if t.get("url") == preferred:
                    chosen = t
                    break
            if chosen is None:
                for t in targets:
                    u = t.get("url") or ""
                    if preferred in u or (u and u in preferred):
                        chosen = t
                        break
        if chosen is None:
            chosen = targets[-1]
        await self.attach_to_target(chosen["targetId"])
        return True

    async def navigate_attached_target(self, url: str) -> None:
        await self._cdp.send.Page.navigate(
            params={"url": url},
            session_id=self._session_id,
        )

    async def create_and_attach_target(self, url: str) -> str:
        ret = await self._cdp.send.Target.createTarget(params={"url": "about:blank"})
        target_id = ret["targetId"]
        await self.attach_to_target(target_id)
        await self.navigate_attached_target(url)
        return str(target_id)

    async def get_targets(self) -> list[dict[str, Any]]:
        ret = await self._cdp.send.Target.getTargets(params={})
        return list(
            filter(
                lambda x: x["type"] == "page" and not x["url"].startswith("chrome://"),
                ret["targetInfos"],
            )
        )

    async def get_provider_targets(self) -> list[ProviderTarget]:
        """解析 Lingxi Provider 扩展的 Target.getTargets 响应。

        契约判定只要求响应包含 targets 数组（新插件行为，旧插件只返回
        targetInfos）；数组内的可空字段（url/title/guestState 等在
        chrome:// 等特殊页面上可为 null）统一归一化为默认值。
        """
        ret = await self._cdp.send.Target.getTargets(params={})
        targets = ret.get("targets") if isinstance(ret, dict) else None
        if not isinstance(targets, list):
            raise ProviderTargetContractError(
                "Provider Target.getTargets 响应缺少 result.targets 数组"
            )
        # Extension 路由下插件构造的 targets[] 可能不带 url/title，
        # 只在 targetInfos[] 里；按 targetId 回填展示字段。
        info_by_id: dict[str, dict] = {}
        target_infos = ret.get("targetInfos")
        if isinstance(target_infos, list):
            for info in target_infos:
                if isinstance(info, dict) and isinstance(info.get("targetId"), str):
                    info_by_id[info["targetId"]] = info
        for target in targets:
            if not isinstance(target, dict):
                raise ProviderTargetContractError(
                    "Provider Target.getTargets 响应包含无效的 target"
                )
            info = info_by_id.get(target.get("targetId", ""), {})
            if not isinstance(target.get("url"), str):
                target["url"] = str(info.get("url") or "")
            if not isinstance(target.get("title"), str):
                target["title"] = str(info.get("title") or "")
            if not isinstance(target.get("targetId"), str) or not target["targetId"].strip():
                target["targetId"] = str(target.get("targetId") or "")
            for field in ("origin", "disposition", "guestState"):
                if not isinstance(target.get(field), str):
                    target[field] = ""
            if not isinstance(target.get("leased"), bool):
                target["leased"] = False
            if not isinstance(target.get("is_current"), bool):
                target["is_current"] = False
            if not isinstance(target.get("tabId"), int) or isinstance(
                target.get("tabId"), bool
            ):
                target["tabId"] = 0
        return cast(list[ProviderTarget], targets)

    async def close_provider_targets(self, target_ids: list[str]) -> dict[str, Any]:
        """一次调用 Lingxi Target.closeTargets 批量关闭明确 Target。"""
        ret = await self._cdp.send.Target.closeTargets(
            params={"targetIds": target_ids}
        )
        if not isinstance(ret, dict):
            raise RuntimeError("Provider Target.closeTargets 响应不是对象")
        return ret

    async def mark_provider_target(
        self, target_id: str, disposition: str
    ) -> dict[str, Any]:
        """标记 Provider Target，成功后将页面切到前台展示。"""
        raw_sender = getattr(self._cdp, "send_raw_method", None)
        if raw_sender is None:
            raise RuntimeError("当前 CDP client 不支持 Lingxi Provider 扩展命令")
        ret = await raw_sender(
            "mark_target",
            {"targetId": target_id, "disposition": disposition},
        )
        if not isinstance(ret, dict):
            raise RuntimeError("Provider mark_target 响应不是对象")
        try:
            await self.activate_target(target_id)
        except Exception as error:
            return {
                **ret,
                "activated": False,
                "activationWarning": str(error),
            }
        return {**ret, "activated": True}

    async def evaluate(
        self, script: str, timeout: float = 60, *, await_promise: bool = True
    ) -> Any:
        """执行 JS 表达式并返回结果"""

        # 注意：插件 / In-App（HTTPCDPClient）下 Browser._session_id 可为空——
        # 路由靠 HTTPCDPClient 自身的 SESSION_ID；page 级命令前需先 attach
        # 已有 tab（见 util._ensure_page_target），否则会报 no target tabId。

        ret = await self._cdp.send.Runtime.evaluate(
            params={
                "expression": script,
                "returnByValue": True,
                "userGesture": True,
                "awaitPromise": await_promise,
                "timeout": int(timeout * 1000),
                "allowUnsafeEvalBlockedByCsp": True,
            },
            session_id=self._session_id,
        )
        if "exceptionDetails" in ret:
            raise EvaluateError(ret["exceptionDetails"]["exception"]["description"])
        return ret["result"].get("value")

    async def _evaluate_expression_object(self, expression: str) -> str:
        ret = await self._cdp.send.Runtime.evaluate(
            params={
                "expression": expression,
                "returnByValue": False,
                "userGesture": True,
                "awaitPromise": True,
                "allowUnsafeEvalBlockedByCsp": True,
            },
            session_id=self._session_id,
        )
        if "exceptionDetails" in ret:
            raise EvaluateError(ret["exceptionDetails"]["exception"]["description"])
        object_id = ret["result"].get("objectId")
        if not object_id:
            raise EvaluateError("表达式未返回对象引用")
        return object_id

    async def _release_object(self, object_id: str | None) -> None:
        if not object_id:
            return
        try:
            await self._cdp.send.Runtime.releaseObject(
                params={"objectId": object_id},
                session_id=self._session_id,
            )
        except Exception:
            pass

    def _interactive_element_expression(self, element_index: int) -> str:
        return f"""(function(idx) {{
    var root = window.__LINGXI_BROWSER__;
    if (!root || !Array.isArray(root.interactiveElements)) {{
        throw new Error('请先调用快照刷新 interactiveElements 列表');
    }}
    var els = root.interactiveElements;
    if (idx < 0 || idx >= els.length) {{
        throw new Error(
            'element_index=' + idx + ' 超出范围，当前共 ' + els.length
            + ' 个元素，请先调用快照刷新列表'
        );
    }}
    var el = els[idx];
    if (!el || !el.isConnected) {{
        throw new Error(
            'element_index=' + idx + ' 对应的元素已从页面移除，请先调用快照刷新列表'
        );
    }}
    return el;
}})({element_index})"""

    async def call_function_on_interactive_element(
        self, element_index: int, function_declaration: str
    ) -> Any:
        object_id = await self._evaluate_expression_object(
            self._interactive_element_expression(element_index)
        )
        try:
            ret = await self._cdp.send.Runtime.callFunctionOn(
                params={
                    "functionDeclaration": function_declaration,
                    "objectId": object_id,
                    "returnByValue": True,
                    "userGesture": True,
                },
                session_id=self._session_id,
            )
            if "exceptionDetails" in ret:
                raise EvaluateError(
                    ret["exceptionDetails"]["exception"]["description"]
                )
            return ret["result"].get("value")
        finally:
            await self._release_object(object_id)

    @staticmethod
    def _is_file_chooser_cancel_unsupported(error: Exception) -> bool:
        message = str(error).lower()
        return (
            "invalid parameters" in message
            or "invalid params" in message
            or "unknown parameter" in message
            or "unrecognized parameter" in message
            or (
                "setinterceptfilechooserdialog" in message
                and ("wasn't found" in message or "not found" in message)
            )
        )

    async def _enable_file_chooser_cancel(self, session_id: str) -> bool:
        if self._file_chooser_cancel_support is False:
            return False
        try:
            await self._cdp.send.Page.setInterceptFileChooserDialog(
                params={"enabled": True, "cancel": True},
                session_id=session_id,
            )
        except Exception as error:
            try:
                await self._cdp.send.Page.setInterceptFileChooserDialog(
                    params={"enabled": False}, session_id=session_id
                )
            except Exception:
                pass
            if self._is_file_chooser_cancel_unsupported(error):
                self._file_chooser_cancel_support = False
                return False
            raise
        self._file_chooser_cancel_support = True
        return True

    async def _disable_file_chooser_cancel(self, session_id: str) -> None:
        try:
            await self._cdp.send.Page.setInterceptFileChooserDialog(
                params={"enabled": False}, session_id=session_id
            )
        except Exception:
            pass

    def _schedule_file_chooser_cancel_disable(self, session_id: str) -> None:
        previous = getattr(self, "_file_chooser_cancel_disable_task", None)
        if previous is not None and not previous.done():
            previous.cancel()

        async def disable_after_grace_period() -> None:
            try:
                await asyncio.sleep(self._FILE_CHOOSER_CANCEL_GRACE_SECONDS)
                async with self._upload_lock:
                    await self._disable_file_chooser_cancel(session_id)
            except asyncio.CancelledError:
                return

        task = asyncio.create_task(disable_after_grace_period())
        self._file_chooser_cancel_disable_task = task

        def clear_completed_task(completed: asyncio.Task[None]) -> None:
            if self._file_chooser_cancel_disable_task is completed:
                self._file_chooser_cancel_disable_task = None

        task.add_done_callback(clear_completed_task)

    async def click_interactive_element(self, element_index: int) -> None:
        """Click with deterministic DOM checks and native chooser cancellation."""

        async with self._upload_lock:
            previous = getattr(self, "_file_chooser_cancel_disable_task", None)
            if previous is not None and not previous.done():
                previous.cancel()
            self._file_chooser_cancel_disable_task = None

            session_id = self._session_id
            interception_enabled = await self._enable_file_chooser_cancel(
                session_id
            )
            try:
                await self._click_interactive_element_with_dom_guard(
                    element_index
                )
            except BaseException:
                if interception_enabled:
                    await self._disable_file_chooser_cancel(session_id)
                raise
            else:
                if interception_enabled:
                    self._schedule_file_chooser_cancel_disable(session_id)

    async def _click_interactive_element_with_dom_guard(
        self, element_index: int
    ) -> None:
        """Click unless the target has a deterministic file-input relation."""

        click_result = await self.evaluate(
            _actions_expression("clickInteractiveElement", element_index)
        )
        if click_result is None:
            return
        if not isinstance(click_result, dict):
            raise RuntimeError("无法确认 click 是否已执行，请刷新交互元素后重试")

        followed_href = str(click_result.get("followedHref") or "").strip()
        if followed_href:
            await self._follow_untrusted_anchor(
                followed_href,
                str(click_result.get("urlBefore") or ""),
            )
            return

        source = str(click_result.get("source") or "unknown")
        raise RuntimeError(
            "该元素明确关联文件上传控件，已阻止 click。"
            "请直接使用 browser.upload_files(element_index, files)，"
            "不要先调用 browser.click()。"
            f"关联方式：{source}"
        )

    async def _follow_untrusted_anchor(self, dest: str, url_before: str) -> None:
        """合成 click 未触发 <a> 导航时，用 Page.navigate 跟上真实 href。"""

        try:
            current = await self.evaluate(
                "(function(){ return window.location.href; })()"
            )
        except Exception:
            current = None
        if current and url_before and str(current) != url_before:
            return
        await self._cdp.send.Page.navigate(
            params={"url": dest},
            session_id=self._session_id,
        )

    @with_dom
    async def set_files_on_related_input(
        self, element_index: int, files: list[str]
    ) -> FileInputTarget | None:
        """Resolve a deterministic file input and set files via its JS object."""

        selected_object_id = await self._evaluate_expression_object(
            self._interactive_element_expression(element_index)
        )
        wrapper_object_id: str | None = None
        target_object_id: str | None = None
        relation_function = """function() {
    const isFileInput = (node) => node instanceof HTMLInputElement
        && (node.getAttribute('type') || '').toLowerCase() === 'file';
    if (isFileInput(this)) return { element: this, source: 'self' };

    if (this instanceof HTMLLabelElement && isFileInput(this.control)) {
        return { element: this.control, source: 'label' };
    }
    const ancestorLabel = this.closest ? this.closest('label') : null;
    if (ancestorLabel && isFileInput(ancestorLabel.control)) {
        return { element: ancestorLabel.control, source: 'ancestor_label' };
    }

    const descendants = this.querySelectorAll
        ? Array.from(this.querySelectorAll('input[type="file"]')) : [];
    if (descendants.length === 1) {
        return { element: descendants[0], source: 'descendant' };
    }
    return null;
}"""
        try:
            relation = await self._cdp.send.Runtime.callFunctionOn(
                params={
                    "functionDeclaration": relation_function,
                    "objectId": selected_object_id,
                    "returnByValue": False,
                },
                session_id=self._session_id,
            )
            if "exceptionDetails" in relation:
                raise EvaluateError(
                    relation["exceptionDetails"]["exception"]["description"]
                )
            relation_result = relation["result"]
            if relation_result.get("subtype") == "null":
                return None
            wrapper_object_id = relation_result.get("objectId")
            if not wrapper_object_id:
                return None

            metadata = await self._cdp.send.Runtime.callFunctionOn(
                params={
                    "functionDeclaration": """function() {
    return {
        source: this.source,
        multiple: Boolean(this.element.multiple),
        accept: this.element.getAttribute('accept') || ''
    };
}""",
                    "objectId": wrapper_object_id,
                    "returnByValue": True,
                },
                session_id=self._session_id,
            )
            if "exceptionDetails" in metadata:
                raise EvaluateError(
                    metadata["exceptionDetails"]["exception"]["description"]
                )

            target = await self._cdp.send.Runtime.callFunctionOn(
                params={
                    "functionDeclaration": "function() { return this.element; }",
                    "objectId": wrapper_object_id,
                    "returnByValue": False,
                },
                session_id=self._session_id,
            )
            if "exceptionDetails" in target:
                raise EvaluateError(
                    target["exceptionDetails"]["exception"]["description"]
                )
            target_object_id = target["result"].get("objectId")
            if not target_object_id:
                return None

            target_metadata = metadata["result"].get("value") or {}
            resolved_target = cast(
                FileInputTarget,
                {
                    "multiple": bool(target_metadata.get("multiple", False)),
                    "accept": str(target_metadata.get("accept", "")),
                    "source": target_metadata["source"],
                },
            )
            validate_file_input_files(
                files,
                multiple=resolved_target["multiple"],
                accept=resolved_target["accept"],
            )
            await self._set_file_input_files(target_object_id, files)
            return resolved_target
        finally:
            for object_id in (
                target_object_id,
                wrapper_object_id,
                selected_object_id,
            ):
                if object_id:
                    try:
                        await self._cdp.send.Runtime.releaseObject(
                            params={"objectId": object_id},
                            session_id=self._session_id,
                        )
                    except Exception:
                        pass

    async def _set_file_input_files(
        self, object_id: str, files: list[str]
    ) -> None:
        await self._cdp.send.DOM.setFileInputFiles(
            params={"objectId": object_id, "files": files},
            session_id=self._session_id,
        )

    async def _resolve_backend_node_object(self, backend_node_id: int) -> str:
        resolved = await self._cdp.send.DOM.resolveNode(
            params={"backendNodeId": backend_node_id},
            session_id=self._session_id,
        )
        object_id = resolved.get("object", {}).get("objectId")
        if not object_id:
            raise RuntimeError("无法将文件选择器节点解析为 JS 对象")
        return str(object_id)

    async def _get_file_input_accept(self, object_id: str) -> str:
        result = await self._cdp.send.Runtime.callFunctionOn(
            params={
                "functionDeclaration": (
                    "function() { return this.getAttribute('accept') || ''; }"
                ),
                "objectId": object_id,
                "returnByValue": True,
            },
            session_id=self._session_id,
        )
        if "exceptionDetails" in result:
            raise EvaluateError(
                result["exceptionDetails"]["exception"]["description"]
            )
        return str(result.get("result", {}).get("value") or "")

    @with_dom
    async def _set_files_from_chooser_event(
        self, event: dict[str, Any], files: list[str]
    ) -> FileInputTarget:
        object_id = await self._resolve_backend_node_object(
            int(event["backendNodeId"])
        )
        try:
            target = cast(
                FileInputTarget,
                {
                    "multiple": event.get("mode") == "selectMultiple",
                    "accept": await self._get_file_input_accept(object_id),
                    "source": "chooser",
                },
            )
            validate_file_input_files(
                files,
                multiple=target["multiple"],
                accept=target["accept"],
            )
            await self._set_file_input_files(object_id, files)
            return target
        finally:
            await self._release_object(object_id)

    def _on_file_chooser_opened(
        self, event: dict[str, Any], session_id: str | None
    ) -> None:
        waiter = self._file_chooser_waiter
        if (
            waiter is None
            or waiter.done()
            or session_id != self._file_chooser_session_id
        ):
            return
        backend_node_id = event.get("backendNodeId")
        if (
            not isinstance(backend_node_id, int)
            or isinstance(backend_node_id, bool)
            or backend_node_id <= 0
        ):
            waiter.set_exception(
                RuntimeError(
                    "文件选择器事件没有返回 file input 节点；"
                    "当前控件可能不是标准 input file chooser"
                )
            )
            return
        waiter.set_result(event)

    async def trusted_click_interactive_element(self, element_index: int) -> None:
        """Click via Runtime.evaluate so file-chooser buttons still get a user gesture."""

        await self.evaluate(
            _actions_expression("trustedClickInteractiveElement", element_index)
        )

    async def fill_interactive_element(
        self, element_index: int, text: str, press_enter: bool = False
    ) -> None:
        """Fill an input/textarea/contenteditable via Runtime.evaluate."""

        await self.evaluate(
            _actions_expression(
                "fillInteractiveElement", element_index, text, bool(press_enter)
            )
        )

    async def set_files_via_chooser(
        self,
        element_index: int,
        files: list[str],
        timeout: float = 10.0,
    ) -> FileInputTarget:
        """Atomically intercept a chooser opened by a button and set its files."""

        if timeout <= 0:
            raise ValueError("文件选择器等待时间必须大于 0")
        if not files:
            raise ValueError("files 至少需要包含一个文件路径")
        if not self._supports_file_chooser:
            raise RuntimeError("当前 cdp-use 客户端不支持文件选择器事件")

        async with self._upload_lock:
            session_id = self._session_id
            if not session_id:
                raise RuntimeError("当前没有可用的浏览器标签页")

            loop = asyncio.get_running_loop()
            waiter: asyncio.Future[dict[str, Any]] = loop.create_future()
            interception_enabled = False
            self._file_chooser_waiter = waiter
            self._file_chooser_session_id = session_id
            try:
                await self._cdp.send.Page.enable(
                    params={}, session_id=session_id
                )
                await self._cdp.send.Page.setInterceptFileChooserDialog(
                    params={"enabled": True}, session_id=session_id
                )
                interception_enabled = True

                # Install the waiter before clicking so a fast event cannot be lost.
                await self.trusted_click_interactive_element(element_index)
                try:
                    event = await asyncio.wait_for(waiter, timeout=timeout)
                except asyncio.TimeoutError as exc:
                    raise TimeoutError(
                        f"点击元素后 {timeout:g} 秒内未打开文件选择器"
                    ) from exc

                if self._session_id != session_id:
                    raise RuntimeError(
                        "等待文件选择器期间页面标签已发生变化，请刷新交互元素后重试"
                    )

                return await self._set_files_from_chooser_event(event, files)
            finally:
                if interception_enabled:
                    try:
                        await self._cdp.send.Page.setInterceptFileChooserDialog(
                            params={"enabled": False}, session_id=session_id
                        )
                    except Exception:
                        pass
                if self._file_chooser_waiter is waiter:
                    self._file_chooser_waiter = None
                    self._file_chooser_session_id = None
                if not waiter.done():
                    waiter.cancel()

    @with_dom
    async def query_selector_all(self, selector: str) -> list[int]:
        ret = await self._cdp.send.DOM.getDocument(
            params={"depth": -1},
            session_id=self._session_id,
        )
        # 遍历树，建立 nodeId → backendNodeId 映射
        node_map: dict[int, int] = {}
        stack: list[dict] = [ret["root"]]
        while stack:
            node = stack.pop()
            node_map[node["nodeId"]] = node.get("backendNodeId", -1)
            stack.extend(node.get("children", []))

        root_node_id = ret["root"]["nodeId"]
        ret = await self._cdp.send.DOM.querySelectorAll(
            params={"nodeId": root_node_id, "selector": selector},
            session_id=self._session_id,
        )
        return [node_map.get(nid, -1) for nid in ret["nodeIds"]]

    @with_dom
    async def scroll_into_view(self, backend_node_id: int) -> None:
        await self._cdp.send.DOM.scrollIntoViewIfNeeded(
            params={"backendNodeId": backend_node_id},
            session_id=self._session_id,
        )

    @with_dom
    async def focus(self, backend_node_id: int) -> None:
        await self._cdp.send.DOM.focus(
            params={"backendNodeId": backend_node_id},
            session_id=self._session_id,
        )

    async def screenshot(
        self, format: str = "jpeg", quality: int = 90, full_page: bool = False
    ) -> bytes:
        if format not in ("jpeg", "png"):
            raise ValueError(f"Invalid format: {format}")
        if quality not in range(0, 101):
            raise ValueError(f"Invalid quality: {quality}")
        params = {
            "format": format,
            "captureBeyondViewport": full_page,
        }
        if format == "jpeg":
            params["quality"] = quality

        ret = await self._cdp.send.Page.captureScreenshot(
            params=params,
            session_id=self._session_id,
        )
        return base64.b64decode(ret["data"])

    async def export_to_pdf(self) -> bytes:
        ret = await self._cdp.send.Page.printToPDF(
            params={},
            session_id=self._session_id,
        )
        return base64.b64decode(ret["data"])

    def register_extension(
        self, name: str, extension_class: Callable[[Browser], Extension]
    ) -> None:
        self._extensions[name] = extension_class(self)

    async def call_extension(
        self, name: str, action: str, *args: Any, **kwargs: Any
    ) -> Any:
        return await self._extensions[name].call(action, *args, **kwargs)
