/**
 * Page interaction helpers evaluated via Runtime.evaluate.
 * Click / fill follow page-controller's synthetic Pointer + UI Event sequence
 * instead of CDP Input.* commands.
 */
(function () {
    function resolveInteractiveElement(idx) {
        var root = window.__LINGXI_BROWSER__;
        if (!root || !Array.isArray(root.interactiveElements)) {
            throw new Error('请先调用快照刷新 interactiveElements 列表');
        }
        var els = root.interactiveElements;
        if (idx < 0 || idx >= els.length) {
            throw new Error(
                'element_index=' + idx + ' 超出范围，当前共 ' + els.length
                + ' 个元素，请先调用快照刷新列表'
            );
        }
        var el = els[idx];
        if (!el || !el.isConnected) {
            throw new Error(
                'element_index=' + idx + ' 对应的元素已从页面移除，请先调用快照刷新列表'
            );
        }
        return el;
    }

    function waitFor(seconds) {
        return new Promise(function (resolve) {
            setTimeout(resolve, seconds * 1000);
        });
    }

    function scrollIntoViewIfNeeded(element) {
        if (typeof element.scrollIntoViewIfNeeded === 'function') {
            element.scrollIntoViewIfNeeded();
        } else {
            element.scrollIntoView({
                behavior: 'auto',
                block: 'center',
                inline: 'nearest',
            });
        }
    }

    function isFileInput(node) {
        return node instanceof HTMLInputElement
            && (node.getAttribute('type') || '').toLowerCase() === 'file';
    }

    function resolveRelatedFileInput(element) {
        if (isFileInput(element)) {
            return { element: element, source: 'self' };
        }
        if (element instanceof HTMLLabelElement && isFileInput(element.control)) {
            return { element: element.control, source: 'label' };
        }
        var ancestorLabel = element.closest ? element.closest('label') : null;
        if (ancestorLabel && isFileInput(ancestorLabel.control)) {
            return { element: ancestorLabel.control, source: 'ancestor_label' };
        }
        var descendants = element.querySelectorAll
            ? Array.from(element.querySelectorAll('input[type="file"]'))
            : [];
        if (descendants.length === 1) {
            return { element: descendants[0], source: 'descendant' };
        }
        return null;
    }

    function fileInputMetadata(fileInput, source) {
        return {
            source: source,
            multiple: Boolean(fileInput.multiple),
            accept: fileInput.getAttribute('accept') || '',
        };
    }

    function blurLastClickedElement() {
        var root = window.__LINGXI_BROWSER__;
        if (!root) return;
        var last = root.lastClickedElement;
        if (last) {
            last.dispatchEvent(new PointerEvent('pointerout', { bubbles: true }));
            last.dispatchEvent(new PointerEvent('pointerleave', { bubbles: false }));
            last.dispatchEvent(new MouseEvent('mouseout', { bubbles: true }));
            last.dispatchEvent(new MouseEvent('mouseleave', { bubbles: false }));
            last.blur();
            root.lastClickedElement = null;
        }
    }

    function rememberClickedElement(element) {
        var root = window.__LINGXI_BROWSER__ = window.__LINGXI_BROWSER__ || {};
        root.lastClickedElement = element;
    }

    function getNativeValueSetter(element) {
        var proto = Object.getPrototypeOf(element);
        var desc = proto ? Object.getOwnPropertyDescriptor(proto, 'value') : null;
        if (desc && typeof desc.set === 'function') {
            return desc.set;
        }
        return function (value) {
            element.value = value;
        };
    }

    function resolveAnchor(element) {
        if (!element) return null;
        if (String(element.tagName || '').toUpperCase() === 'A') return element;
        return element.closest ? element.closest('a[href]') : null;
    }

    function isNavigableHttpHref(hrefAttr, resolvedHref) {
        var raw = String(hrefAttr || '').trim();
        if (!raw) return false;
        var lower = raw.toLowerCase();
        if (lower.charAt(0) === '#') return false;
        if (lower.indexOf('javascript:') === 0) return false;
        if (lower.indexOf('mailto:') === 0 || lower.indexOf('tel:') === 0) return false;
        return /^https?:/i.test(String(resolvedHref || '').trim());
    }

    // Runtime.evaluate 合成的 click / element.click() 在 Chromium 里 isTrusted=false，
    // <a> 默认导航会被拦；站点脚本也常 preventDefault 后只在可信点击时跳转。
    function followAnchorIfClickDidNotNavigate(element, urlBefore) {
        if (window.location.href !== urlBefore) return null;
        var link = resolveAnchor(element);
        if (!link) return null;
        var dest = link.href;
        if (!isNavigableHttpHref(link.getAttribute('href'), dest)) return null;
        if (!dest || dest === urlBefore) return null;
        if (link.hasAttribute('download')) return null;
        var tgt = String(link.getAttribute('target') || '').toLowerCase();
        if (tgt === '_blank' || tgt === '_new') {
            var opened = null;
            try {
                opened = window.open(dest, '_blank');
            } catch (err) {
                opened = null;
            }
            if (opened) return null;
        }
        return { followedHref: dest, urlBefore: urlBefore };
    }

    // W3C Pointer Events + UI Events order used by page-controller:
    // pointerover/enter → mouseover/enter → pointerdown → mousedown → [focus]
    // → pointerup → mouseup → click
    async function clickElement(element) {
        blurLastClickedElement();
        rememberClickedElement(element);

        scrollIntoViewIfNeeded(element);
        var frame = element.ownerDocument.defaultView
            && element.ownerDocument.defaultView.frameElement;
        if (frame) scrollIntoViewIfNeeded(frame);

        var rect = element.getBoundingClientRect();
        var x = rect.left + rect.width / 2;
        var y = rect.top + rect.height / 2;

        await waitFor(0.1);

        var doc = element.ownerDocument;
        var hitTarget = doc.elementFromPoint(x, y);
        var target = hitTarget instanceof HTMLElement && element.contains(hitTarget)
            ? hitTarget
            : element;

        var pointerOpts = {
            bubbles: true,
            cancelable: true,
            clientX: x,
            clientY: y,
            pointerType: 'mouse',
        };
        var mouseOpts = {
            bubbles: true,
            cancelable: true,
            clientX: x,
            clientY: y,
            button: 0,
        };

        target.dispatchEvent(new PointerEvent('pointerover', pointerOpts));
        target.dispatchEvent(new PointerEvent('pointerenter', Object.assign({}, pointerOpts, { bubbles: false })));
        target.dispatchEvent(new MouseEvent('mouseover', mouseOpts));
        target.dispatchEvent(new MouseEvent('mouseenter', Object.assign({}, mouseOpts, { bubbles: false })));

        target.dispatchEvent(new PointerEvent('pointerdown', pointerOpts));
        target.dispatchEvent(new MouseEvent('mousedown', mouseOpts));

        if (typeof element.focus === 'function') {
            element.focus({ preventScroll: true });
        }

        target.dispatchEvent(new PointerEvent('pointerup', pointerOpts));
        target.dispatchEvent(new MouseEvent('mouseup', mouseOpts));
        target.click();

        await waitFor(0.2);
    }

    function pressEnterKey(element) {
        var opts = {
            key: 'Enter',
            code: 'Enter',
            keyCode: 13,
            which: 13,
            charCode: 13,
            bubbles: true,
            cancelable: true,
        };
        var cancelled = !element.dispatchEvent(new KeyboardEvent('keydown', opts));
        element.dispatchEvent(new KeyboardEvent('keypress', opts));
        element.dispatchEvent(new KeyboardEvent('keyup', opts));
        if (cancelled) return;

        var form = element.form || (element.closest && element.closest('form'));
        if (!form) return;
        if (typeof form.requestSubmit === 'function') {
            try {
                form.requestSubmit();
                return;
            } catch (err) {
                // fall through to clicking a submitter / form.submit
            }
        }
        var submitter = form.querySelector(
            'button[type="submit"], input[type="submit"], input[type="image"], button:not([type])'
        );
        if (submitter) {
            submitter.click();
            return;
        }
        form.submit();
    }

    async function inputTextElement(element, text, pressEnter) {
        var isContentEditable = Boolean(element.isContentEditable);
        var isInput = element.tagName === 'INPUT';
        var isTextArea = element.tagName === 'TEXTAREA';
        if (isInput && isFileInput(element)) {
            throw new Error('文件上传控件请使用 upload_files，不要使用 fill');
        }
        if (!isInput && !isTextArea && !isContentEditable) {
            throw new Error('目标元素不是 input、textarea 或 contenteditable，无法 fill');
        }

        await clickElement(element);

        if (isContentEditable) {
            if (element.dispatchEvent(new InputEvent('beforeinput', {
                bubbles: true,
                cancelable: true,
                inputType: 'deleteContent',
            }))) {
                element.innerText = '';
                element.dispatchEvent(new InputEvent('input', {
                    bubbles: true,
                    inputType: 'deleteContent',
                }));
            }

            if (element.dispatchEvent(new InputEvent('beforeinput', {
                bubbles: true,
                cancelable: true,
                inputType: 'insertText',
                data: text,
            }))) {
                element.innerText = text;
                element.dispatchEvent(new InputEvent('input', {
                    bubbles: true,
                    inputType: 'insertText',
                    data: text,
                }));
            }

            var planASucceeded = String(element.innerText || '').trim() === String(text || '').trim();
            if (!planASucceeded) {
                element.focus();
                var doc = element.ownerDocument;
                var selection = (doc.defaultView || window).getSelection();
                var range = doc.createRange();
                range.selectNodeContents(element);
                if (selection) {
                    selection.removeAllRanges();
                    selection.addRange(range);
                }
                doc.execCommand('delete', false);
                doc.execCommand('insertText', false, text);
            }

            element.dispatchEvent(new Event('change', { bubbles: true }));
        } else {
            getNativeValueSetter(element).call(element, text);
            element.dispatchEvent(new Event('input', { bubbles: true }));
        }

        if (pressEnter) {
            pressEnterKey(element);
        } else {
            blurLastClickedElement();
        }

        await waitFor(0.1);
    }

    async function clickInteractiveElement(idx) {
        var element = resolveInteractiveElement(idx);
        var related = resolveRelatedFileInput(element);
        if (related) {
            return fileInputMetadata(related.element, related.source);
        }

        var synchronouslyClickedFileInput = null;
        var preventSynchronousFileInputClick = function (event) {
            var path = typeof event.composedPath === 'function'
                ? event.composedPath()
                : [event.target];
            var fileInput = path.find(isFileInput);
            if (!fileInput) return;
            synchronouslyClickedFileInput = fileInput;
            event.preventDefault();
        };

        var urlBefore = window.location.href;
        window.addEventListener('click', preventSynchronousFileInputClick, true);
        try {
            await clickElement(element);
        } finally {
            window.removeEventListener('click', preventSynchronousFileInputClick, true);
        }

        if (synchronouslyClickedFileInput) {
            return fileInputMetadata(synchronouslyClickedFileInput, 'synchronous_file_click');
        }
        return followAnchorIfClickDidNotNavigate(element, urlBefore);
    }

    async function trustedClickInteractiveElement(idx) {
        var element = resolveInteractiveElement(idx);
        await clickElement(element);
        return null;
    }

    async function fillInteractiveElement(idx, text, pressEnter) {
        var element = resolveInteractiveElement(idx);
        await inputTextElement(element, String(text == null ? '' : text), Boolean(pressEnter));
        return null;
    }

    return {
        clickInteractiveElement: clickInteractiveElement,
        trustedClickInteractiveElement: trustedClickInteractiveElement,
        fillInteractiveElement: fillInteractiveElement,
    };
})
