"""IAB delivery reminders and stale-target activation regression tests."""

import io
import os
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import api
import browser
import cli
import util
from cdp_http import CDPCommandError


class ActivationTests(unittest.IsolatedAsyncioTestCase):
    def page_provider(self, targets):
        provider = MagicMock()
        provider.get_provider_targets = AsyncMock(return_value=targets)
        provider.activate_target = AsyncMock()
        provider.attach_to_target = AsyncMock()
        provider.mark_provider_target = AsyncMock()
        return provider

    async def test_stale_target_is_unperformed_without_selecting_replacement(self):
        # A new target must not be substituted even when it has the same URL.
        provider = self.page_provider([{"targetId": "36", "url": "https://example.com"}])
        with patch.object(util, "get_target_management_browser", new=AsyncMock(return_value=provider)):
            result = await api.tabs_activate("35")
        self.assertEqual(result, {"targetId": "35", "activated": False, "status": "target_unavailable"})
        provider.activate_target.assert_not_awaited()
        provider.attach_to_target.assert_not_awaited()
        provider.mark_provider_target.assert_not_awaited()

    async def test_available_target_is_only_activated_after_listing(self):
        provider = self.page_provider([{"targetId": "35", "disposition": "auto_close"}])
        with patch.object(util, "get_target_management_browser", new=AsyncMock(return_value=provider)):
            result = await api.tabs_activate(" 35 ")
        self.assertEqual(result, {"targetId": "35", "activated": True})
        self.assertEqual([call[0] for call in provider.mock_calls], ["get_provider_targets", "activate_target"])
        provider.activate_target.assert_awaited_once_with("35")
        provider.attach_to_target.assert_not_awaited()
        provider.mark_provider_target.assert_not_awaited()

    async def test_list_failure_is_not_treated_as_missing_target(self):
        provider = self.page_provider([])
        error = RuntimeError("provider disconnected")
        provider.get_provider_targets.side_effect = error
        with patch.object(util, "get_target_management_browser", new=AsyncMock(return_value=provider)):
            with self.assertRaises(RuntimeError) as raised:
                await api.tabs_activate("35")
        self.assertIs(raised.exception, error)
        provider.activate_target.assert_not_awaited()

    async def test_ownership_change_after_listing_remains_a_real_error(self):
        provider = self.page_provider([{"targetId": "35"}])
        error = CDPCommandError({"code": -32000, "message": "tab_not_owned_by_session"})
        provider.activate_target.side_effect = error
        with patch.object(util, "get_target_management_browser", new=AsyncMock(return_value=provider)):
            with self.assertRaises(CDPCommandError) as raised:
                await api.tabs_activate("35")
        self.assertIs(raised.exception, error)
        provider.activate_target.assert_awaited_once_with("35")
        provider.attach_to_target.assert_not_awaited()


class DeliveryOutputTests(unittest.TestCase):
    def test_missing_target_cli_exits_normally_without_claiming_success(self):
        provider = MagicMock()
        provider.get_provider_targets = AsyncMock(return_value=[])
        provider.activate_target = AsyncMock()
        with patch.object(util, "get_target_management_browser", new=AsyncMock(return_value=provider)):
            output = io.StringIO()
            with redirect_stdout(output):
                self.assertEqual(cli.main(["tabs_activate", "--target-id", "35"]), 0)
        self.assertIn("未执行（target_unavailable）", output.getvalue())
        self.assertIn("当前会话已无法访问 Target `35`", output.getvalue())
        self.assertNotIn("Browser Page Activated", output.getvalue())
        self.assertNotIn("页面交付提醒", output.getvalue())
        provider.activate_target.assert_not_awaited()

    def test_real_activation_failure_still_exits_nonzero(self):
        provider = MagicMock()
        provider.get_provider_targets = AsyncMock(return_value=[{"targetId": "35"}])
        provider.activate_target = AsyncMock(side_effect=CDPCommandError({"code": -32000, "message": "tab_not_owned_by_session"}))
        with patch.object(util, "get_target_management_browser", new=AsyncMock(return_value=provider)):
            output = io.StringIO()
            with redirect_stdout(output):
                self.assertEqual(cli.main(["tabs_activate", "--target-id", "35"]), 1)
        self.assertIn("tab_not_owned_by_session", output.getvalue())
        self.assertNotIn("未执行（target_unavailable）", output.getvalue())

    def test_iab_success_outputs_remind_about_delivery(self):
        result = {
            "targetId": "35", "snapshot": "---\nTitle: Search\nURL: https://example.com",
            "interactive_elements": "0[:] button", "result": "Search",
            "selected_files": [{"name": "report.pdf"}], "data": b"test-image",
        }

        def complete(_action, coroutine):
            coroutine.close()
            return result

        with tempfile.TemporaryDirectory() as tmp, patch.dict(os.environ, {"BROWSER_PLUGIN_MODE": "cdp", "BROWSER_IN_APP_PORT": "53082"}, clear=True), patch.object(util, "_browser_mode", "in_app"), patch.object(browser, "_run_action", side_effect=complete), patch.object(util, "run_coroutine_threadsafe", side_effect=lambda coro: complete("upload_files", coro)):
            calls = (
                (browser.navigate, ("https://example.com",), {}),
                (browser.click, (0,), {}),
                (browser.fill, (0, "text"), {}),
                (browser.select_option, (0,), {"option_text": "value"}),
                (browser.get_interactive_elements, (), {}),
                (browser.execute_script, ("document.title",), {}),
                (browser.upload_files, (0, ["report.pdf"]), {}),
                (browser.screenshot, (), {"output": str(Path(tmp) / "screen.png")}),
            )
            for function, args, kwargs in calls:
                with self.subTest(action=function.__name__):
                    text = function(*args, target_id="35", **kwargs)
                    self.assertEqual(text.count("页面交付提醒"), 1)
                    self.assertIn("--disposition deliverable", text)
                    self.assertIn("Activated 为 true", text)
                    self.assertIn("临时页面无需标记", text)

    def test_activation_success_does_not_imply_retention(self):
        def complete(action, coroutine):
            coroutine.close()
            return {"targetId": "35", "activated": True}
        with patch.dict(os.environ, {"BROWSER_IN_APP_PORT": "53082"}, clear=True), patch.object(util, "_browser_mode", "in_app"), patch.object(browser, "_run_action", side_effect=complete):
            text = browser.tabs_activate("35")
        self.assertIn("Activated: `true`", text)
        self.assertIn("不表示已保留", text)

    def test_legacy_plugin_and_local_browser_do_not_get_iab_rules(self):
        for environment, mode in (
            ({"BROWSER_PLUGIN_MODE": "extension", "BROWSER_IN_APP_PORT": "53082"}, "extension"),
            ({"BROWSER_PLUGIN_MODE": "extension", "BROWSER_IN_APP_PORT": "53082"}, "in_app"),
            ({"BROWSER_EXECUTABLE_PATH": "chrome"}, "cdp"),
        ):
            with patch.dict(os.environ, environment, clear=True), patch.object(util, "_browser_mode", mode):
                self.assertEqual(browser._append_delivery_hint("snapshot"), "snapshot")


if __name__ == "__main__":
    unittest.main()
