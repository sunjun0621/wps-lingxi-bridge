#!/usr/bin/env python3
"""
browser 选路与 CLI 单测

覆盖：
  - 插件 / In-App / 本地 Chromium 三路选路优先级
  - 缺环境变量立即报错（不回落）
  - user_stop 提示
  - 缓存复用与选路变化清缓存
  - cli.py 参数解析与失败 exit code

不依赖真实浏览器或远端 server，全部 mock。
"""
import os
import sys
import tempfile

import asyncio
import json
from unittest.mock import patch, MagicMock, AsyncMock
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

import util
import api
import browser
import cli
from cdp_http import HTTPCDPClient, SessionEndedError, USER_STOP_HINT, _raise_cdp_error


def reset_state():
    util._browser = None
    util._browser_mode = None
    util._last_route = None
    util._tabs_contract_route = None
    util._tabs_contract_ok = False
    browser.mode = "extension"


def make_valid_provider_targets():
    return [
        {
            "tabId": 7,
            "targetId": "target-A",
            "url": "https://example.com/",
            "title": "Example",
            "origin": "user",
            "disposition": "user_keep",
            "leased": False,
            "is_current": True,
            "guestState": "ready",
        }
    ]


def make_mock_browser(healthy=True):
    b = MagicMock()
    b.is_healthy = AsyncMock(return_value=healthy)
    b.create_and_attach_target = AsyncMock()
    b.evaluate = AsyncMock(return_value=None)
    b.ensure_attached_to_page = AsyncMock(return_value=True)
    b._session_id = ""
    b._attached_target_id = "target-current"
    b.attached_target_id = "target-current"
    return b


def _clear_browser_env():
    for key in (
        "BROWSER_PLUGIN_MODE",
        "NATIVE_HOST_PORT",
        "BROWSER_IN_APP_PORT",
        "SESSION_ID",
        "BROWSER_BRIEF",
        "BROWSER_EXECUTABLE_PATH",
    ):
        os.environ.pop(key, None)


def test_extension_route_uses_http_cdp():
    reset_state()
    _clear_browser_env()
    mock_b = make_mock_browser()
    with patch.dict(
        os.environ,
        {
            "BROWSER_PLUGIN_MODE": "extension",
            "NATIVE_HOST_PORT": "38127",
            "SESSION_ID": "nh-test",
            "BROWSER_BRIEF": "demo",
        },
    ):
        with patch.object(util, "HTTPCDPClient") as MockClient:
            with patch.object(util.core, "Browser", return_value=mock_b):
                result = util.run_coroutine_threadsafe(util.get_browser(), timeout=10)

    MockClient.assert_called_once_with(session_id="nh-test", port=38127)
    assert result is mock_b
    assert util._browser_mode == "extension"
    print("✓ test_extension_route_uses_http_cdp")


def test_extension_defaults_native_host_port():
    reset_state()
    _clear_browser_env()
    mock_b = make_mock_browser()
    with patch.dict(
        os.environ, {"BROWSER_PLUGIN_MODE": "extension", "SESSION_ID": "nh-test"}
    ):
        with patch.object(util, "HTTPCDPClient") as MockClient:
            with patch.object(util.core, "Browser", return_value=mock_b):
                util.run_coroutine_threadsafe(util.get_browser(), timeout=10)
    MockClient.assert_called_once_with(session_id="nh-test", port=38127)
    print("✓ test_extension_defaults_native_host_port")


def test_in_app_route_uses_explicit_port():
    reset_state()
    _clear_browser_env()
    mock_b = make_mock_browser()
    mock_client = MagicMock()
    mock_client.session_start = AsyncMock(return_value={})
    with patch.dict(
        os.environ,
        {
            "BROWSER_PLUGIN_MODE": "cdp",
            "BROWSER_IN_APP_PORT": "19090",
            "SESSION_ID": "inapp-1",
            "BROWSER_BRIEF": "task",
            "BROWSER_EXECUTABLE_PATH": "/should/not/use",
        },
    ):
        with patch.object(
            util, "HTTPCDPClient", return_value=mock_client
        ) as MockClient:
            with patch.object(util.core, "Browser", return_value=mock_b):
                with patch.object(util, "ensure_local_chromium_running") as start_local:
                    result = util.run_coroutine_threadsafe(
                        util.get_browser(), timeout=10
                    )

    MockClient.assert_called_once_with(session_id="inapp-1", port=19090)
    mock_client.session_start.assert_awaited_once_with("task")
    start_local.assert_not_called()
    assert result is mock_b
    assert util._browser_mode == "in_app"
    mock_b.ensure_attached_to_page.assert_awaited()
    print("✓ test_in_app_route_uses_explicit_port")


def test_local_chromium_route():
    reset_state()
    _clear_browser_env()
    mock_b = make_mock_browser()
    with patch.dict(os.environ, {"BROWSER_EXECUTABLE_PATH": "/usr/bin/chromium"}):
        with patch.object(
            util, "ensure_local_chromium_running", return_value="http://127.0.0.1:9222"
        ) as start_local:
            with patch.object(
                util.core.Browser, "create", new=AsyncMock(return_value=mock_b)
            ):
                result = util.run_coroutine_threadsafe(util.get_browser(), timeout=10)

    start_local.assert_called_once_with("/usr/bin/chromium")
    assert result is mock_b
    assert util._browser_mode == "cdp"
    print("✓ test_local_chromium_route")


def test_cdp_reconnect_attaches_existing_page():
    """跨进程重连：无 _session_id 时应 attach 到已有 page。"""
    reset_state()
    _clear_browser_env()
    mock_b = make_mock_browser()
    mock_b._session_id = ""
    with patch.dict(os.environ, {"BROWSER_EXECUTABLE_PATH": "/usr/bin/chromium"}):
        with patch.object(
            util, "ensure_local_chromium_running", return_value="http://127.0.0.1:9222"
        ):
            with patch.object(
                util.core.Browser, "create", new=AsyncMock(return_value=mock_b)
            ):
                with patch.object(
                    util, "load_url", return_value="https://www.baidu.com"
                ):
                    util.run_coroutine_threadsafe(util.get_browser(), timeout=10)

    mock_b.ensure_attached_to_page.assert_awaited_once_with(
        "https://www.baidu.com", preferred_target_id=""
    )
    print("✓ test_cdp_reconnect_attaches_existing_page")


def test_ensure_attached_to_page_prefers_saved_url():
    import asyncio
    import core as core_mod

    class FakeSend:
        class Target:
            @staticmethod
            async def getTargets(params=None):
                return {
                    "targetInfos": [
                        {"targetId": "t1", "type": "page", "url": "https://a.example/"},
                        {
                            "targetId": "t2",
                            "type": "page",
                            "url": "https://www.baidu.com/",
                        },
                        {
                            "targetId": "t3",
                            "type": "service_worker",
                            "url": "chrome-extension://x",
                        },
                    ]
                }

            @staticmethod
            async def attachToTarget(params=None):
                return {"sessionId": "sess-" + params["targetId"]}

            @staticmethod
            async def detachFromTarget(params=None):
                return {}

    browser = core_mod.Browser(MagicMock())
    browser._cdp = MagicMock()
    browser._cdp.send = FakeSend()

    ok = asyncio.run(browser.ensure_attached_to_page("https://www.baidu.com/"))
    assert ok is True
    assert browser._session_id == "sess-t2"
    assert browser._attached_target_id == "t2"
    print("✓ test_ensure_attached_to_page_prefers_saved_url")


def test_ensure_attached_to_page_prefers_saved_tab_id():
    import core as core_mod

    class FakeSend:
        class Target:
            @staticmethod
            async def getTargets(params=None):
                return {
                    "targetInfos": [
                        {
                            "targetId": "t1",
                            "type": "page",
                            "url": "https://www.baidu.com/",
                        },
                        {
                            "targetId": "2",
                            "tabId": 2,
                            "type": "page",
                            "url": "https://www.baidu.com/",
                        },
                    ]
                }

            @staticmethod
            async def attachToTarget(params=None):
                return {"sessionId": "sess-" + params["targetId"]}

            @staticmethod
            async def detachFromTarget(params=None):
                return {}

    browser = core_mod.Browser(MagicMock())
    browser._cdp = MagicMock()
    browser._cdp.send = FakeSend()

    ok = asyncio.run(
        browser.ensure_attached_to_page(
            "https://www.baidu.com/", preferred_target_id="2"
        )
    )
    assert ok is True
    assert browser._session_id == "sess-2"
    assert browser._attached_target_id == "2"
    print("✓ test_ensure_attached_to_page_prefers_saved_tab_id")


def test_ensure_attached_to_page_tab_id_mismatch_falls_back_to_url():
    import core as core_mod

    class FakeSend:
        class Target:
            @staticmethod
            async def getTargets(params=None):
                return {
                    "targetInfos": [
                        {"targetId": "t1", "type": "page", "url": "https://a.example/"},
                        {
                            "targetId": "t2",
                            "type": "page",
                            "url": "https://www.baidu.com/",
                        },
                    ]
                }

            @staticmethod
            async def attachToTarget(params=None):
                return {"sessionId": "sess-" + params["targetId"]}

            @staticmethod
            async def detachFromTarget(params=None):
                return {}

    browser = core_mod.Browser(MagicMock())
    browser._cdp = MagicMock()
    browser._cdp.send = FakeSend()

    ok = asyncio.run(
        browser.ensure_attached_to_page(
            "https://www.baidu.com/", preferred_target_id="stale-id"
        )
    )
    assert ok is True
    assert browser._session_id == "sess-t2"
    print("✓ test_ensure_attached_to_page_tab_id_mismatch_falls_back_to_url")


def test_save_and_load_target_id():
    with tempfile.TemporaryDirectory() as temp_dir:
        with patch.dict(os.environ, {"WORKSPACE_DIR": temp_dir}):
            assert util.load_target_id() == ""
            util.save_target_id("2")
            assert util.load_target_id() == "2"
            path = Path(temp_dir) / ".rundata" / "browser" / "target_id.txt"
            assert path.read_text(encoding="utf-8") == "2"
    print("✓ test_save_and_load_target_id")


def test_missing_all_config_errors():
    reset_state()
    _clear_browser_env()
    try:
        util.run_coroutine_threadsafe(util.get_browser(), timeout=10)
        assert False, "should raise"
    except RuntimeError as e:
        assert "BROWSER_EXECUTABLE_PATH" in str(e)
    print("✓ test_missing_all_config_errors")


def test_extension_preferred_over_in_app():
    reset_state()
    _clear_browser_env()
    mock_b = make_mock_browser()
    with patch.dict(
        os.environ,
        {
            "BROWSER_PLUGIN_MODE": "extension",
            "NATIVE_HOST_PORT": "38127",
            "BROWSER_IN_APP_PORT": "19090",
            "SESSION_ID": "nh-test",
            "BROWSER_BRIEF": "demo",
        },
    ):
        with patch.object(util, "HTTPCDPClient") as MockClient:
            with patch.object(util.core, "Browser", return_value=mock_b):
                util.run_coroutine_threadsafe(util.get_browser(), timeout=10)

    MockClient.assert_called_once_with(session_id="nh-test", port=38127)
    assert util._browser_mode == "extension"
    print("✓ test_extension_preferred_over_in_app")


def test_cached_browser_reused():
    reset_state()
    _clear_browser_env()
    mock_b = make_mock_browser()
    util._browser = mock_b
    util._browser_mode = "cdp"
    util._last_route = "cdp:/usr/bin/chromium"
    with patch.dict(os.environ, {"BROWSER_EXECUTABLE_PATH": "/usr/bin/chromium"}):
        with patch.object(util, "ensure_local_chromium_running") as start_local:
            result = util.run_coroutine_threadsafe(util.get_browser(), timeout=10)
    start_local.assert_not_called()
    assert result is mock_b
    print("✓ test_cached_browser_reused")


def test_route_change_clears_cache():
    reset_state()
    _clear_browser_env()
    old = make_mock_browser()
    util._browser = old
    util._browser_mode = "cdp"
    util._last_route = "cdp:/old"
    new_b = make_mock_browser()
    with patch.dict(
        os.environ,
        {
            "BROWSER_PLUGIN_MODE": "extension",
            "NATIVE_HOST_PORT": "38127",
            "SESSION_ID": "nh-new",
            "BROWSER_BRIEF": "x",
        },
    ):
        with patch.object(util, "HTTPCDPClient"):
            with patch.object(util.core, "Browser", return_value=new_b):
                result = util.run_coroutine_threadsafe(util.get_browser(), timeout=10)
    assert result is new_b
    assert util._browser_mode == "extension"
    print("✓ test_route_change_clears_cache")


def test_target_workflow_action_includes_auth_handoff_text_reply_hint():
    """Target 工作流中，navigate 应先 handoff，再文字引导且禁用 ask/manual。"""
    routes = (
        (
            {"BROWSER_PLUGIN_MODE": "cdp", "BROWSER_IN_APP_PORT": "19090"},
            "in_app",
        ),
    )
    for environment, browser_mode in routes:
        reset_state()
        util._browser_mode = browser_mode
        with patch.dict(os.environ, environment, clear=True):
            with patch.object(
                browser,
                "_run_action",
                side_effect=lambda _action, coro: (
                    coro.close(),
                    {"targetId": "target-A", "snapshot": "snapshot"},
                )[1],
            ):
                result = browser.navigate("https://example.com")

        assert "tabs_mark --target-id <target> --disposition handoff" in result
        assert "再直接用文字引导用户" in result
        assert "不要调用 ask_user_question" in result
        assert "重新调用 tabs_list 确认 Target" in result
        for mode_word in ("当前使用浏览器插件", "Extension/IAB", "headless", "有头", "无头"):
            assert mode_word not in result
    print("✓ test_target_workflow_action_includes_auth_handoff_text_reply_hint")


def test_legacy_plugin_auth_hint_skips_target_management():
    reset_state()
    util._browser_mode = "extension"
    # 模拟运行时契约探测失败（旧版插件），提示应走 legacy 文案
    util._tabs_contract_route = "extension"
    util._tabs_contract_ok = False
    with patch.dict(os.environ, {"BROWSER_PLUGIN_MODE": "extension"}, clear=True):
        result = browser._append_runtime_hint("navigate 成功：\nsnapshot")
    assert "直接用文字引导用户" in result
    assert "不要调用 ask_user_question" in result
    assert "get_interactive_elements" in result
    assert "tabs_mark" not in result
    assert "tabs_list" not in result
    assert "不要声称已标记保留页面" in result


def test_in_app_tabs_still_execute_and_report_real_errors():
    from contextlib import redirect_stdout
    from io import StringIO

    reset_state()
    mock_b = make_mock_browser()
    mock_b.get_provider_targets = AsyncMock(return_value=[{"targetId": "A"}])
    mock_b.close_provider_targets = AsyncMock(return_value={
        "success": True, "targets": [{"targetId": "A", "success": True}]
    })
    mock_b.activate_target = AsyncMock()
    mock_b.attach_to_target = AsyncMock()
    mock_b.mark_provider_target = AsyncMock(return_value={
        "targetId": "A", "disposition": "handoff", "activated": True
    })
    with patch.dict(os.environ, {"BROWSER_IN_APP_PORT": "19090"}, clear=True), \
            patch.object(util, "get_browser", new=AsyncMock(return_value=mock_b)):
        for command in (
            ["tabs_list"],
            ["tabs_close", "--target-id", "A"],
            ["tabs_activate", "--target-id", "A"],
            ["tabs_mark", "--target-id", "A", "--disposition", "handoff"],
        ):
            output = StringIO()
            with redirect_stdout(output):
                assert cli.main(command) == 0
            assert "unsupported" not in output.getvalue()
        assert mock_b.get_provider_targets.await_count == 2
        mock_b.close_provider_targets.assert_awaited_once_with(["A"])
        mock_b.activate_target.assert_awaited_once_with("A")
        mock_b.attach_to_target.assert_awaited_once_with("A")
        mock_b.mark_provider_target.assert_awaited_once_with("A", "handoff")

        mock_b.close_provider_targets.side_effect = RuntimeError("target not found")
        output = StringIO()
        with redirect_stdout(output):
            assert cli.main(["tabs_close", "--target-id", "A"]) == 1
        assert "target not found" in output.getvalue()
        assert "失败" in output.getvalue()


def test_legacy_plugin_page_failure_is_not_suppressed():
    from contextlib import redirect_stdout
    from io import StringIO

    with patch.dict(os.environ, {"BROWSER_PLUGIN_MODE": "extension"}, clear=True), \
            patch.object(util, "get_browser", new=AsyncMock(side_effect=RuntimeError("disconnected"))):
        output = StringIO()
        with redirect_stdout(output):
            assert cli.main(["navigate", "--url", "https://example.com"]) == 1
        assert "disconnected" in output.getvalue()
        assert "unsupported" not in output.getvalue()


def test_extension_tabs_contract_probe_enables_tabs():
    """新版插件 tabs_list 契约合法 → 正常返回 browser 并放行 tabs_*。"""
    reset_state()
    mock_b = make_mock_browser()
    mock_b.get_provider_targets = AsyncMock(return_value=make_valid_provider_targets())
    with patch.dict(os.environ, {"BROWSER_PLUGIN_MODE": "extension"}, clear=True), \
            patch.object(util, "get_browser", new=AsyncMock(return_value=mock_b)) as connect:
        assert asyncio.run(util.get_target_management_browser()) is mock_b
        connect.assert_awaited_once_with(ensure_page_target=False)
        mock_b.get_provider_targets.assert_awaited_once()
        util._browser_mode = "extension"
        assert "tabs_mark" in browser._auth_handoff_text_reply_hint()


def test_extension_legacy_plugin_contract_probe_falls_back_to_real_error():
    """旧版插件：探测失败不拦截 tabs_*，真实调用报契约错误并切 legacy 提示。"""
    reset_state()
    mock_b = make_mock_browser()
    contract_error = util.core.ProviderTargetContractError(
        "Provider Target.getTargets 响应缺少 result.targets 数组"
    )
    mock_b.get_provider_targets = AsyncMock(side_effect=contract_error)
    with patch.dict(os.environ, {"BROWSER_PLUGIN_MODE": "extension"}, clear=True), \
            patch.object(util, "get_browser", new=AsyncMock(return_value=mock_b)):
        # 探测只记录结果，不拦截
        assert asyncio.run(util.get_target_management_browser()) is mock_b
        util._browser_mode = "extension"
        assert "跳过 tabs_*" in browser._auth_handoff_text_reply_hint()
        # 后续调用仍会真实执行并抛出契约错误
        try:
            asyncio.run(api.tabs_list())
        except util.core.ProviderTargetContractError:
            pass
        else:
            raise AssertionError("tabs_list 未抛出 ProviderTargetContractError")
        mock_b.get_provider_targets.assert_awaited()


def test_legacy_plugin_tabs_report_unsupported_via_contract_error():
    from contextlib import redirect_stdout, redirect_stderr
    from io import StringIO

    commands = (
        ["tabs_list"],
        ["tabs_close", "--target-id", "A"],
        ["tabs_activate", "--target-id", "A"],
        ["tabs_mark", "--target-id", "A", "--disposition", "deliverable"],
    )
    reset_state()
    mock_b = make_mock_browser()
    contract_error = util.core.ProviderTargetContractError(
        "Provider Target.getTargets 响应缺少 result.targets 数组"
    )
    mock_b.get_provider_targets = AsyncMock(side_effect=contract_error)
    mock_b.close_provider_targets = AsyncMock(side_effect=contract_error)
    mock_b.mark_provider_target = AsyncMock(side_effect=contract_error)
    mock_b.attach_to_target = AsyncMock()
    # Extension takes priority even if Desktop also injects an IAB port.
    with patch.dict(os.environ, {
        "BROWSER_PLUGIN_MODE": "extension", "BROWSER_IN_APP_PORT": "19090"
    }, clear=True), patch.object(util, "get_browser", new=AsyncMock(return_value=mock_b)) as connect:
        for command in commands:
            output, errors = StringIO(), StringIO()
            with redirect_stdout(output), redirect_stderr(errors):
                exit_code = cli.main(command)
            assert exit_code == 0
            body = output.getvalue()
            assert "未执行（unsupported）" in body
            assert "不要重试 tabs_* 命令" in body
            assert " 成功" not in body
        # 每条命令都真实尝试连接过（含一次探测缓存命中后仍执行真实调用）
        assert connect.await_count >= len(commands)


def test_plugin_non_navigate_result_excludes_auth_text_reply_hint():
    """插件提示暂时只由 navigate 返回，click 不追加。"""
    reset_state()
    util._browser_mode = "extension"
    with patch.dict(os.environ, {"BROWSER_PLUGIN_MODE": "extension"}):
        with patch.object(
            browser,
            "_run_action",
            side_effect=lambda _action, coro: (
                coro.close(),
                {
                    "targetId": "target-A",
                    "snapshot": "---\nTitle: Example\nURL: https://example.com",
                },
            )[1],
        ):
            result = browser.click(0)

    assert result == (
        "click 成功：\n"
        "---\n"
        "TargetId: target-A\n"
        "Title: Example\n"
        "URL: https://example.com"
    )
    print("✓ test_plugin_non_navigate_result_excludes_auth_text_reply_hint")


def test_headless_action_result_excludes_plugin_auth_hint():
    """本地无头路由不应改变原有登录接管规则。"""
    reset_state()
    util._browser_mode = "cdp"
    with patch.dict(os.environ, {"BROWSER_PLUGIN_MODE": "cdp"}):
        result = browser._append_runtime_hint("navigate 成功：\nsnapshot")

    assert result == "navigate 成功：\nsnapshot"
    print("✓ test_headless_action_result_excludes_plugin_auth_hint")


def test_explicit_headless_while_plugin_enabled_excludes_plugin_auth_hint():
    """插件开关开启但实际已切到 headless 时，不应误加插件提示。"""
    reset_state()
    util._browser_mode = "cdp"
    with patch.dict(os.environ, {"BROWSER_PLUGIN_MODE": "extension"}):
        result = browser._append_runtime_hint("navigate 成功：\nsnapshot")

    assert result == "navigate 成功：\nsnapshot"
    print("✓ test_explicit_headless_while_plugin_enabled_excludes_plugin_auth_hint")


def test_user_stop_returns_ask_hint():
    """用户停止后应告知模型本轮不要再发起浏览器操作。"""
    reset_state()
    _clear_browser_env()
    mock_b = MagicMock()
    mock_b.is_healthy = AsyncMock(
        side_effect=SessionEndedError(USER_STOP_HINT)
    )
    util._browser = mock_b
    util._browser_mode = "extension"
    util._last_route = "extension"
    with patch.dict(
        os.environ,
        {
            "BROWSER_PLUGIN_MODE": "extension",
            "NATIVE_HOST_PORT": "38127",
            "SESSION_ID": "nh-test",
            "BROWSER_BRIEF": "demo",
        },
    ):
        try:
            util.run_coroutine_threadsafe(util.get_browser(), timeout=10)
            assert False, "should raise"
        except RuntimeError as e:
            msg = str(e)
            assert "用户主动停止了浏览器操作" in msg
            assert "不要再发起新的浏览器操作" in msg
    assert util._browser is None
    print("✓ test_user_stop_returns_ask_hint")


def test_cdp_user_stop_32000_raises_session_ended():
    try:
        _raise_cdp_error({"code": -32000, "message": "user_stop"})
        assert False, "should raise"
    except SessionEndedError as e:
        assert str(e) == USER_STOP_HINT
        assert "用户主动停止了浏览器操作" in str(e)
        assert "本轮对话不要再发起新的浏览器操作" in str(e)
    print("✓ test_cdp_user_stop_32000_raises_session_ended")


def test_cdp_not_allowed_32000_is_not_user_stop():
    try:
        _raise_cdp_error({"code": -32000, "message": "Not allowed"})
        assert False, "should raise"
    except SessionEndedError:
        assert False, "Not allowed 不应视为用户停止"
    except RuntimeError as e:
        assert "Not allowed" in str(e)
    print("✓ test_cdp_not_allowed_32000_is_not_user_stop")


def test_run_action_user_stop_tells_model_not_to_retry():
    async def boom():
        raise SessionEndedError(USER_STOP_HINT)

    result = browser._run_action("click", boom())
    assert result == USER_STOP_HINT
    assert "不要再发起新的浏览器操作" in result
    print("✓ test_run_action_user_stop_tells_model_not_to_retry")


def test_http_cdp_client_explicit_port():
    client = HTTPCDPClient(session_id="s1", port=19090)
    assert client._port == 19090
    assert client._session_id == "s1"
    print("✓ test_http_cdp_client_explicit_port")


def test_http_cdp_client_raw_method_envelope():
    response = MagicMock()
    response.read.return_value = b'{"result":{"targetId":"target-A"}}'
    response.__enter__.return_value = response
    captured = {}

    def fake_urlopen(request, timeout=None):
        captured.update(json.loads(request.data.decode("utf-8")))
        return response

    client = HTTPCDPClient(session_id="trusted-session", port=19090)
    with patch("cdp_http.urllib.request.urlopen", side_effect=fake_urlopen):
        result = asyncio.run(
            client.send_raw_method(
                "mark_target",
                {"targetId": "target-A", "disposition": "handoff"},
            )
        )

    assert captured == {
        "method": "mark_target",
        "params": {"targetId": "target-A", "disposition": "handoff"},
        "session_id": "trusted-session",
    }
    assert result == {"targetId": "target-A"}
    print("✓ test_http_cdp_client_raw_method_envelope")


def test_http_cdp_client_forwards_group_id():
    response = MagicMock()
    response.read.return_value = b'{"result":{}}'
    response.__enter__.return_value = response
    captured = {}

    def fake_urlopen(request, timeout=None):
        captured.update(json.loads(request.data.decode("utf-8")))
        return response

    client = HTTPCDPClient(session_id="sess-1", port=19090)
    with patch.dict(os.environ, {"GROUP_ID": "run-42"}):
        with patch("cdp_http.urllib.request.urlopen", side_effect=fake_urlopen):
            asyncio.run(client.session_start("brief"))

    assert captured["session_id"] == "sess-1"
    assert captured["group_id"] == "run-42"
    assert captured["method"] == "session_start"

    captured.clear()
    with patch.dict(os.environ, {"GROUP_ID": "run-42"}):
        with patch("cdp_http.urllib.request.urlopen", side_effect=fake_urlopen):
            asyncio.run(client.send_raw_method("Browser.getVersion", {}))

    assert captured["session_id"] == "sess-1"
    assert captured["group_id"] == "run-42"
    assert captured["method"] == "Browser.getVersion"
    print("✓ test_http_cdp_client_forwards_group_id")


def test_provider_target_management_contract():
    calls = []
    provider_targets = [
        {
            "tabId": 7,
            "targetId": "target-A",
            "title": "Project",
            "url": "https://example.com/project",
            "origin": "user",
            "disposition": "deliverable",
            "leased": False,
            "is_current": True,
            "guestState": "ready",
        }
    ]
    partial_result = {
        "success": False,
        "targets": [
            {"targetId": "target-A", "success": True},
            {
                "targetId": "target-B",
                "success": False,
                "error": "TARGET_NOT_FOUND",
            },
        ],
    }

    class FakeTarget:
        @staticmethod
        async def getTargets(params=None):
            calls.append(("Target.getTargets", params))
            return {
                "targets": provider_targets,
                "targetInfos": [
                    {
                        "targetId": "target-A",
                        "type": "page",
                        "title": "Project",
                        "url": "https://example.com/project",
                        "attached": False,
                    }
                ],
            }

        @staticmethod
        async def closeTargets(params=None):
            calls.append(("Target.closeTargets", params))
            return partial_result

        @staticmethod
        async def activateTarget(params=None):
            calls.append(("Target.activateTarget", params))
            return {}

    class FakeSend:
        Target = FakeTarget

    class FakeCDP:
        send = FakeSend()
        register = None

        @staticmethod
        async def send_raw_method(method, params=None):
            calls.append((method, params))
            return {
                "targetId": params["targetId"],
                "disposition": params["disposition"],
            }

    managed_browser = util.core.Browser(FakeCDP())
    listed = asyncio.run(managed_browser.get_provider_targets())
    closed = asyncio.run(
        managed_browser.close_provider_targets(["target-A", "target-B"])
    )
    marked = asyncio.run(
        managed_browser.mark_provider_target("target-A", "deliverable")
    )

    assert listed == provider_targets
    assert closed is partial_result
    assert marked == {
        "targetId": "target-A",
        "disposition": "deliverable",
        "activated": True,
    }
    assert calls == [
        ("Target.getTargets", {}),
        ("Target.closeTargets", {"targetIds": ["target-A", "target-B"]}),
        (
            "mark_target",
            {"targetId": "target-A", "disposition": "deliverable"},
        ),
        ("Target.activateTarget", {"targetId": "target-A"}),
    ]
    assert managed_browser._session_id == ""
    assert managed_browser._attached_target_id == ""
    print("✓ test_provider_target_management_contract")


def test_mark_provider_target_preserves_mark_when_activation_fails():
    calls = []

    class FakeTarget:
        @staticmethod
        async def activateTarget(params=None):
            calls.append(("Target.activateTarget", params))
            raise RuntimeError("activation unavailable")

    class FakeSend:
        Target = FakeTarget

    class FakeCDP:
        send = FakeSend()
        register = None

        @staticmethod
        async def send_raw_method(method, params=None):
            calls.append((method, params))
            return {
                "targetId": params["targetId"],
                "disposition": params["disposition"],
            }

    managed_browser = util.core.Browser(FakeCDP())
    marked = asyncio.run(
        managed_browser.mark_provider_target("target-H", "handoff")
    )

    assert calls == [
        (
            "mark_target",
            {"targetId": "target-H", "disposition": "handoff"},
        ),
        ("Target.activateTarget", {"targetId": "target-H"}),
    ]
    assert marked == {
        "targetId": "target-H",
        "disposition": "handoff",
        "activated": False,
        "activationWarning": "activation unavailable",
    }
    print("✓ test_mark_provider_target_preserves_mark_when_activation_fails")


def test_fake_provider_failures_propagate_without_target_fallback():
    calls = []

    class FakeTarget:
        @staticmethod
        async def getTargets(params=None):
            calls.append(("Target.getTargets", params))
            raise RuntimeError("ACCESS_DENIED")

        @staticmethod
        async def closeTargets(params=None):
            calls.append(("Target.closeTargets", params))
            raise ConnectionError("provider disconnected")

        @staticmethod
        async def attachToTarget(params=None):
            calls.append(("Target.attachToTarget", params))
            raise TimeoutError("attach timeout")

    class FakeSend:
        Target = FakeTarget

    class FakeCDP:
        send = FakeSend()
        register = None

        @staticmethod
        async def send_raw_method(method, params=None):
            calls.append((method, params))
            raise RuntimeError("METHOD_NOT_FOUND: mark_target")

    managed_browser = util.core.Browser(FakeCDP())

    failures = (
        (managed_browser.get_provider_targets(), RuntimeError, "ACCESS_DENIED"),
        (
            managed_browser.close_provider_targets(["target-A", "target-B"]),
            ConnectionError,
            "provider disconnected",
        ),
        (
            managed_browser.attach_to_target("target-missing"),
            TimeoutError,
            "attach timeout",
        ),
        (
            managed_browser.mark_provider_target("target-A", "handoff"),
            RuntimeError,
            "METHOD_NOT_FOUND",
        ),
    )
    for coroutine, error_type, message in failures:
        try:
            asyncio.run(coroutine)
            assert False, f"expected {error_type.__name__}"
        except error_type as error:
            assert message in str(error)

    assert calls == [
        ("Target.getTargets", {}),
        ("Target.closeTargets", {"targetIds": ["target-A", "target-B"]}),
        (
            "Target.attachToTarget",
            {"targetId": "target-missing", "flatten": True},
        ),
        ("mark_target", {"targetId": "target-A", "disposition": "handoff"}),
    ]
    assert managed_browser._session_id == ""
    assert managed_browser._attached_target_id == ""
    print("✓ test_fake_provider_failures_propagate_without_target_fallback")


def test_native_get_targets_parsing_remains_unchanged():
    class FakeTarget:
        @staticmethod
        async def getTargets(params=None):
            return {
                "targetInfos": [
                    {"targetId": "page-A", "type": "page", "url": "https://a/"},
                    {
                        "targetId": "internal",
                        "type": "page",
                        "url": "chrome://settings/",
                    },
                    {"targetId": "worker", "type": "worker", "url": "https://a/"},
                ]
            }

    class FakeCDP:
        send = MagicMock()
        send.Target = FakeTarget
        register = None

    managed_browser = util.core.Browser(FakeCDP())
    assert asyncio.run(managed_browser.get_targets()) == [
        {"targetId": "page-A", "type": "page", "url": "https://a/"}
    ]
    print("✓ test_native_get_targets_parsing_remains_unchanged")


def test_tabs_api_deduplicates_and_tabs_mark_reacquires_lease():
    mock_b = make_mock_browser()
    mark_events = []

    async def attach_to_target(target_id):
        mark_events.append(("attach", target_id))

    async def mark_provider_target(target_id, disposition):
        mark_events.append(("mark", target_id, disposition))
        return {"targetId": target_id, "disposition": disposition}

    provider_target = {
        "tabId": 1,
        "targetId": "A",
        "url": "https://example.com/",
        "title": "Example",
        "origin": "user",
        "disposition": "user_keep",
        "leased": False,
        "is_current": True,
        "guestState": "ready",
    }
    mock_b.get_provider_targets = AsyncMock(return_value=[provider_target])
    partial_result = {
        "success": False,
        "targets": [
            {"targetId": "A", "success": True},
            {"targetId": "B", "success": False, "error": "TARGET_NOT_FOUND"},
        ],
    }
    mock_b.close_provider_targets = AsyncMock(return_value=partial_result)
    mock_b.activate_target = AsyncMock(return_value=None)
    mock_b.attach_to_target = AsyncMock(side_effect=attach_to_target)
    mock_b.mark_provider_target = AsyncMock(side_effect=mark_provider_target)

    with patch.object(
        util, "get_target_management_browser", new=AsyncMock(return_value=mock_b)
    ):
        listed = asyncio.run(api.tabs_list())
        one = asyncio.run(api.tabs_close(["A"]))
        many = asyncio.run(api.tabs_close(["A", "B", "A", "B"]))
        activated = asyncio.run(api.tabs_activate(" A "))
        marked = asyncio.run(api.tabs_mark("A", "handoff"))

    assert listed == {"targets": [provider_target]}
    assert one is partial_result
    assert many is partial_result
    assert activated == {"targetId": "A", "activated": True}
    assert marked == {"targetId": "A", "disposition": "handoff"}
    assert mock_b.close_provider_targets.await_args_list[0].args == (["A"],)
    assert mock_b.close_provider_targets.await_args_list[1].args == (["A", "B"],)
    mock_b.activate_target.assert_awaited_once_with("A")
    assert mark_events == [("attach", "A"), ("mark", "A", "handoff")]
    mock_b.ensure_attached_to_page.assert_not_called()
    print("✓ test_tabs_api_deduplicates_and_tabs_mark_reacquires_lease")


def test_tabs_mark_does_not_mark_when_reattach_fails():
    mock_b = make_mock_browser()
    mock_b.attach_to_target = AsyncMock(
        side_effect=RuntimeError("tab_not_available")
    )
    mock_b.mark_provider_target = AsyncMock()

    with patch.object(
        util, "get_target_management_browser", new=AsyncMock(return_value=mock_b)
    ):
        try:
            asyncio.run(api.tabs_mark("A", "handoff"))
            assert False, "tabs_mark should propagate attach failures"
        except RuntimeError as error:
            assert str(error) == "tab_not_available"

    mock_b.mark_provider_target.assert_not_awaited()
    print("✓ test_tabs_mark_does_not_mark_when_reattach_fails")


def test_tabs_list_formats_multiple_pages_as_markdown():
    result = {
        "targets": [
            {
                "tabId": 1,
                "targetId": "target-A",
                "title": "Baidu",
                "url": "https://www.baidu.com",
                "origin": "user",
                "disposition": "deliverable",
                "leased": False,
                "is_current": True,
                "guestState": "ready",
            },
            {
                "tabId": 2,
                "targetId": "target-B",
                "title": "GitHub",
                "url": "https://github.com",
                "origin": "agent",
                "disposition": "user_keep",
                "leased": True,
                "is_current": False,
                "guestState": "ready",
            },
        ]
    }

    assert browser._format_tabs_list_result(result) == (
        "### Browser Pages\n"
        "\n"
        "Total open pages: 2\n"
        "\n"
        "#### Page 1\n"
        "\n"
        "- Target ID: `target-A`\n"
        "- Title: `Baidu`\n"
        "- URL: [https://www.baidu.com](https://www.baidu.com)\n"
        "- Source: `user`\n"
        "- Disposition: `deliverable`\n"
        "- Is Current: `true`\n"
        "\n"
        "#### Page 2\n"
        "\n"
        "- Target ID: `target-B`\n"
        "- Title: `GitHub`\n"
        "- URL: [https://github.com](https://github.com)\n"
        "- Source: `agent`\n"
        "- Disposition: `user_keep`\n"
        "- Is Current: `false`"
    )
    assert "Attached" not in browser._format_tabs_list_result(result)
    print("✓ test_tabs_list_formats_multiple_pages_as_markdown")


def test_tabs_list_formats_empty_page_list_as_markdown():
    assert browser._format_tabs_list_result({"targets": []}) == (
        "### Browser Pages\n\nTotal open pages: 0"
    )
    print("✓ test_tabs_list_formats_empty_page_list_as_markdown")


def test_tabs_activate_formats_success_as_markdown():
    assert browser._format_tabs_activate_result(
        {"targetId": "target-A", "activated": True}
    ) == (
        "### Browser Page Activated\n"
        "\n"
        "- Target ID: `target-A`\n"
        "- Activated: `true`"
    )
    print("✓ test_tabs_activate_formats_success_as_markdown")


def test_tabs_mark_formats_success_as_markdown():
    result = {
        "targetId": "5",
        "disposition": "handoff",
        "activated": True,
    }
    assert browser._format_tabs_mark_result(result) == (
        "### Browser Page Marked\n"
        "\n"
        "- Target ID: `5`\n"
        "- Disposition: `handoff`\n"
        "- Activated: `true`"
    )
    print("✓ test_tabs_mark_formats_success_as_markdown")


def test_tabs_mark_formats_activation_warning_as_markdown():
    result = {
        "targetId": "5",
        "disposition": "handoff",
        "activated": False,
        "activationWarning": "activation unavailable",
    }
    assert browser._format_tabs_mark_result(result) == (
        "### Browser Page Marked\n"
        "\n"
        "- Target ID: `5`\n"
        "- Disposition: `handoff`\n"
        "- Activated: `false`\n"
        "- Activation Warning: `activation unavailable`"
    )
    print("✓ test_tabs_mark_formats_activation_warning_as_markdown")


def test_tabs_close_formats_partial_failure_as_markdown():
    result = {
        "success": False,
        "targets": [
            {"targetId": "12", "success": True},
            {
                "targetId": "15",
                "success": False,
                "error": "TARGET_NOT_FOUND",
            },
        ],
    }
    assert browser._format_tabs_close_result(result) == (
        "### Browser Pages Close Result\n"
        "\n"
        "- Overall Success: `false`\n"
        "- Total Targets: `2`\n"
        "- Closed Successfully: `1`\n"
        "- Failed to Close: `1`\n"
        "\n"
        "#### Target 1\n"
        "\n"
        "- Target ID: `12`\n"
        "- Success: `true`\n"
        "\n"
        "#### Target 2\n"
        "\n"
        "- Target ID: `15`\n"
        "- Success: `false`\n"
        "- Error: `TARGET_NOT_FOUND`"
    )
    print("✓ test_tabs_close_formats_partial_failure_as_markdown")


def test_tabs_close_formats_complete_success_as_markdown():
    result = {
        "success": True,
        "targets": [
            {"targetId": "12", "success": True},
            {"targetId": "15", "success": True},
        ],
    }
    output = browser._format_tabs_close_result(result)
    assert "- Overall Success: `true`" in output
    assert "- Total Targets: `2`" in output
    assert "- Closed Successfully: `2`" in output
    assert "- Failed to Close: `0`" in output
    assert "- Error:" not in output
    print("✓ test_tabs_close_formats_complete_success_as_markdown")


def test_tabs_mark_rejects_invalid_disposition_before_provider():
    provider = AsyncMock()
    with patch.object(util, "get_target_management_browser", new=provider):
        try:
            asyncio.run(api.tabs_mark("A", "keep"))
            assert False, "keep should be rejected"
        except ValueError as error:
            assert "deliverable" in str(error) and "handoff" in str(error)
    provider.assert_not_awaited()
    print("✓ test_tabs_mark_rejects_invalid_disposition_before_provider")


def test_tabs_reject_empty_target_ids_before_provider():
    provider = AsyncMock()
    with patch.object(util, "get_target_management_browser", new=provider):
        for coroutine in (
            api.tabs_close([]),
            api.tabs_close(["A", "  "]),
            api.tabs_activate(" "),
            api.tabs_mark(" ", "deliverable"),
        ):
            try:
                asyncio.run(coroutine)
                assert False, "empty target ids should be rejected"
            except ValueError as error:
                assert "targetId" in str(error)
    provider.assert_not_awaited()
    print("✓ test_tabs_reject_empty_target_ids_before_provider")


def test_target_management_rejects_headless_without_connecting():
    reset_state()
    _clear_browser_env()
    with patch.dict(
        os.environ,
        {"BROWSER_EXECUTABLE_PATH": "/usr/bin/chromium"},
    ):
        with patch.object(util, "get_browser", new=AsyncMock()) as get_browser:
            for coroutine in (
                api.tabs_list(),
                api.tabs_close(["A"]),
                api.tabs_activate("A"),
                api.tabs_mark("A", "deliverable"),
            ):
                try:
                    asyncio.run(coroutine)
                    assert False, "headless should be unsupported"
                except RuntimeError as error:
                    assert "不支持" in str(error)
                    assert "多标签页命令" in str(error)
    get_browser.assert_not_awaited()
    print("✓ test_target_management_rejects_headless_without_connecting")


def test_in_app_target_management_does_not_restore_or_attach():
    reset_state()
    _clear_browser_env()
    mock_b = make_mock_browser()
    util._browser = mock_b
    util._browser_mode = "in_app"
    util._last_route = "in_app:19090"
    with patch.dict(os.environ, {"BROWSER_IN_APP_PORT": "19090"}):
        result = asyncio.run(util.get_target_management_browser())

    assert result is mock_b
    mock_b.ensure_attached_to_page.assert_not_called()
    print("✓ test_in_app_target_management_does_not_restore_or_attach")


def test_cli_target_management_arguments():
    with patch.object(cli.browser, "tabs_list", return_value="tabs_list 成功：\n{}"):
        assert cli.main(["tabs_list"]) == 0

    with patch.object(
        cli.browser, "tabs_close", return_value="tabs_close 成功：\n{}"
    ) as close:
        assert cli.main(["tabs_close", "--target-id", "A"]) == 0
        assert (
            cli.main(
                [
                    "tabs_close",
                    "--target-id",
                    "A",
                    "--target-id",
                    "B",
                    "--target-id",
                    "A",
                ]
            )
            == 0
        )
    assert close.call_args_list[0].args == (["A"],)
    assert close.call_args_list[1].args == (["A", "B", "A"],)

    with patch.object(
        cli.browser, "tabs_activate", return_value="tabs_activate 成功：\n{}"
    ) as activate:
        assert cli.main(["tabs_activate", "--target-id", "A"]) == 0
    activate.assert_called_once_with("A")

    with patch.object(
        cli.browser, "tabs_mark", return_value="tabs_mark 成功：\n{}"
    ) as mark:
        assert (
            cli.main(
                [
                    "tabs_mark",
                    "--target-id",
                    "A",
                    "--disposition",
                    "deliverable",
                ]
            )
            == 0
        )
    mark.assert_called_once_with("A", "deliverable")

    parser = cli.build_parser()
    try:
        parser.parse_args(["tabs_close"])
        assert False, "tabs_close should require at least one target id"
    except SystemExit as error:
        assert error.code == 2
    try:
        parser.parse_args(["tabs_activate"])
        assert False, "tabs_activate should require a target id"
    except SystemExit as error:
        assert error.code == 2
    try:
        parser.parse_args(
            ["tabs_mark", "--target-id", "A", "--disposition", "keep"]
        )
        assert False, "keep should not be accepted by CLI"
    except SystemExit as error:
        assert error.code == 2
    print("✓ test_cli_target_management_arguments")


def test_cli_page_actions_forward_target_id():
    cases = [
        (
            ["navigate", "--url", "https://example.com", "--target-id", "A"],
            "navigate",
            ("https://example.com",),
            {"target_id": "A"},
        ),
        (
            ["click", "--target-id", "A", "--element-index", "2"],
            "click",
            (2,),
            {"target_id": "A"},
        ),
        (
            [
                "fill",
                "--target-id",
                "A",
                "--element-index",
                "2",
                "--text",
                "hello",
                "--press-enter",
            ],
            "fill",
            (2, "hello"),
            {"press_enter": True, "target_id": "A"},
        ),
        (
            [
                "upload_files",
                "--target-id",
                "A",
                "--element-index",
                "2",
                "--files",
                "/tmp/a.txt",
            ],
            "upload_files",
            (2, ["/tmp/a.txt"]),
            {"target_id": "A"},
        ),
        (
            [
                "select_option",
                "--target-id",
                "A",
                "--element-index",
                "2",
                "--option-text",
                "One",
            ],
            "select_option",
            (2,),
            {
                "option_text": "One",
                "option_value": None,
                "option_index": None,
                "target_id": "A",
            },
        ),
        (
            ["get_interactive_elements", "--target-id", "A"],
            "get_interactive_elements",
            (),
            {"target_id": "A"},
        ),
        (
            ["execute_script", "--target-id", "A", "--script", "1 + 1"],
            "execute_script",
            ("1 + 1",),
            {"target_id": "A"},
        ),
        (
            ["screenshot", "--target-id", "A", "--output", "shot.png"],
            "screenshot",
            (),
            {"output": "shot.png", "full_page": False, "target_id": "A"},
        ),
    ]

    for argv, method_name, expected_args, expected_kwargs in cases:
        with patch.object(
            cli.browser, method_name, return_value=f"{method_name} 成功：\nok"
        ) as method:
            assert cli.main(argv) == 0
        assert method.call_args.args == expected_args
        assert method.call_args.kwargs == expected_kwargs
    print("✓ test_cli_page_actions_forward_target_id")


def test_page_action_text_outputs_include_target_id():
    snapshot_result = {
        "targetId": "A",
        "snapshot": "---\nTitle: Example\nURL: https://example.com\n---\nbody",
    }
    for method_name, args in (
        ("navigate", ("https://example.com",)),
        ("click", (1,)),
        ("fill", (1, "text")),
        ("select_option", (1,)),
    ):
        with patch.object(
            browser,
            "_run_action",
            side_effect=lambda _action, coro: (coro.close(), snapshot_result)[1],
        ):
            result = getattr(browser, method_name)(*args, target_id="A")
        assert "---\nTargetId: A\nTitle: Example" in result

    upload_result = {
        **snapshot_result,
        "selected_files": [{"name": "report.pdf"}],
    }
    with patch.object(
        browser.util,
        "run_coroutine_threadsafe",
        side_effect=lambda coro: (coro.close(), upload_result)[1],
    ):
        result = browser.upload_files(1, ["/tmp/report.pdf"], target_id="A")
    assert "---\nTargetId: A\nTitle: Example" in result

    results = (
        (
            "get_interactive_elements",
            (),
            {"targetId": "A", "interactive_elements": []},
        ),
        ("execute_script", ("1 + 1",), {"targetId": "A", "result": 2}),
    )
    for method_name, args, action_result in results:
        with patch.object(
            browser,
            "_run_action",
            side_effect=lambda _action, coro: (coro.close(), action_result)[1],
        ):
            result = getattr(browser, method_name)(*args, target_id="A")
        assert "TargetId: A" in result
    print("✓ test_page_action_text_outputs_include_target_id")


def test_provider_page_actions_attach_and_return_actual_target():
    managed_browser = make_mock_browser()

    async def attach(target_id):
        managed_browser.attached_target_id = target_id

    managed_browser.attach_to_target = AsyncMock(side_effect=attach)
    managed_browser.navigate_attached_target = AsyncMock()
    managed_browser.create_and_attach_target = AsyncMock()
    managed_browser.click_interactive_element = AsyncMock()
    managed_browser.fill_interactive_element = AsyncMock()
    managed_browser.set_files_on_related_input = AsyncMock(
        return_value={"source": "self"}
    )
    managed_browser.set_files_via_chooser = AsyncMock()
    managed_browser.call_function_on_interactive_element = AsyncMock()
    managed_browser.evaluate = AsyncMock(return_value=2)
    managed_browser.screenshot = AsyncMock(return_value=b"image")

    async def call_extension(_name, action):
        if action == "extract_elements":
            return [{"index": 0}]
        return "snapshot-A"

    managed_browser.call_extension = AsyncMock(side_effect=call_extension)

    with tempfile.NamedTemporaryFile() as upload:
        upload.write(b"payload")
        upload.flush()
        with patch.object(api.util, "is_provider_browser_route", return_value=True):
            with patch.object(
                api.util,
                "get_browser",
                new=AsyncMock(return_value=managed_browser),
            ) as get_browser:
                with patch.object(
                    api.util, "wait_dom_content_loaded", new=AsyncMock()
                ):
                    with patch.object(api.util, "wait_dom_stable", new=AsyncMock()):
                        with patch.object(
                            api.util, "BrowserAutoSwitchTarget"
                        ) as auto_switch:
                            results = [
                                asyncio.run(
                                    api.navigate(
                                        "https://example.com",
                                        target_id="A",
                                        with_snapshot=True,
                                    )
                                ),
                                asyncio.run(
                                    api.click(1, target_id="A", with_snapshot=True)
                                ),
                                asyncio.run(
                                    api.fill(1, "text", target_id="A")
                                ),
                                asyncio.run(
                                    api.upload_files(
                                        1, [upload.name], target_id="A"
                                    )
                                ),
                                asyncio.run(
                                    api.select_option(
                                        1, option_text="One", target_id="A"
                                    )
                                ),
                                asyncio.run(api.get_interactive_elements("A")),
                                asyncio.run(api.execute_script("1 + 1", "A")),
                                asyncio.run(api.screenshot(target_id="A")),
                            ]

    assert [result["targetId"] for result in results] == ["A"] * 8
    assert results[0]["snapshot"] == "snapshot-A"
    assert results[5]["interactive_elements"] == [{"index": 0}]
    assert results[6]["result"] == 2
    assert results[7]["data"] == b"image"
    assert managed_browser.attach_to_target.await_count == 8
    managed_browser.create_and_attach_target.assert_not_awaited()
    managed_browser.navigate_attached_target.assert_awaited_once_with(
        "https://example.com"
    )
    for call in get_browser.await_args_list:
        assert call.kwargs == {"ensure_page_target": False}
    auto_switch.assert_not_called()
    print("✓ test_provider_page_actions_attach_and_return_actual_target")


def test_provider_navigate_without_target_creates_new_page():
    managed_browser = make_mock_browser()

    async def create(url):
        managed_browser.attached_target_id = "new-target"
        return "new-target"

    managed_browser.create_and_attach_target = AsyncMock(side_effect=create)
    managed_browser.navigate_attached_target = AsyncMock()
    managed_browser.call_extension = AsyncMock(return_value="new snapshot")
    with patch.object(api.util, "is_provider_browser_route", return_value=True):
        with patch.object(
            api.util, "get_browser", new=AsyncMock(return_value=managed_browser)
        ) as get_browser:
            with patch.object(api.util, "wait_dom_content_loaded", new=AsyncMock()):
                result = asyncio.run(
                    api.navigate("https://example.com", with_snapshot=True)
                )

    assert result == {"targetId": "new-target", "snapshot": "new snapshot"}
    get_browser.assert_awaited_once_with(ensure_page_target=False)
    managed_browser.create_and_attach_target.assert_awaited_once_with(
        "https://example.com"
    )
    managed_browser.attach_to_target.assert_not_called()
    managed_browser.navigate_attached_target.assert_not_awaited()
    print("✓ test_provider_navigate_without_target_creates_new_page")


def test_create_and_attach_target_returns_real_target_id():
    calls = []

    class FakeTarget:
        @staticmethod
        async def createTarget(params=None):
            calls.append(("Target.createTarget", params))
            return {"targetId": "new-target"}

        @staticmethod
        async def attachToTarget(params=None):
            calls.append(("Target.attachToTarget", params))
            return {"sessionId": "page-session"}

    class FakePage:
        @staticmethod
        async def navigate(params=None, session_id=""):
            calls.append(("Page.navigate", params, session_id))
            return {}

    class FakeSend:
        Target = FakeTarget
        Page = FakePage

    class FakeCDP:
        send = FakeSend()
        register = None

    managed_browser = util.core.Browser(FakeCDP())
    target_id = asyncio.run(
        managed_browser.create_and_attach_target("https://example.com")
    )

    assert target_id == "new-target"
    assert managed_browser.attached_target_id == "new-target"
    assert calls == [
        ("Target.createTarget", {"url": "about:blank"}),
        (
            "Target.attachToTarget",
            {"targetId": "new-target", "flatten": True},
        ),
        ("Page.navigate", {"url": "https://example.com"}, "page-session"),
    ]
    print("✓ test_create_and_attach_target_returns_real_target_id")


def test_attach_failure_clears_previous_target_without_fallback():
    calls = []

    class FakeTarget:
        @staticmethod
        async def detachFromTarget(params=None):
            calls.append(("Target.detachFromTarget", params))
            return {}

        @staticmethod
        async def attachToTarget(params=None):
            calls.append(("Target.attachToTarget", params))
            raise RuntimeError("TARGET_NOT_FOUND")

    class FakeSend:
        Target = FakeTarget

    class FakeCDP:
        send = FakeSend()
        register = None

    managed_browser = util.core.Browser(FakeCDP())
    managed_browser._session_id = "old-session"
    managed_browser._attached_target_id = "old-target"
    try:
        asyncio.run(managed_browser.attach_to_target("missing-target"))
        assert False, "attach should fail"
    except RuntimeError as error:
        assert "TARGET_NOT_FOUND" in str(error)

    assert managed_browser.attached_target_id == ""
    assert managed_browser._session_id == ""
    assert calls == [
        ("Target.detachFromTarget", {"sessionId": "old-session"}),
        (
            "Target.attachToTarget",
            {"targetId": "missing-target", "flatten": True},
        ),
    ]
    print("✓ test_attach_failure_clears_previous_target_without_fallback")


def test_provider_page_actions_require_target_before_browser_side_effects():
    factories = [
        lambda: api.click(1),
        lambda: api.fill(1, "text"),
        lambda: api.select_option(1, option_text="One"),
        lambda: api.get_interactive_elements(),
        lambda: api.execute_script("1 + 1"),
        lambda: api.screenshot(),
    ]
    with patch.object(api.util, "is_provider_browser_route", return_value=True):
        with patch.object(api.util, "get_browser", new=AsyncMock()) as get_browser:
            for factory in factories:
                try:
                    asyncio.run(factory())
                    assert False, "Provider action without targetId should fail"
                except ValueError as error:
                    assert "必须指定 targetId" in str(error)
    get_browser.assert_not_awaited()

    with tempfile.NamedTemporaryFile() as upload:
        upload.write(b"payload")
        upload.flush()
        with patch.object(api.util, "is_provider_browser_route", return_value=True):
            with patch.object(api.util, "get_browser", new=AsyncMock()) as get_browser:
                try:
                    asyncio.run(api.upload_files(1, [upload.name]))
                    assert False, "Provider upload without targetId should fail"
                except ValueError as error:
                    assert "必须指定 targetId" in str(error)
        get_browser.assert_not_awaited()
    print("✓ test_provider_page_actions_require_target_before_browser_side_effects")


def test_failed_explicit_attach_does_not_fallback_or_operate_other_page():
    managed_browser = make_mock_browser()
    managed_browser.attach_to_target = AsyncMock(
        side_effect=RuntimeError("TARGET_NOT_FOUND")
    )
    managed_browser.click_interactive_element = AsyncMock()
    managed_browser.ensure_attached_to_page = AsyncMock()
    with patch.object(api.util, "is_provider_browser_route", return_value=True):
        with patch.object(
            api.util, "get_browser", new=AsyncMock(return_value=managed_browser)
        ):
            try:
                asyncio.run(api.click(1, target_id="missing"))
                assert False, "failed attach should abort"
            except RuntimeError as error:
                assert "TARGET_NOT_FOUND" in str(error)

    managed_browser.click_interactive_element.assert_not_awaited()
    managed_browser.ensure_attached_to_page.assert_not_awaited()
    print("✓ test_failed_explicit_attach_does_not_fallback_or_operate_other_page")


def test_headless_page_action_without_target_keeps_legacy_routing():
    managed_browser = make_mock_browser()
    managed_browser.fill_interactive_element = AsyncMock()

    class DummySwitch:
        async def __aenter__(self):
            return managed_browser

        async def __aexit__(self, exc_type, exc, tb):
            return False

    with patch.object(api.util, "is_provider_browser_route", return_value=False):
        with patch.object(
            api.util, "get_browser", new=AsyncMock(return_value=managed_browser)
        ) as get_browser:
            with patch.object(
                api.util, "BrowserAutoSwitchTarget", return_value=DummySwitch()
            ) as auto_switch:
                result = asyncio.run(api.fill(1, "text"))

    assert result["targetId"] == "target-current"
    get_browser.assert_awaited_once_with(ensure_page_target=True)
    managed_browser.attach_to_target.assert_not_called()
    auto_switch.assert_called_once_with(managed_browser)
    print("✓ test_headless_page_action_without_target_keeps_legacy_routing")


def test_cli_navigate_success_exit_0():
    with patch.object(cli.browser, "navigate", return_value="navigate 成功：\nok"):
        code = cli.main(["navigate", "--url", "https://example.com"])
    assert code == 0
    print("✓ test_cli_navigate_success_exit_0")


def test_cli_success_page_text_with_failure_markers_still_exit_0():
    """Page Text 含「失败：」「超时」时不得误判为非 0 退出码。"""
    snapshot = (
        "navigate 成功：\n"
        "TargetId: target-A\n"
        "---\n"
        "Page Text:\n"
        "登录 失败：密码错误\n"
        "请求 超时\n"
        "操作 失败\n"
    )
    with patch.object(cli.browser, "navigate", return_value=snapshot):
        code = cli.main(["navigate", "--url", "https://example.com"])
    assert code == 0
    print("✓ test_cli_success_page_text_with_failure_markers_still_exit_0")


def test_cli_failure_exit_1():
    with patch.object(cli.browser, "click", return_value="click 失败：\nbad"):
        code = cli.main(["click", "--element-index", "1"])
    assert code == 1
    print("✓ test_cli_failure_exit_1")


def test_cli_timeout_exit_1():
    with patch.object(cli.browser, "navigate", return_value="navigate 超时"):
        code = cli.main(["navigate", "--url", "https://example.com"])
    assert code == 1
    print("✓ test_cli_timeout_exit_1")


def test_cli_select_option_requires_one_matcher():
    code = cli.main(["select_option", "--element-index", "1"])
    assert code == 1
    print("✓ test_cli_select_option_requires_one_matcher")


def test_headless_mode_reuses_cached_browser():
    """选路未变化时复用缓存的本地 Chromium 浏览器，不重新拉起。"""
    reset_state()
    mock_b = make_mock_browser()
    util._browser = mock_b
    util._browser_mode = "cdp"

    with patch.dict(os.environ, {"BROWSER_EXECUTABLE_PATH": "/tmp/chromium"}, clear=False):
        util._last_route = util._current_route()
        result = util.run_coroutine_threadsafe(util.get_browser(), timeout=10)

    assert result is mock_b, "should reuse cached browser when route unchanged"
    print("✓ test_headless_mode_reuses_cached_browser")


def test_dead_browser_cache_recreated():
    reset_state()
    # 缓存的浏览器已被 kill（browser_close 后），is_healthy 返回 False → 重建
    dead_browser = make_mock_browser(healthy=False)
    util._browser = dead_browser
    util._browser_mode = "extension"

    mock_b = make_mock_browser()
    with patch.dict(
        os.environ,
        {
            "BROWSER_PLUGIN_MODE": "extension",
            "NATIVE_HOST_PORT": "38127",
            "SESSION_ID": "nh-test",
        },
    ):
        with patch.object(util, "HTTPCDPClient"):
            with patch.object(util.core, "Browser", return_value=mock_b):
                result = util.run_coroutine_threadsafe(util.get_browser(), timeout=10)

    assert result is not dead_browser, "dead browser should be replaced"
    assert result is mock_b
    assert util._browser_mode == "extension"
    print("✓ test_dead_browser_cache_recreated")


def test_navigate_api_disables_restore_and_opens_only_requested_url():
    mock_browser = make_mock_browser()
    get_browser = AsyncMock(return_value=mock_browser)

    with patch.object(api.util, "is_provider_browser_route", return_value=False):
        with patch.object(api.util, "get_browser", new=get_browser):
            with patch.object(
                api.util,
                "wait_dom_content_loaded",
                new=AsyncMock(),
            ):
                with patch.object(api.util, "persist_attached_page") as persist_page:
                    result = asyncio.run(api.navigate("https://example.com"))

    get_browser.assert_awaited_once_with(ensure_page_target=True)
    mock_browser.create_and_attach_target.assert_awaited_once_with(
        "https://example.com"
    )
    persist_page.assert_called_once_with(mock_browser, "https://example.com")
    assert result["targetId"] == "target-current"
    print("✓ test_navigate_api_disables_restore_and_opens_only_requested_url")


def test_save_url_logs_filesystem_error_without_exposing_path():
    path = MagicMock(spec=Path)
    path.write_text.side_effect = PermissionError("/secret/workspace/url.txt")

    with patch.object(util, "_get_url_path", return_value=path):
        with patch.object(util.logger, "warning") as warning:
            util.save_url("https://example.com")

    warning.assert_called_once_with(
        "Failed to persist browser URL state: %s",
        "PermissionError",
    )
    assert "/secret/workspace" not in str(warning.call_args)
    print("✓ test_save_url_logs_filesystem_error_without_exposing_path")


def test_save_url_does_not_swallow_programming_error():
    path = MagicMock(spec=Path)
    path.write_text.side_effect = TypeError("url must be str")

    with patch.object(util, "_get_url_path", return_value=path):
        try:
            util.save_url(None)
            assert False, "TypeError should propagate"
        except TypeError as error:
            assert str(error) == "url must be str"
    print("✓ test_save_url_does_not_swallow_programming_error")


def test_git_bash_screenshot_path_on_windows():
    actual, display_path = util._normalize_user_output_path(
        "/c/Users/WPS/output/test.png",
        platform="nt",
    )

    assert actual == r"C:\Users\WPS\output\test.png"
    assert display_path == "/c/Users/WPS/output/test.png"
    print("✓ test_git_bash_screenshot_path_on_windows")


def test_git_bash_drive_root_on_windows():
    actual, display_path = util._normalize_user_output_path("/d", platform="nt")

    assert actual == "D:\\"
    assert display_path == "/d"
    print("✓ test_git_bash_drive_root_on_windows")


def test_regular_windows_path_unchanged():
    raw = r"C:\Users\WPS\output\test.png"
    actual, display_path = util._normalize_user_output_path(raw, platform="nt")

    assert actual == raw
    assert display_path == raw
    print("✓ test_regular_windows_path_unchanged")


def test_posix_path_unchanged():
    raw = "/tmp/test.png"
    actual, display_path = util._normalize_user_output_path(raw, platform="posix")

    assert actual == raw
    assert display_path == raw
    print("✓ test_posix_path_unchanged")


def test_screenshot_returns_display_path_without_exposing_absolute_path():
    with tempfile.TemporaryDirectory() as temp_dir:
        actual_path = Path(temp_dir) / "shot.png"

        def fake_run_action(_action, coroutine):
            coroutine.close()
            return {"targetId": "target-A", "data": b"fake-png-data"}

        with patch.object(
            util,
            "resolve_user_output_path",
            return_value=(actual_path, "shot.png"),
        ):
            with patch.object(browser, "_run_action", side_effect=fake_run_action):
                result = browser.screenshot("shot.png")

        assert actual_path.read_bytes() == b"fake-png-data"
        assert result == (
            "screenshot 成功：\nTargetId: target-A\n---\n截图已保存到 shot.png"
        )
        assert temp_dir not in result
    print("✓ test_screenshot_returns_display_path_without_exposing_absolute_path")


def test_actions_expression_uses_runtime_evaluate_payload():
    import core as core_mod

    expr = core_mod._actions_expression(
        "fillInteractiveElement", 4, "hello\nworld", True
    )
    assert expr.startswith("(")
    assert "fillInteractiveElement(4, \"hello\\nworld\", true)" in expr
    assert "function ()" in expr or "function()" in expr
    print("✓ test_actions_expression_uses_runtime_evaluate_payload")


def test_click_fill_trusted_click_go_through_runtime_evaluate():
    import core as core_mod

    expressions: list[str] = []

    class FakeRuntime:
        @staticmethod
        async def evaluate(params=None, session_id=""):
            expressions.append((params or {}).get("expression", ""))
            return {"result": {"value": None}}

    class FakeSend:
        class Runtime:
            evaluate = staticmethod(FakeRuntime.evaluate)

    class FakeCDP:
        send = FakeSend()
        register = None

    browser = core_mod.Browser(FakeCDP())
    browser._session_id = "sess"
    asyncio.run(browser._click_interactive_element_with_dom_guard(2))
    asyncio.run(browser.fill_interactive_element(2, "查询", True))
    asyncio.run(browser.trusted_click_interactive_element(2))

    assert len(expressions) == 3
    assert "clickInteractiveElement(2)" in expressions[0]
    assert "fillInteractiveElement(2, " in expressions[1]
    assert "查询" in expressions[1]
    assert "true)" in expressions[1]
    assert "trustedClickInteractiveElement(2)" in expressions[2]
    for expr in expressions:
        assert "Input.dispatchMouseEvent" not in expr
        assert "Input.dispatchKeyEvent" not in expr
        assert "Input.insertText" not in expr
    print("✓ test_click_fill_trusted_click_go_through_runtime_evaluate")


def test_click_follows_anchor_when_synthetic_click_stays_put():
    import core as core_mod

    navigated: list[str] = []

    class FakeRuntime:
        @staticmethod
        async def evaluate(params=None, session_id=""):
            expr = (params or {}).get("expression", "")
            if "clickInteractiveElement" in expr:
                return {
                    "result": {
                        "value": {
                            "followedHref": "http://tieba.baidu.com/",
                            "urlBefore": "https://www.baidu.com/",
                        }
                    }
                }
            if "location.href" in expr:
                return {"result": {"value": "https://www.baidu.com/"}}
            return {"result": {"value": None}}

    class FakePage:
        @staticmethod
        async def navigate(params=None, session_id=""):
            navigated.append((params or {}).get("url", ""))

    class FakeSend:
        class Runtime:
            evaluate = staticmethod(FakeRuntime.evaluate)

        class Page:
            navigate = staticmethod(FakePage.navigate)

    class FakeCDP:
        send = FakeSend()
        register = None

    browser = core_mod.Browser(FakeCDP())
    browser._session_id = "sess"
    asyncio.run(browser._click_interactive_element_with_dom_guard(3))
    assert navigated == ["http://tieba.baidu.com/"]
    print("✓ test_click_follows_anchor_when_synthetic_click_stays_put")


def test_fill_api_does_not_call_input_cdp():
    mock_b = make_mock_browser()
    mock_b.fill_interactive_element = AsyncMock()
    mock_b.insert_text = AsyncMock()
    mock_b.key_event = AsyncMock()

    async def fake_get_browser(**kwargs):
        return mock_b

    class DummySwitch:
        async def __aenter__(self):
            return mock_b

        async def __aexit__(self, exc_type, exc, tb):
            return False

    with patch.object(util, "is_provider_browser_route", return_value=False):
        with patch.object(util, "get_browser", side_effect=fake_get_browser):
            with patch.object(
                util, "BrowserAutoSwitchTarget", return_value=DummySwitch()
            ):
                asyncio.run(api.fill(1, "abc", press_enter=True))

    mock_b.fill_interactive_element.assert_awaited_once_with(1, "abc", True)
    mock_b.insert_text.assert_not_called()
    mock_b.key_event.assert_not_called()
    print("✓ test_fill_api_does_not_call_input_cdp")


if __name__ == "__main__":
    test_legacy_plugin_auth_hint_skips_target_management()
    test_extension_tabs_contract_probe_enables_tabs()
    test_extension_legacy_plugin_contract_probe_falls_back_to_real_error()
    test_legacy_plugin_tabs_report_unsupported_via_contract_error()
    test_in_app_tabs_still_execute_and_report_real_errors()
    test_legacy_plugin_page_failure_is_not_suppressed()
    test_http_cdp_client_raw_method_envelope()
    test_http_cdp_client_forwards_group_id()
    test_provider_target_management_contract()
    test_mark_provider_target_preserves_mark_when_activation_fails()
    test_fake_provider_failures_propagate_without_target_fallback()
    test_native_get_targets_parsing_remains_unchanged()
    test_tabs_api_deduplicates_and_tabs_mark_reacquires_lease()
    test_tabs_mark_does_not_mark_when_reattach_fails()
    test_tabs_activate_formats_success_as_markdown()
    test_tabs_mark_rejects_invalid_disposition_before_provider()
    test_tabs_reject_empty_target_ids_before_provider()
    test_target_management_rejects_headless_without_connecting()
    test_in_app_target_management_does_not_restore_or_attach()
    test_cli_target_management_arguments()
    test_cli_page_actions_forward_target_id()
    test_cli_navigate_success_exit_0()
    test_cli_success_page_text_with_failure_markers_still_exit_0()
    test_cli_failure_exit_1()
    test_cli_timeout_exit_1()
    test_cli_select_option_requires_one_matcher()
    test_page_action_text_outputs_include_target_id()
    test_provider_page_actions_attach_and_return_actual_target()
    test_provider_navigate_without_target_creates_new_page()
    test_create_and_attach_target_returns_real_target_id()
    test_attach_failure_clears_previous_target_without_fallback()
    test_provider_page_actions_require_target_before_browser_side_effects()
    test_failed_explicit_attach_does_not_fallback_or_operate_other_page()
    test_headless_page_action_without_target_keeps_legacy_routing()
    test_target_workflow_action_includes_auth_handoff_text_reply_hint()
    test_plugin_non_navigate_result_excludes_auth_text_reply_hint()
    test_headless_action_result_excludes_plugin_auth_hint()
    test_explicit_headless_while_plugin_enabled_excludes_plugin_auth_hint()
    test_user_stop_returns_ask_hint()
    test_cdp_user_stop_32000_raises_session_ended()
    test_cdp_not_allowed_32000_is_not_user_stop()
    test_run_action_user_stop_tells_model_not_to_retry()
    test_headless_mode_reuses_cached_browser()
    test_dead_browser_cache_recreated()
    test_navigate_api_disables_restore_and_opens_only_requested_url()
    test_save_url_logs_filesystem_error_without_exposing_path()
    test_save_url_does_not_swallow_programming_error()
    test_ensure_attached_to_page_prefers_saved_tab_id()
    test_ensure_attached_to_page_tab_id_mismatch_falls_back_to_url()
    test_save_and_load_target_id()
    test_git_bash_screenshot_path_on_windows()
    test_git_bash_drive_root_on_windows()
    test_regular_windows_path_unchanged()
    test_posix_path_unchanged()
    test_screenshot_returns_display_path_without_exposing_absolute_path()
    test_actions_expression_uses_runtime_evaluate_payload()
    test_click_fill_trusted_click_go_through_runtime_evaluate()
    test_click_follows_anchor_when_synthetic_click_stays_put()
    test_fill_api_does_not_call_input_cdp()
    print("\n✅ 全部测试通过")
