"""Regression tests for slow pages, transport errors and health diagnostics.

Run with: python -m unittest discover -s skills/browser/scripts -p test_browser_recovery.py
"""

import asyncio
import io
import json
import threading
import unittest
import urllib.error
import urllib.request
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import browser
import cdp_http
import core
import util


class PageWaitTests(unittest.IsolatedAsyncioTestCase):
    async def test_interactive_page_does_not_wait_for_load(self):
        page = MagicMock()
        page.evaluate = AsyncMock(return_value="interactive")
        with patch.object(util, "wait_dom_stable", new=AsyncMock()) as stable:
            await util.wait_dom_content_loaded(page)
        expression = page.evaluate.call_args.args[0]
        self.assertNotIn("Promise", expression)
        self.assertNotIn("addEventListener", expression)
        self.assertFalse(page.evaluate.call_args.kwargs["await_promise"])
        stable.assert_awaited_once_with(page)

    async def test_loading_deadline_counts_query_time(self):
        clock = [0.0]
        page = MagicMock(attached_target_id="A")

        async def query(*args, **kwargs):
            clock[0] += 1.5
            return "loading"

        async def sleep(delay):
            clock[0] += delay

        page.evaluate = AsyncMock(side_effect=query)
        with patch.object(util, "time", SimpleNamespace(monotonic=lambda: clock[0])), patch.object(
            util, "asyncio", SimpleNamespace(wait_for=asyncio.wait_for, sleep=sleep)
        ):
            with self.assertRaisesRegex(RuntimeError, "浏览器通信正常.*TargetId: A"):
                await util.wait_dom_content_loaded(page)
        self.assertLessEqual(page.evaluate.await_count, 9)

    async def test_stability_budget_counts_query_time(self):
        clock = [0.0]
        page = MagicMock()

        async def query(*args, **kwargs):
            clock[0] += 0.8
            return clock[0] * 100

        async def sleep(delay):
            clock[0] += delay

        page.evaluate = AsyncMock(side_effect=query)
        with patch.object(util, "time", SimpleNamespace(monotonic=lambda: clock[0])), patch.object(
            util, "asyncio", SimpleNamespace(wait_for=asyncio.wait_for, sleep=sleep)
        ):
            await util.wait_dom_stable(page, max_wait=2.0)
        self.assertEqual(page.evaluate.await_count, 2)
        self.assertAlmostEqual(clock[0], 2.0)

    async def test_nonresponsive_query_has_wall_clock_limit(self):
        page = MagicMock()

        async def stuck(*args, **kwargs):
            await asyncio.Event().wait()

        page.evaluate = AsyncMock(side_effect=stuck)
        with self.assertRaisesRegex(cdp_http.BrowserConnectionError, "Runtime.evaluate"):
            await util._query_page_state(page, "document.readyState", timeout=0.01)

    async def test_stability_does_not_swallow_connection_failure_or_user_stop(self):
        for error in (
            cdp_http.BrowserConnectionError("socket timeout"),
            cdp_http.SessionEndedError("user stopped"),
        ):
            page = MagicMock()
            page.evaluate = AsyncMock(side_effect=error)
            with self.assertRaises(type(error)):
                await util.wait_dom_stable(page)

    async def test_evaluate_disables_promise_wait_only_when_requested(self):
        client = MagicMock()
        client.send.Runtime.evaluate = AsyncMock(return_value={"result": {"value": "interactive"}})
        page = core.Browser(client)
        await page.evaluate("document.readyState", timeout=1, await_promise=False)
        self.assertFalse(client.send.Runtime.evaluate.call_args.kwargs["params"]["awaitPromise"])
        await page.evaluate("Promise.resolve(1)")
        self.assertTrue(client.send.Runtime.evaluate.call_args.kwargs["params"]["awaitPromise"])


class TransportTests(unittest.IsolatedAsyncioTestCase):
    def test_http_error_preserves_json_reason_and_closes_body(self):
        for status, body in (
            (504, b'{"error":{"code":-32001,"message":"Runtime.evaluate response timeout"}}'),
            (409, b'{"error":{"code":-32005,"message":"session_unhealthy: response timeout"}}'),
            (503, b"not json"),
        ):
            stream = io.BytesIO(body)
            error = urllib.error.HTTPError("http://localhost/cdp", status, "test", {}, stream)
            with patch.object(cdp_http.urllib.request, "urlopen", side_effect=error):
                with self.assertRaises(cdp_http.BrowserConnectionError) as raised:
                    cdp_http._urlopen_json(urllib.request.Request("http://localhost/cdp"), 1)
            self.assertIn(str(status), str(raised.exception))
            if body.startswith(b"{"):
                self.assertIn(json.loads(body)["error"]["message"], str(raised.exception))
            self.assertTrue(stream.closed)

    async def test_http_io_does_not_block_event_loop_and_uses_query_timeout(self):
        ticked = threading.Event()

        def response(*args):
            ticked.wait(1)
            return {"result": {"result": {"value": "interactive"}}}

        async def tick():
            await asyncio.sleep(0.005)
            ticked.set()

        ticker = asyncio.create_task(tick())
        client = cdp_http.HTTPCDPClient(session_id="S", port=1234)
        with patch.object(cdp_http, "_urlopen_json", side_effect=response) as send:
            await client._send("Runtime.evaluate", {"timeout": 1000})
            self.assertTrue(ticked.is_set())
            self.assertEqual(send.call_args.args[1], 1.0)
        await ticker

    async def test_socket_timeout_reports_method_and_stops_retries(self):
        with patch.object(cdp_http, "_urlopen_json", side_effect=TimeoutError("socket timeout")):
            with self.assertRaises(cdp_http.BrowserConnectionError) as raised:
                await cdp_http.HTTPCDPClient("S", 1234)._send("Page.navigate", {})
        output = browser._make_error_message("navigate", raised.exception)
        self.assertIn("Page.navigate", output)
        self.assertIn("本轮停止", output)
        self.assertIn("超时不代表底层操作已取消", output)

    async def test_health_failure_preserves_cdp_code_and_message(self):
        error = cdp_http.CDPCommandError({"code": -32000, "message": "debugger attach rejected"})
        client = MagicMock()
        client.send.Browser.getVersion = AsyncMock(side_effect=error)
        with patch.object(util, "HTTPCDPClient", return_value=client):
            with self.assertRaises(cdp_http.BrowserConnectionError) as raised:
                await util._connect_http_cdp("S", 1234, "插件")
        self.assertIn("-32000", str(raised.exception))
        self.assertIn("debugger attach rejected", str(raised.exception))
        self.assertNotIn("tab 已关闭", str(raised.exception))

    async def test_health_user_stop_is_not_connection_failure(self):
        client = MagicMock()
        client.send.Browser.getVersion = AsyncMock(side_effect=cdp_http.SessionEndedError("user stopped"))
        with patch.object(util, "HTTPCDPClient", return_value=client):
            with self.assertRaises(cdp_http.SessionEndedError):
                await util._connect_http_cdp("S", 1234, "插件")


if __name__ == "__main__":
    unittest.main()
