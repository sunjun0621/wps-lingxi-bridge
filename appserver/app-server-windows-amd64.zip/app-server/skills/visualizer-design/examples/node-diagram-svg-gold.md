# 节点连线图黄金样例（SVG）

支付订单状态机（交互版）：菱形放射布局——中间态"支付中"居上居中、初始"待支付"居下居中、两个结果态居左右、终态"已关闭"靠右下角。每条边短而直，端点全部精确落边，无折线绕行、无穿越。

**布局清单（写代码前先声明，端点由此推导）**：

| 节点 | x | y | w | h | 边缘锚点 |
| --- | --- | --- | --- | --- | --- |
| 待支付 | 305 | 396 | 170 | 68 | 顶边 y=396（x=360 错开中心）；右边缘 x=475（y=430 中心） |
| 支付中 | 305 | 76 | 170 | 68 | 底边 y=144（x=330 / x=450 两处锚点错开） |
| 支付成功 | 85 | 256 | 170 | 68 | 顶边 y=256 |
| 支付失败 | 525 | 256 | 170 | 68 | 顶边 y=256；底边 y=324 |
| 已关闭 | 565 | 396 | 170 | 68 | 左边缘 x=565 |

**端点推导（全部可核对）**：

- 去支付：`M360,396`（待支付顶边）`L360,150`（距支付中底边 144 有 6px gap）
- 超时关闭：`M475,430`（待支付右边缘+垂直中心）`L563,430`（距已关闭左边缘 565 有 2px gap）
- 支付成功：`M330,144`（支付中底边锚点1）`L214,254`（距成功顶边 256 有 2px gap，短斜线不穿任何节点）
- 支付失败：`M450,144`（支付中底边锚点2，与锚点1错开 120px）`L566,254`
- 重试：`M545,324`（失败底边）`L460,394`（距待支付顶边 396 有 2px gap，短斜线）

```html
<div style="width:100%;max-width:780px;margin:0 auto;background-color:transparent;box-sizing:border-box;font-family:'Roboto','PingFang SC','Segoe UI',Arial,sans-serif;">
  <div style="font-size:13px;color:var(--muted-foreground,#6B7280);margin-bottom:8px;">支付订单状态机 · 点击任一状态查看它能转到哪、能做什么（箭头上的文字是触发条件）</div>
  <div style="width:100%;overflow-x:auto;scrollbar-gutter:stable;box-sizing:border-box;">
    <svg viewBox="0 0 780 500" style="width:100%;min-width:640px;height:auto;display:block;" role="img" aria-label="支付订单状态流转图">
      <defs>
        <marker id="arr" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" style="fill:var(--muted-foreground,#9aa3af)"/></marker>
        <marker id="arrOn" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" style="fill:var(--primary,#3f6ad8)"/></marker>
      </defs>
      <g>
        <path id="e-pp" d="M360,396 L360,150" fill="none" style="stroke:var(--muted-foreground,#9aa3af)" stroke-width="1.6" marker-end="url(#arr)"/>
        <text id="e-pp-t" x="380" y="282" font-size="13" style="fill:var(--muted-foreground,#6B7280);paint-order:stroke;stroke:var(--background,#ffffff);stroke-width:2px;">去支付</text>
        <path id="e-pc" d="M475,430 L563,430" fill="none" style="stroke:var(--muted-foreground,#9aa3af)" stroke-width="1.6" marker-end="url(#arr)"/>
        <text id="e-pc-t" x="519" y="420" text-anchor="middle" font-size="13" style="fill:var(--muted-foreground,#6B7280);paint-order:stroke;stroke:var(--background,#ffffff);stroke-width:2px;">超时关闭</text>
        <path id="e-ms" d="M330,144 L214,254" fill="none" style="stroke:var(--muted-foreground,#9aa3af)" stroke-width="1.6" marker-end="url(#arr)"/>
        <text id="e-ms-t" x="248" y="212" font-size="13" style="fill:var(--muted-foreground,#6B7280);paint-order:stroke;stroke:var(--background,#ffffff);stroke-width:2px;">支付成功</text>
        <path id="e-mf" d="M450,144 L566,254" fill="none" style="stroke:var(--muted-foreground,#9aa3af)" stroke-width="1.6" marker-end="url(#arr)"/>
        <text id="e-mf-t" x="532" y="212" font-size="13" style="fill:var(--muted-foreground,#6B7280);paint-order:stroke;stroke:var(--background,#ffffff);stroke-width:2px;">支付失败</text>
        <path id="e-fp" d="M545,324 L460,394" fill="none" style="stroke:var(--muted-foreground,#9aa3af)" stroke-width="1.6" marker-end="url(#arr)"/>
        <text id="e-fp-t" x="502" y="366" font-size="13" style="fill:var(--muted-foreground,#6B7280);paint-order:stroke;stroke:var(--background,#ffffff);stroke-width:2px;">重试</text>
      </g>
      <g class="node" data-id="pending" style="cursor:pointer;">
        <rect x="305" y="396" width="170" height="68" rx="12" style="fill:var(--card,#fff);fill:color-mix(in srgb, var(--viz-series-1,#5b82e8) 14%, var(--card,#fff));stroke:var(--viz-series-1,#5b82e8)" stroke-width="2"/>
        <text x="390" y="424" text-anchor="middle" font-size="16" font-weight="600" style="fill:var(--foreground,#2b4a9e)">待支付</text>
        <text x="390" y="446" text-anchor="middle" font-size="11.5" style="fill:var(--muted-foreground,#6B7280)">去支付 · 超时关闭</text>
      </g>
      <g class="node" data-id="processing" style="cursor:pointer;">
        <rect x="305" y="76" width="170" height="68" rx="12" style="fill:var(--card,#fff);fill:color-mix(in srgb, var(--viz-series-3,#e0a32e) 15%, var(--card,#fff));stroke:var(--viz-series-3,#e0a32e)" stroke-width="2"/>
        <text x="390" y="104" text-anchor="middle" font-size="16" font-weight="600" style="fill:var(--foreground,#8a5a00)">支付中</text>
        <text x="390" y="126" text-anchor="middle" font-size="11.5" style="fill:var(--muted-foreground,#6B7280)">等回调 → 成功 / 失败</text>
      </g>
      <g class="node" data-id="success" style="cursor:pointer;">
        <rect x="85" y="256" width="170" height="68" rx="12" style="fill:var(--card,#fff);fill:color-mix(in srgb, var(--viz-series-2,#52C41A) 14%, var(--card,#fff));stroke:var(--viz-series-2,#52C41A)" stroke-width="2"/>
        <text x="170" y="284" text-anchor="middle" font-size="16" font-weight="600" style="fill:var(--foreground,#2f7a0f)">支付成功</text>
        <text x="170" y="306" text-anchor="middle" font-size="11.5" style="fill:var(--muted-foreground,#6B7280)">终态</text>
      </g>
      <g class="node" data-id="failed" style="cursor:pointer;">
        <rect x="525" y="256" width="170" height="68" rx="12" style="fill:var(--card,#fff);fill:color-mix(in srgb, var(--viz-series-4,#ea6668) 14%, var(--card,#fff));stroke:var(--viz-series-4,#ea6668)" stroke-width="2"/>
        <text x="610" y="284" text-anchor="middle" font-size="16" font-weight="600" style="fill:var(--foreground,#a22c2e)">支付失败</text>
        <text x="610" y="306" text-anchor="middle" font-size="11.5" style="fill:var(--muted-foreground,#6B7280)">可重试</text>
      </g>
      <g class="node" data-id="closed" style="cursor:pointer;">
        <rect x="565" y="396" width="170" height="68" rx="12" style="fill:var(--card,#fff);fill:color-mix(in srgb, var(--muted-foreground,#8a94a3) 15%, var(--card,#fff));stroke:var(--muted-foreground,#8a94a3)" stroke-width="2"/>
        <text x="650" y="424" text-anchor="middle" font-size="16" font-weight="600" style="fill:var(--foreground,#4c555f)">已关闭</text>
        <text x="650" y="446" text-anchor="middle" font-size="11.5" style="fill:var(--muted-foreground,#6B7280)">终态</text>
      </g>
    </svg>
  </div>
  <div id="panel" style="margin-top:12px;padding:14px 16px;border:1px solid var(--border,#e5e5e5);border-radius:12px;background:var(--muted,transparent);box-sizing:border-box;">
    <div id="ptitle" style="font-size:14px;font-weight:600;color:var(--foreground,#1A1B1C);">支付订单状态机</div>
    <div id="pbody" style="margin-top:6px;font-size:13px;line-height:1.6;color:var(--muted-foreground,#6B7280);">五个状态，箭头方向为流转方向、箭头上文字为触发条件。</div>
  </div>
</div>
```

交互增强（可选，点击状态高亮关联边与目标节点、其余降透明度，EDGES/STATES 数据驱动）见本仓库交互要求；静态图可省略 `<script>` 与 `id` 属性。

## 自检记录（生成后逐条核对，不依赖渲染）

| 检查项 | 结果 |
| --- | --- |
| 5 条边端点是否全部落在节点边缘（终点 2~6px 悬停） | 是（396/475/144/324 均为精确边缘值；150/563/254/394 均留 2~6px） |
| 斜线是否穿越节点 | 否（成功/失败两条斜线走在中间空白带） |
| 支付中底边两个锚点是否错开 | 是（x=330 与 x=450，差 120px） |
| 待支付两条出边锚点是否分布不同边缘 | 是（顶边 x=360 / 右边缘 y=430） |
| 窄屏是否横向滚动 | 是（min-width:640px + overflow-x:auto + scrollbar-gutter:stable，横条空间恒定预留，高度不随滚动条出现/消失跳变） |
| 超宽宿主是否限宽 | 是（最外层 width:100%;max-width:780px;margin:0 auto——与 viewBox 宽 780 一致，渲染宽封顶 1:1，字号不随超宽屏放大；窄屏不受影响仍撑满） |
| 颜色是否全部走主题变量 | 是（文字 var(--foreground)/var(--muted-foreground)，结构线 var(--muted-foreground)，节点底 color-mix 双重声明（旧内核回退 var(--card)），边框同系列色变量，白描边 var(--background)，SVG 一律 style= 形式） |
