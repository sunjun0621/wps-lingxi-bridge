# Cowork Widget 主题变量（官方注入）

客户端会在渲染前把宿主当前主题的 CSS 变量注入 renderer 所在的 sandbox iframe（`html[theme-mode='dark']` 管理深色模式，切换后自动同步变量并重新渲染）。变量在 iframe 文档 `:root` 上可用，HTML/CSS/JS 均可读取。服务端生成的 HTML **只引用下面这些官方语义变量**，不要写死浅色/深色值，始终提供 fallback 以兼容预览场景。

## 唯一硬性要求：文字可读

深色模式下文字必须清晰。判断标准是**“文字颜色与所在背景的对比度”**，不只是“用了变量”。**必须使用官方语义变量，禁止自拟变量名**（如 `--tx`/`--tx2`/`--panel`/`--bg`/`--acc` 等客户端不会注入，写了也永远走 fallback、深色下失效）。

## 官方语义变量（首选接口）

| 变量 | 用途 | 典型 fallback |
| --- | --- | --- |
| `--foreground` | 主文字 | `#1f1f1f` |
| `--muted-foreground` | 次要/弱化文字 | `#6b7280` |
| `--background` | 页面/主容器背景 | `#ffffff` |
| `--card` / `--card-foreground` | 卡片背景 / 卡片文字 | `#ffffff` / 主文字 |
| `--muted` / `--muted-foreground` | 弱化区域背景 / 文字 | — |
| `--accent` / `--accent-foreground` | 强调区域背景 / 文字 | — |
| `--primary` / `--primary-foreground` | 主操作色 / 其上文字 | — |
| `--secondary` / `--secondary-foreground` | 次级控件 / 其上文字 | — |
| `--destructive` | 危险操作色 | — |
| `--border` | 通用边框 | `#e5e5e5` |
| `--input` / `--ring` | 输入框 / 聚焦环 | — |

**成对变量必须配对使用**：用了 `--card` 的背景，文字用 `--card-foreground`；用了 `--primary` 的背景，文字用 `--primary-foreground`。保证文字与所在背景同源对比，深色下不会出现“浅字白块”。

### 变量语义误用是高频错误

- `--accent` 是**浅淡强调背景**（悬停、选中态底色），不是强色。**禁止**用它做主按钮填充、强调文字色——亮色下它是浅色，配硬编码 `#fff` 白字直接看不清。
- 主操作按钮（“下一步”“提交”等）：填充 `var(--primary)` + 文字 `var(--primary-foreground)`，这是官方语义的用法。
- `--accent` 上的文字必须用 `var(--accent-foreground)`；任何变量背景上的文字都用对应 `-foreground` 变量，**禁止硬编码 `#fff`/`#1A1B1C`**。

## JS 颜色与图表变量

JS 内的颜色常量禁止硬编码（如 `const ACC='#2E7DBF', INACT='#D3D3D3'`）——字符串色值不随主题切换，深色下组件状态色全部失效。统一用 `token()` 读变量，fallback 只作无变量环境的兜底：

```js
const root = document.documentElement;
const token = (n, fb) => getComputedStyle(root).getPropertyValue(n).trim() || fb;
const ACC = token('--primary', '#2E7DBF');              // 激活/主色
const INACT = token('--muted-foreground', '#9ca3af');    // 未激活
const colors = [token('--viz-series-1','#3b82f6'), token('--viz-series-2','#22c55e')]; // 图表系列色
const isDark = root.getAttribute('theme-mode') === 'dark';
```

图表系列色用 `--viz-series-1` 至 `--viz-series-5`（映射主题 `--chart-1`~`--chart-5`），按序列顺序取色。

## 色块背景与对比度

- 局部色块（圆点、卡片、按钮、描述块）背景用 `var(--card,#ffffff)` / `var(--background,#ffffff)` / `var(--muted)`，**禁止 `#fff` 硬编码**，否则深色下“浅字白块”看不清。
- 强调/主操作色块（如主按钮、激活态）用 `var(--primary)` / `var(--accent)`，其上文字配对应 `-foreground` 变量，保证深浅两种主题下对比度都够。

## 彩色块与分类编码

- **文字色永远用主题变量**（`--foreground`、`--muted-foreground`、各成对 `-foreground`）；彩色只允许出现在背景与装饰上。
- 分类、模块、标签等彩色底：系列色与卡片色混合，底色随主题明暗。**必须双重声明**：先写安全值再写 color-mix——
  `background:var(--card,#ffffff);background:color-mix(in srgb, var(--viz-series-1,#EAA7B2) 22%, var(--card,#ffffff))`（SVG fill 同理）。
  原因：旧内核不解析 `color-mix` 时**整条声明失效，fill/background 回退初始值（黑色）**，不是丢底色——不写前一条，旧内核里节点直接变黑实心。双重声明让旧内核取 `var(--card)`、新内核取 color-mix。文字 `var(--foreground,#1f1f1f)`。
- **禁透明彩底 + 硬编码深字**（`rgba(155,187,244,0.28)` 底 + `color:#1f1f1f`）：含 alpha 的底在深色宿主上自动变暗，深字不跟随，深色下不可读——彩色场景最高频翻车点。
- **禁不透明浅彩底 + 硬编码深字**（`#EAA7B2` 底 + `color:#1f1f1f`）：深色模式下亮块刺眼、与主题断裂。

## SVG 文字与描边

- 一律写成 CSS 样式：`<text style="fill:var(--foreground,#1f1f1f)">`、次要 `style="fill:var(--muted-foreground,#6b7280)"`，或 `fill="currentColor"`。
- **描边克制**：`paint-order:stroke` 的描边颜色用 `var(--background,#ffffff)` 随主题，禁止硬编码 `#fff`；宽度 ≤ 字号 20%，描边只是遮线不是盖字，过宽会在深色下糊住浅色文字。

**禁用表示属性里的 `var()`**：`fill="var(--x,...)"` 不带 `style=` 时 `var()` 不解析，恒为 fallback。SVG 引用变量必须带 `style=` 前缀。
- **线条分两级**：结构线（流程连线、箭头、时序图生命线、箭头线）用 `var(--muted-foreground,#6b7280)` 或系列色——它们承载图形语义，深色下必须可见。**`--border` 只给 UI 装饰线**（卡片描边、分隔线、泳道背景框描边）：深色下 `--border` 是 `#46464e`，与背景 `#18181b` 对比度仅约 1.6:1，叠加 `stroke-dasharray` 虚线与 <2px 线宽后彻底不可见——结构线用它，深色模式直接消失。

## iframe 边界

- iframe 与宿主不是 CSS 继承关系，不能直接用宿主页面的 `var(...)`；变量必须由客户端注入的这份接口提供。
- 不要访问 `window.parent.document`（iframe 为 opaque origin）。
- 图表库若把颜色复制进 JS 配置对象，主题切换后需重新执行图表配置；仅改 CSS 变量不会自动更新已生成的 Canvas。
