"""HTTP 版本的 builtins 函数

通过 HTTP 调用 KDocs API。
"""
import json
import mimetypes
import os
import time
import urllib.parse

import requests

import sys as _sys
from pathlib import Path
_scripts_dir = str(Path(__file__).resolve().parents[2] / "scripts")
if _scripts_dir not in _sys.path:
    _sys.path.insert(0, _scripts_dir)
from wps_http import path_segment

_API_ORIGIN = 'https://www.kdocs.cn'
_API_BASE_URL = f'{_API_ORIGIN}/api/v3/office'
_WEBOFFICE_BRANCH = 'kdocs-amd-t-master-et-agentmode'
_MAX_IMAGE_SIZE = 20 * 1024 * 1024  # 20MB
_MAX_REDIRECTS = 5


def _safe_filename(path: str) -> str:
    name = os.path.basename(path.replace("\\", "/").strip()) or "image.png"
    return name.replace("\x00", "") or "image.png"


def _put_with_redirect_guard(session: requests.Session, url: str, headers: dict, data: bytes) -> requests.Response:
    """PUT 上传，跟随有限次重定向。"""
    current = url
    for _ in range(_MAX_REDIRECTS + 1):
        resp = session.put(current, headers=headers, data=data, timeout=60, allow_redirects=False)
        if not resp.is_redirect:
            return resp
        loc = resp.headers.get("Location")
        if not loc:
            return resp
        current = urllib.parse.urljoin(current, loc)
    raise RuntimeError(f"上传重定向次数超过限制 ({_MAX_REDIRECTS})")


class HTTPBuiltins:
    """HTTP 版本的 builtins 函数"""

    def __init__(self, wps_sid: str, file_id: str):
        self._wps_sid = wps_sid
        self._file_id = file_id
        self._jsa_context = None
        self._http = requests.Session()
        self._http.cookies.set('wps_sid', wps_sid)
        self._http.cookies.set('weboffice_branch', _WEBOFFICE_BRANCH)
        self._http.headers.update({'Origin': _API_ORIGIN})

    def set_jsa_context(self, context: dict) -> None:
        self._jsa_context = context

    def upload_local_image(self, file_path: str) -> str:
        """上传本地图片到当前文档，返回可下载的云端 url（供 tag=url 插图使用）。

        流程：申请地址 → PUT 直传 → complete → shapes 取 url。
        """
        if not file_path or not isinstance(file_path, str):
            raise ValueError("本地图片路径不能为空")
        if not os.path.isfile(file_path):
            raise FileNotFoundError(f"本地图片不存在: {file_path}")

        with open(file_path, "rb") as f:
            file_data = f.read()
        if not file_data:
            raise ValueError(f"本地图片为空: {file_path}")
        if len(file_data) > _MAX_IMAGE_SIZE:
            raise ValueError(f"图片过大 ({len(file_data)} bytes)，上限 {_MAX_IMAGE_SIZE} bytes")

        file_name = _safe_filename(file_path)
        content_type = mimetypes.guess_type(file_name)[0] or "image/png"
        file_size = len(file_data)
        text_hdr = {"Content-Type": "text/plain;charset=UTF-8"}
        link_id = self._file_id

        addr_url = f"{_API_BASE_URL}/file/{path_segment(link_id, name='file_id')}/attachment/upload/address"
        addr_body = json.dumps(
            {"name": file_name, "size": file_size, "content_type": content_type},
            ensure_ascii=False,
        ).encode("utf-8")
        addr_resp = self._http.post(addr_url, data=addr_body, headers=text_hdr, timeout=30)
        addr_resp.raise_for_status()
        addr_data = addr_resp.json()

        request_info = addr_data.get("request") or {}
        upload_url = request_info.get("url")
        upload_headers = dict(request_info.get("headers") or {})
        upload_id = addr_data.get("upload_id")
        send_back_params = addr_data.get("send_back_params") or {}
        if not upload_url or not upload_id:
            raise RuntimeError(f"申请上传地址失败，响应异常: {addr_data}")

        put_headers = dict(upload_headers)
        put_headers["Content-Type"] = content_type
        put_resp = _put_with_redirect_guard(self._http, upload_url, put_headers, file_data)
        put_resp.raise_for_status()

        params_for_complete = {}
        for param_name, source in send_back_params.items():
            if isinstance(source, str) and source.startswith("header."):
                params_for_complete[param_name] = put_resp.headers.get(source[len("header."):], "")
        missing = [k for k, v in params_for_complete.items() if not v]
        if missing:
            raise RuntimeError(f"云存储响应头缺少回调参数: {missing}")

        complete_url = f"{_API_BASE_URL}/file/{path_segment(link_id, name='file_id')}/attachment/upload/complete"
        complete_body = json.dumps(
            {"upload_id": upload_id, "params": params_for_complete},
            ensure_ascii=False,
        ).encode("utf-8")
        complete_resp = self._http.post(complete_url, data=complete_body, headers=text_hdr, timeout=30)
        complete_resp.raise_for_status()
        complete_data = complete_resp.json()
        attachment_id = complete_data.get("attachment_id")
        if not attachment_id:
            raise RuntimeError(f"上传完成回调未返回 attachment_id: {complete_data}")

        shapes_resp = self._http.post(
            f"{_API_BASE_URL}/file/{path_segment(link_id, name='file_id')}/attachment/shapes",
            json={"objects": [{"attachment_id": attachment_id}], "support_webp": False},
            timeout=30,
        )
        shapes_resp.raise_for_status()
        shapes_data = shapes_resp.json()
        image_url = ((shapes_data.get("data") or {}).get(attachment_id) or {}).get("url")
        if not image_url:
            raise RuntimeError(f"shapes 未返回图片 url: {shapes_data}")
        return image_url

    def _core_execute(self, command: str, param_json: str, ex_args_json: str | None = None) -> str:
        param = json.loads(param_json)
        body = {
            "command": command,
            "param": param,
            "use_cache": True,
        }
        if ex_args_json:
            body["exArgs"] = json.loads(ex_args_json)

        resp = self._http.post(
            f'{_API_BASE_URL}/file/{path_segment(self._file_id, name="file_id")}/core/execute',
            json=body,
            timeout=60,
        )
        return resp.text

    def _evaluate_script(self, data_json: str) -> str:
        data = json.loads(data_json)
        script = data.get('script', '')

        url = f'{_API_BASE_URL}/file/{path_segment(self._file_id, name="file_id")}/script?runtime_version=2.0'
        resp = self._http.post(
            url,
            json={
                'script': script,
                'script_name': 'script',
                'file_id': self._file_id,
                'Context': self._jsa_context or {},
            },
            timeout=60,
        )

        if resp.status_code != 200:
            return json.dumps({"success": False, "error": f"HTTP {resp.status_code}: {resp.text}"})

        resp_data = resp.json()
        task_id = resp_data.get('task_id')

        if task_id:
            result = self._poll_task_result(task_id)
            return json.dumps(result)

        return json.dumps({"success": True, "data": self._normalize_script_data(resp_data)})

    @staticmethod
    def _normalize_script_data(data: dict) -> dict:
        """从 script API 返回值中提取 result.return，去除 contextInfo 包装。

        WebOffice /script API 返回: {result: {contextInfo: {...}, return: <脚本return值>}}
        归一化后: {result: <脚本return值>}
        """
        if isinstance(data, dict) and "result" in data:
            result = data["result"]
            if isinstance(result, dict) and "return" in result:
                data = dict(data)
                data["result"] = result["return"]
        return data

    def _poll_task_result(self, task_id: str) -> dict:
        max_poll = 10
        sleep_time = 1
        url_encoded_task_id = urllib.parse.quote(task_id)

        for _ in range(max_poll):
            time.sleep(sleep_time)
            resp = self._http.get(
                f'{_API_ORIGIN}/api/v3/script/task?task_id={url_encoded_task_id}',
                timeout=30,
            )

            if resp.status_code != 200:
                continue

            resp_data = resp.json()
            if resp_data.get('status') == 'finished':
                if resp_data.get('error'):
                    return {"success": False, "error": resp_data['error']}
                return {"success": True, "data": self._normalize_script_data(resp_data.get('data', {}))}

        return {"success": False, "error": "Task timeout"}
