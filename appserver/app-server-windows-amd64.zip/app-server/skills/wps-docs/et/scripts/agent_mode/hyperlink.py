# 依赖说明（拼接执行时已在命名空间中）：
# - json, Any, Optional 等标准库来自 summary.py / _utils.py
# - _Context, _make_setattr_guard, _jsa_result 来自 _utils.py


def _js_nullable(value: Any) -> str:
    if value is None:
        return 'null'
    return json.dumps(value, ensure_ascii=False)


# 供 delete / _queue_update / Range.add_hyperlink 等 JSA 片段复用
_JS_NORM_ADDR = '''
function normAddr(a) {
    return String(a || "").replace(/\\$/g, "").split("!").pop();
}
'''


def _parse_hyperlink_list(res: dict) -> list[dict]:
    if not res.get('success', True):
        print(f"获取超链接失败: {res.get('error', '未知错误')}")
        return []
    data = _jsa_result(res)
    if not isinstance(data, list):
        return []
    return [item for item in data if isinstance(item, dict)]


def _hyperlink_from_info(ctx: _Context, sheet_name: str, info: dict) -> 'Hyperlink':
    return Hyperlink(
        ctx,
        sheet_name,
        int(info.get('index', 0)),
        str(info.get('cell', '')),
        str(info.get('address', '')),
        str(info.get('text', '')),
        str(info.get('subAddress', '')),
        str(info.get('screenTip', '')),
    )


def list_hyperlinks(ctx: _Context, sheet_name: str, range_addr: str | None = None) -> list['Hyperlink']:
    """枚举工作表或区域内的超链接。"""
    sheet_js = json.dumps(sheet_name, ensure_ascii=False)
    if range_addr:
        range_js = json.dumps(range_addr, ensure_ascii=False)
        hls_source = f'sheet.Range({range_js}).Hyperlinks'
    else:
        hls_source = 'sheet.Hyperlinks'

    script = f'''
let sheet = Application.Worksheets.Item({sheet_js});
let hls = {hls_source};
let out = [];
for (let i = 1; i <= hls.Count; i++) {{
    let hl = hls.Item(i);
    out.push({{
        index: i,
        cell: hl.Range.Address(),
        address: hl.Address || "",
        text: hl.TextToDisplay || "",
        subAddress: hl.SubAddress || "",
        screenTip: hl.ScreenTip || ""
    }});
}}
return JSON.stringify(out);
'''
    res = ctx.evaluate_script_v2(script.strip())
    return [_hyperlink_from_info(ctx, sheet_name, info) for info in _parse_hyperlink_list(res)]


def hyperlink_count(ctx: _Context, sheet_name: str) -> int:
    """返回工作表超链接数量。"""
    sheet_js = json.dumps(sheet_name, ensure_ascii=False)
    script = f'''
let sheet = Application.Worksheets.Item({sheet_js});
return sheet.Hyperlinks.Count;
'''
    res = ctx.evaluate_script_v2(script.strip())
    if not res.get('success', True):
        print(f"获取超链接数量失败: {res.get('error', '未知错误')}")
        return 0
    data = _jsa_result(res)
    try:
        return int(data)
    except (TypeError, ValueError):
        return 0


def fetch_workbook_hyperlinks(ctx: _Context, sheet_names: list[str]) -> dict[str, list[dict]]:
    """一次 JSA 扫描多个工作表的超链接，供摘要使用。"""
    if not sheet_names:
        return {}
    names_js = json.dumps(sheet_names, ensure_ascii=False)
    script = f'''
let names = {names_js};
let result = {{}};
for (let n = 0; n < names.length; n++) {{
    let sheetName = names[n];
    let sheet = Application.Worksheets.Item(sheetName);
    let hls = sheet.Hyperlinks;
    let out = [];
    for (let i = 1; i <= hls.Count; i++) {{
        let hl = hls.Item(i);
        out.push({{
            index: i,
            cell: hl.Range.Address(),
            address: hl.Address || "",
            text: hl.TextToDisplay || "",
            subAddress: hl.SubAddress || "",
            screenTip: hl.ScreenTip || ""
        }});
    }}
    result[sheetName] = out;
}}
return JSON.stringify(result);
'''
    res = ctx.evaluate_script_v2(script.strip())
    if not res.get('success', True):
        print(f"获取工作簿超链接摘要失败: {res.get('error', '未知错误')}")
        return {}
    data = _jsa_result(res)
    if not isinstance(data, dict):
        return {}
    return {
        str(name): [item for item in items if isinstance(item, dict)]
        for name, items in data.items()
        if isinstance(items, list)
    }


class Hyperlink:
    """单元格超链接对象，用于读取/修改链接地址与显示文本，或删除链接。

    Note:
        通过 `sheet.hyperlinks()` 或 `range.hyperlinks()` 获取实例。
        本期仅覆盖单元格超链接，不包含形状超链接与 `=HYPERLINK()` 公式。

    Example:
        for hl in sheet.hyperlinks():
            print(hl.cell_address, hl.address, hl.text)
        sheet.range("A1").add_hyperlink("https://www.wps.cn", text="WPS")
        hl = sheet.hyperlinks()[0]
        hl.address = "https://www.kdocs.cn"
        hl.text = "金山文档"
        hl.delete()
    """

    __setattr__ = _make_setattr_guard(
        frozenset([
            '_ctx', '_sheet_name', '_index', '_cell_address',
            '_address', '_text', '_sub_address', '_screen_tip',
            'address', 'text', 'sub_address', 'screen_tip',
        ]),
        ['address', 'text', 'sub_address', 'screen_tip'],
    )

    def __init__(
        self,
        ctx: _Context,
        sheet_name: str,
        index: int,
        cell_address: str,
        address: str = '',
        text: str = '',
        sub_address: str = '',
        screen_tip: str = '',
    ):
        self._ctx = ctx
        self._sheet_name = sheet_name
        self._index = index
        self._cell_address = cell_address
        self._address = address
        self._text = text
        self._sub_address = sub_address
        self._screen_tip = screen_tip

    @property
    def cell_address(self) -> str:
        """超链接所在单元格地址（只读）。"""
        return self._cell_address

    @property
    def address(self) -> str:
        """跳转地址（读写）。"""
        return self._address

    @address.setter
    def address(self, value: str):
        self._queue_update('Address', value)
        self._address = value

    @property
    def text(self) -> str:
        """显示文本（读写）。"""
        return self._text

    @text.setter
    def text(self, value: str):
        self._queue_update('TextToDisplay', value)
        self._text = value

    @property
    def sub_address(self) -> str:
        """文档内子地址，如 `Sheet2!A1`（读写）。"""
        return self._sub_address

    @sub_address.setter
    def sub_address(self, value: str):
        self._queue_update('SubAddress', value)
        self._sub_address = value

    @property
    def screen_tip(self) -> str:
        """鼠标悬停提示（读写）。"""
        return self._screen_tip

    @screen_tip.setter
    def screen_tip(self, value: str):
        self._queue_update('ScreenTip', value)
        self._screen_tip = value

    def delete(self) -> None:
        """删除该超链接，并去掉蓝色下划线等超链接外观（保留单元格文字）。"""
        cell_js = json.dumps(self._cell_address, ensure_ascii=False)
        sheet_js = json.dumps(self._sheet_name, ensure_ascii=False)
        # xlUnderlineStyleNone=-4142, xlColorIndexAutomatic=-4105
        # 使用 queue_script：找不到链接时只警告，避免 throw 中断整队脚本
        code = f'''
let sheet = Application.Worksheets.Item({sheet_js});
let target = {cell_js};
{_JS_NORM_ADDR}
let idx = -1;
let hls = sheet.Hyperlinks;
for (let i = 1; i <= hls.Count; i++) {{
    if (normAddr(hls.Item(i).Range.Address()) === normAddr(target)) {{
        idx = i;
        break;
    }}
}}
if (idx < 0) {{
    console.log("超链接已不存在，请重新调用 hyperlinks() 获取最新列表: " + target);
}} else {{
    let rng = hls.Item(idx).Range;
    hls.Item(idx).Delete();
    rng.Font.Underline = -4142;
    rng.Font.ColorIndex = -4105;
}}
'''
        self._ctx.queue_script(code.strip(), log_message=f"删除超链接: {self._sheet_name}!{self._cell_address}")

    def _queue_update(self, prop_name: str, value: str) -> None:
        cell_js = json.dumps(self._cell_address, ensure_ascii=False)
        sheet_js = json.dumps(self._sheet_name, ensure_ascii=False)
        value_js = json.dumps(value, ensure_ascii=False)
        # 使用 queue_script：找不到链接时只警告，避免 throw 中断整队脚本
        code = f'''
let sheet = Application.Worksheets.Item({sheet_js});
let target = {cell_js};
{_JS_NORM_ADDR}
let idx = -1;
let hls = sheet.Hyperlinks;
for (let i = 1; i <= hls.Count; i++) {{
    if (normAddr(hls.Item(i).Range.Address()) === normAddr(target)) {{
        idx = i;
        break;
    }}
}}
if (idx < 0) {{
    console.log("超链接已不存在，请重新调用 hyperlinks() 获取最新列表: " + target);
}} else {{
    hls.Item(idx).{prop_name} = {value_js};
}}
'''
        self._ctx.queue_script(
            code.strip(),
            log_message=f"更新超链接 {self._sheet_name}!{self._cell_address} {prop_name}",
        )

    def __repr__(self) -> str:
        parts = [
            f"cell={self._cell_address!r}",
            f"address={self._address!r}",
        ]
        if self._sub_address:
            parts.append(f"sub_address={self._sub_address!r}")
        parts.append(f"text={self._text!r}")
        return f"Hyperlink({', '.join(parts)})"
