"""
ap.py

提供智能文档的创建、读取、写入、块查询、块插入、块删除、块更新等能力。

"""

import io
import json
import mimetypes
import os
import re
import struct
from typing import Any, Optional

import sys as _sys
import os as _os
_shared = _os.path.normpath(_os.path.join(_os.path.dirname(__file__), "..", "..", "scripts"))
if _shared not in _sys.path:
    _sys.path.insert(0, _shared)
from wps_http import (
    BaseClient,
    path_segment,
    _retry,
    _request_with_redirect_guard,
    resolve_workspace_path,
    safe_join_dir,
    safe_local_filename,
)
from kdocs import _encode_query_value, _append_link_params, _resolve_target_folder, _get as _kdocs_get


# ──────────────────────────────────────────────────────────────────────────────
# 工具函数
# ──────────────────────────────────────────────────────────────────────────────


def _make_result(success: bool, data: Any = None, message: str = "", error: str = "") -> dict:
    r: dict = {"success": success}
    if data is not None:
        r["data"] = data
    if message:
        r["message"] = message
    if error:
        r["error"] = error
    return r


def _image_size(data: bytes) -> tuple:
    """
    从图片二进制数据解析原始宽高，支持 PNG / JPEG / GIF / WEBP。
    """
    try:
        f = io.BytesIO(data)
        head = f.read(24)
        if head[:8] == b'\x89PNG\r\n\x1a\n':
            w, h = struct.unpack('>II', head[16:24])
            return w, h
        if head[:2] in (b'\xff\xd8',):
            f.seek(0)
            f.read(2)
            for _ in range(500):
                marker_data = f.read(2)
                if len(marker_data) < 2:
                    break
                marker, = struct.unpack('>H', marker_data)
                length_data = f.read(2)
                if len(length_data) < 2:
                    break
                length, = struct.unpack('>H', length_data)
                if marker in (0xFFC0, 0xFFC1, 0xFFC2):
                    f.read(1)
                    h, w = struct.unpack('>HH', f.read(4))
                    return w, h
                if length < 2:
                    break
                f.read(length - 2)
        if head[:6] in (b'GIF87a', b'GIF89a'):
            w, h = struct.unpack('<HH', head[6:10])
            return w, h
        if head[:4] == b'RIFF' and head[8:12] == b'WEBP':
            f.seek(0)
            riff = f.read(12)
            chunk = f.read(4)
            if chunk == b'VP8 ':
                f.read(4)
                f.read(6)
                w, h = struct.unpack('<HH', f.read(4))
                return w & 0x3FFF, h & 0x3FFF
            if chunk == b'VP8L':
                f.read(4)
                f.read(1)
                bits = struct.unpack('<I', f.read(4))[0]
                w = (bits & 0x3FFF) + 1
                h = ((bits >> 14) & 0x3FFF) + 1
                return w, h
        return 0, 0
    except Exception:
        return 0, 0


def _render_size(width: int, height: int, max_size: int = 360) -> int:
    """
    等比缩放到 max_size 内，返回渲染宽度 renderWidth。
    """
    if width <= 0 or height <= 0:
        return max_size
    if width >= height:
        return min(width, max_size)
    return round(width * min(height, max_size) / height)


# WPS attachment/upload/address 要求 name 含合法图片后缀，否则 403 file upload not allowed
_IMAGE_NAME_EXTS = frozenset({
    ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".svg", ".ico", ".tif", ".tiff",
})
_CONTENT_TYPE_EXT = {
    "image/jpeg": ".jpg",
    "image/jpg": ".jpg",
    "image/png": ".png",
    "image/gif": ".gif",
    "image/bmp": ".bmp",
    "image/webp": ".webp",
    "image/svg+xml": ".svg",
    "image/x-icon": ".ico",
    "image/vnd.microsoft.icon": ".ico",
    "image/tiff": ".tiff",
}


def _ensure_image_file_name(file_name: str, content_type: Optional[str]) -> str:
    """
    确保上传用的 name 带合法图片后缀。
    无后缀 URL（如 Unsplash photo-xxx）或非法后缀（如 a.b）都会触发服务端 403。
    """
    base = os.path.basename(file_name or "") or "image"
    stem, ext = os.path.splitext(base)
    if ext.lower() in _IMAGE_NAME_EXTS:
        return base

    ct = (content_type or "").split(";")[0].strip().lower()
    guessed = _CONTENT_TYPE_EXT.get(ct)
    if not guessed:
        raw = mimetypes.guess_extension(ct) or ".png"
        if raw == ".jpe":
            raw = ".jpg"
        guessed = raw if raw.lower() in _IMAGE_NAME_EXTS else ".png"

    stem = stem or "image"
    return stem + guessed


def _inject_index(blocks: list) -> None:
    """
    为 content 数组中每个子块注入 index 字段，方便 AI 直接用索引定位块位置。
    """
    for block in blocks:
        content = block.get("content")
        if isinstance(content, list):
            for i, child in enumerate(content):
                child["index"] = i
                _inject_index([child])


def _collect_source_keys(blocks: list) -> list:
    """递归收集块树中所有 picture 块的 sourceKey。"""
    keys = []
    for block in blocks:
        if block.get("type") == "picture":
            sk = (block.get("attrs") or {}).get("sourceKey", "")
            if sk:
                keys.append(sk)
        child = block.get("content")
        if isinstance(child, list):
            keys.extend(_collect_source_keys(child))
    return keys


def _extract_convert_blocks(data: Any) -> list:
    """从 convert 接口返回中提取可直接用于 block.insert 的块数组。"""
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        blocks = data.get("blocks")
        if isinstance(blocks, list):
            return blocks
        # 少数包装：{result: {blocks: [...]}} / {data: {blocks: [...]}}
        for key in ("result", "data"):
            inner = data.get(key)
            if isinstance(inner, list):
                return inner
            if isinstance(inner, dict) and isinstance(inner.get("blocks"), list):
                return inner["blocks"]
    raise RuntimeError(f"convert 接口返回中未找到 blocks 数组: {type(data).__name__}")



# ──────────────────────────────────────────────────────────────────────────────
# OtlClient：智能文档操作客户端
# ──────────────────────────────────────────────────────────────────────────────


class OtlClient(BaseClient):
    _KDOCS_BASE = "https://365.kdocs.cn"

    def __init__(self):
        super().__init__(csrf=False)

    def _get_link_id(self, file_id: str) -> str:
        """
        从 file_id 解析出 core/execute 所需的 link_id。
        - 非纯数字 ID：本身就是 link_id（来自 URL 365.kdocs.cn/l/{link_id}），直接可用
        - 纯数字 ID（v5）：通过 v5 元数据接口获取 link_id
        """
        try:
            int(file_id)
        except (TypeError, ValueError):
            return file_id
        resp = self._s.get(f"{self._V5_BASE}/api/v5/files/{path_segment(file_id, name='file_id')}/metadata", params={"with_link": "true"})
        if resp.get("result") != "ok":
            raise ValueError(f"v5 获取元数据失败: {resp.get('msg', '未知错误')}")
        link_id = (resp.get("fileinfo") or {}).get("link_id", "")
        if not link_id:
            raise ValueError(f"v5 文件 {file_id} 未找到 link_id")
        return link_id

    def _get_private_drive_id(self) -> str:
        """获取「我的云文档」drive_id（公网 special / 私网 private）。"""
        return _kdocs_get()._resolve_drive_id("private")

    @staticmethod
    def _check_resp(resp: dict) -> dict:
        """
        统一校验 core/execute 响应。
        core/execute 有两种错误格式:
          - 新版: {"code": -1, "msg": "..."}
          - 旧版: {"errno": 10000, "result": "clinkUserNotLogin", "msg": "..."}
        成功时返回 data / detail / 整个 resp。
        """
        errno = resp.get("errno")
        if errno is not None and errno != 0:
            raise RuntimeError(resp.get("msg") or resp.get("result") or f"errno={errno}")
        r, c = resp.get("result"), resp.get("code")
        if r not in (None, "ok"):
            raise RuntimeError(resp.get("msg") or r or "未知错误")
        if c is not None and c != 0:
            raise RuntimeError(resp.get("msg") or f"code={c}")
        return resp.get("data") or resp.get("detail") or resp

    def _exec(self, link_id: str, subtype: str, params: Any) -> dict:
        """
        调用 http.otl.exec 接口（写操作：insertContent / block.insert / block.update / block.delete）。
        成功返回响应的 data 或 detail 字段，失败抛出 RuntimeError。
        """
        resp = self._s.post(
            f"{self._KDOCS_BASE}/api/v3/office/file/{path_segment(link_id, name='link_id')}/core/execute",
            {"command": "http.otl.exec", "param": {"subType": subtype, "params": params}},
        )
        return self._check_resp(resp)

    def _query(self, link_id: str, name: str, params: Any) -> dict:
        """
        调用 http.otl.query 接口（读操作：block.query / convert）。
        core/execute 对 query 操作会返回 {name, params, result} 包装层，
        本方法自动解包，直接返回 result 中的实际数据。
        """
        resp = self._s.post(
            f"{self._KDOCS_BASE}/api/v3/office/file/{path_segment(link_id, name='link_id')}/core/execute",
            {"command": "http.otl.query", "param": {"name": name, "params": params}},
        )
        wrapper = self._check_resp(resp)
        if isinstance(wrapper, dict) and "name" in wrapper and "result" in wrapper:
            return wrapper["result"]
        return wrapper

    # ── 公开 API ──────────────────────────────────────────────────────────────

    def create_doc(
        self,
        name: str,
        title: Optional[str] = None,
        content: Optional[str] = None,
        parent_id: Optional[str] = None,
        drive_id: Optional[str] = None,
        location: Optional[str] = None,
    ) -> dict:
        """
        新建智能文档（.otl），可选设置文档标题和 Markdown 正文内容。

        写入流程：
          1. 创建文档（文件名为 name）
          2. block.update update_content 对 doc 块替换整个内容为仅含 title 的数组，
             一步完成标题设置并消除默认空段落
          3. 若有 content，insertContent 写入 Markdown 正文
          4. 若正文含图片，逐张上传并通过 block.update 更新对应 picture 块的 sourceKey

        Args:
            name:      文件名（.otl 后缀可省略）
            title:     文档大标题文字；为 None 时默认取 name（去掉后缀）
            content:   可选，Markdown 正文内容；为 None 时仅创建标题文档
            parent_id: 父文件夹 ID；传 "0" 表示根目录。与 location 均未传时使用当前会话目录
            drive_id:  云盘 ID，默认按 parent_id 自动解析
            location:  目标文件夹路径（如 "工作/项目A"）；parent_id 优先

        Returns:
            {
                "success": True,
                "data": {
                    "link_id": "link_id",
                    "name": "文件名.otl",
                    "link_url": "云文档链接"
                },
                "message": "成功创建智能文档: xxx.otl，链接: https://..."
            }
        """
        try:
            if not name.endswith(".otl"):
                name += ".otl"
            doc_title = title if title else name

            parent_id = _resolve_target_folder(folder_id=parent_id, location=location)
            if not drive_id:
                drive_id = _kdocs_get()._resolve_folder_drive_id(parent_id)
            resp = self._s.post(
                f"{self._v7}/v7/drives/{path_segment(drive_id, name='drive_id')}/files/{path_segment(parent_id, name='parent_id')}/create",
                {"name": name, "file_type": "file"},
            )
            if resp.get("code") != 0:
                return _make_result(False, error=f"创建智能文档失败: {resp.get('msg', '未知错误')}")
            raw = resp.get("data") or {}
            link_id = raw.get("link_id", "")
            link_url = raw.get("link_url", "")
            if not link_id and link_url:
                parts = link_url.rstrip("/").split("/")
                if len(parts) >= 2 and parts[-2] == "l":
                    link_id = parts[-1]

            # 查询初始块结构（新建文档默认含 title + 空 paragraph）
            doc_data = self._query(link_id, "block.query", {"blockIds": ["doc"]})
            initial_content = ((doc_data.get("blocks") or [{}])[0]).get("content", [])

            # 更新 title 块内容
            title_block = next((b for b in initial_content if b.get("type") == "title"), None)
            if title_block:
                self._exec(link_id, "block.update", [{
                    "blockId": title_block["id"],
                    "operation": "update_content",
                    "content": [{"type": "text", "content": doc_title}],
                }])

            image_upload_errors: list = []
            cleanup_warnings: list = []
            if content:
                image_urls = re.findall(r"!\[[^\]]*\]\(([^)]+)\)", content)
                self._exec(link_id, "insertContent", {"content": content, "pos": "end"})

                # insertContent 之后文档结构为 [title, para(空), ...正文块...]
                # 此时 doc 不止 title 一个块，删除空段落是安全的
                for i, blk in enumerate(initial_content):
                    if blk.get("type") == "paragraph":
                        try:
                            self._exec(link_id, "block.delete", {
                                "blockId": "doc",
                                "startIndex": i,
                                "endIndex": i + 1,
                            })
                        except RuntimeError as e:
                            cleanup_warnings.append(f"删除空段落失败(index={i}): {e}")

                if image_urls:
                    uploads = [self._upload_attachment(link_id, u) for u in image_urls]

                    # 查询结构，找到所有 picture 占位块
                    doc_data = self._query(link_id, "block.query", {"blockIds": ["doc"]})
                    picture_blocks = [
                        item
                        for item in ((doc_data.get("blocks") or [{}])[0]).get("content", [])
                        if item.get("type") == "picture"
                    ]

                    for idx, up in enumerate(uploads):
                        url = image_urls[idx]
                        if not up.get("success"):
                            image_upload_errors.append(
                                f"{url}: {up.get('error', '未知错误')}"
                            )
                            continue
                        if idx >= len(picture_blocks):
                            image_upload_errors.append(
                                f"{url}: 文档中未找到对应 picture 占位块"
                            )
                            continue
                        up_data = up["data"]
                        pic = picture_blocks[idx]
                        attrs = dict(pic.get("attrs", {}))
                        attrs["sourceKey"] = up_data["attachment_id"]
                        attrs["width"] = up_data["width"]
                        attrs["height"] = up_data["height"]
                        attrs["renderWidth"] = up_data["renderWidth"]
                        self._exec(link_id, "block.update", [
                            {"blockId": pic["id"], "operation": "update_attrs", "attrs": attrs}
                        ])
            

            link_url = _append_link_params(link_url, name)
            message = f"成功创建智能文档: {name}，链接: {link_url}"
            data = {
                "link_id": link_id,
                "name": name,
                "link_url": link_url,
            }
            # 两阶段策略：正文已写入，图片失败不回滚文档，但必须把原因返回给调用方
            if image_upload_errors:
                data["image_upload_errors"] = image_upload_errors
                preview = "; ".join(image_upload_errors[:3])
                more = f" 等共 {len(image_upload_errors)} 张" if len(image_upload_errors) > 3 else ""
                message += f"；但 {len(image_upload_errors)} 张图片未就绪: {preview}{more}"
            if cleanup_warnings:
                data["cleanup_warnings"] = cleanup_warnings
                message += f"；清理告警: {'; '.join(cleanup_warnings[:3])}"

            return _make_result(True, data=data, message=message)
        except Exception as e:
            return _make_result(False, error=f"创建智能文档失败: {str(e)}")

    def block_query(self, file_id: str) -> dict:
        """
        查询智能文档结构详情，返回完整的块结构树。

        Args:
            file_id: 智能文档文件 ID

        Returns:
            {
                "success": True,
                "data": {
                    "blocks": [
                        {
                            "id": "doc",
                            "type": "doc",
                            "content": [
                                {"id": "...", "type": "title", "attrs": {...}},
                                {"id": "...", "type": "paragraph", "content": [...], "attrs": {...}},
                                ...
                            ]
                        }
                    ]
                },
                "message": "查询文档内容成功"
            }
        """
        try:
            link_id = self._get_link_id(file_id)
            data = self._query(link_id, "block.query", {"blockIds": ["doc"]})
            if isinstance(data, dict) and "blocks" in data:
                _inject_index(data["blocks"])
            return _make_result(True, data=data, message="查询文档内容成功")
        except Exception as e:
            return _make_result(False, error=f"查询文档内容失败: {e}")

    def convert(
        self,
        file_id: str,
        content: str,
        format: str = "markdown",
    ) -> dict:
        """
        将 Markdown/HTML 转换为智能文档块结构。

        Args:
            file_id: 智能文档文件 ID（转换上下文所需）
            content: 源内容
            format:  "markdown" 或 "html"

        Returns:
            {"success": True, "data": {"blocks": [...]}, "message": "..."}
        """
        try:
            fmt = (format or "markdown").strip().lower()
            if fmt not in ("markdown", "html"):
                return _make_result(False, error=f"不支持的 format: {format}（仅 markdown / html）")
            link_id = self._get_link_id(file_id)
            data = self._query(link_id, "convert", {"format": fmt, "content": content})
            blocks = _extract_convert_blocks(data)
            return _make_result(
                True,
                data={"blocks": blocks},
                message=f"转换成功，共 {len(blocks)} 个块",
            )
        except Exception as e:
            return _make_result(False, error=f"转换失败: {e}")

    def _resolve_images_in_content(self, link_id: str, content: list) -> list:
        """
        递归扫描块数组，将 picture 块中的 image_url 自动上传并替换为
        sourceKey / width / height / renderWidth。
        其他类型的块会递归处理其子块（content 字段）。

        若 attrs 已含 sourceKey（无 image_url），直接跳过上传。
        上传失败时抛出 RuntimeError，避免产出缺少 sourceKey 的无效 picture 块。
        """
        resolved = []
        for blk in content:
            blk = dict(blk)
            if blk.get("type") == "picture":
                attrs = dict(blk.get("attrs") or {})
                image_url = attrs.get("image_url") or attrs.get("src") or attrs.get("url")
                if image_url and not attrs.get("sourceKey"):
                    up = self._upload_attachment(link_id, image_url)
                    if not up.get("success"):
                        raise RuntimeError(
                            f"图片上传失败 ({image_url}): {up.get('error', '未知错误')}"
                        )
                    up_data = up["data"]
                    attrs["sourceKey"] = up_data["attachment_id"]
                    attrs["width"] = up_data["width"]
                    attrs["height"] = up_data["height"]
                    attrs["renderWidth"] = up_data["renderWidth"]
                    for k in ("image_url", "src", "url"):
                        attrs.pop(k, None)
                blk["attrs"] = attrs
            elif isinstance(blk.get("content"), list):
                blk["content"] = self._resolve_images_in_content(link_id, blk["content"])
            resolved.append(blk)
        return resolved

    @staticmethod
    def _validate_picture_blocks(content: list, path: str = "") -> None:
        """插入前校验：picture 块必须已有 sourceKey。"""
        for i, blk in enumerate(content):
            cur = f"{path}[{i}]"
            if blk.get("type") == "picture":
                sk = (blk.get("attrs") or {}).get("sourceKey")
                if not sk:
                    raise ValueError(
                        f"第 {cur} 个块是图片但缺少 sourceKey，无法插入"
                        f"（请提供 attrs.image_url/src/url 或已有 sourceKey）"
                    )
            nested = blk.get("content")
            if isinstance(nested, list):
                OtlClient._validate_picture_blocks(nested, path=f"{cur}.content")

    def block_insert(
        self,
        file_id: str,
        index: int,
        content: list,
        block_id: str = "doc"
    ) -> dict:
        """
        在智能文档指定父块下按索引插入块内容。

        调用前须先通过 block_query 获取文档结构，确定正确的 block_id 和 index。

        支持在 content 中插入图片块：将 picture 块的 attrs.image_url 设为图片地址
        （URL 或本地路径），方法会自动上传并填充 sourceKey / width / height / renderWidth。
        也可直接传入已有 sourceKey（跳过上传）。图片上传失败时立即返回明确错误，
        不会继续向服务端提交无效 picture 块。

        Args:
            file_id:   智能文档文件 ID
            block_id:  目标父块 ID，"doc" 表示在文档级插入
            index:     插入位置索引（block_id 为 "doc" 时需 ≥ 1，index=0 是标题）
            content:   块节点数组，picture 块可用 attrs.image_url 代替 sourceKey

        Returns:
            {"success": True, "data": {...}, "message": "插入块成功"}
        """
        try:
            link_id = self._get_link_id(file_id)
            content = self._resolve_images_in_content(link_id, content)
            self._validate_picture_blocks(content)
            data = self._exec(link_id, "block.insert", {"blockId": block_id, "index": index, "content": content})
            return _make_result(True, data=data, message="插入块成功")
        except Exception as e:
            return _make_result(False, error=f"插入块失败: {e}")

    def block_delete(
        self,
        file_id: str,
        start_index: int,
        end_index: int,
        block_id: str = "doc"
    ) -> dict:
        """
        删除智能文档中指定父块下 [startIndex, endIndex) 区间的子块（左闭右开）。

        Args:
            file_id: 智能文档文件 ID
            block_id: 目标父块 ID
            start_index: 删除起始索引（包含）
            end_index: 删除末尾索引（不包含），需大于 start_index

        Returns:
            {"success": True, "data": {...}, "message": "删除块成功"}
        """
        try:
            link_id = self._get_link_id(file_id)
            data = self._exec(
                link_id,
                "block.delete",
                {"blockId": block_id, "startIndex": start_index, "endIndex": end_index},
            )
            return _make_result(True, data=data, message="删除块成功")
        except Exception as e:
            return _make_result(False, error=f"删除块失败: {e}")

    def block_update(self, file_id: str, params: list) -> dict:
        """
        更新智能文档指定块的内容或属性，支持多种操作类型。

        Args:
            file_id: 智能文档文件 ID
            params: 操作数组，每项含以下字段：
                - operation (str, 必填): 操作类型，见下方说明
                - blockId (str, 必填): 目标块 ID

        支持的 operation 类型：
            update_content       - 更新块内容（需传 content 数组）
            update_attrs         - 更新块属性（需传 attrs 对象，覆盖操作）
            insert_table_rows    - 插入表格行（需传 content 和可选 start）
            insert_table_columns - 插入表格列
            delete_table_rows    - 删除表格行（需传 count 和可选 start）
            delete_table_columns - 删除表格列
            merge_table_cells    - 合并单元格（需传 rowSpan, colSpan）
            split_table_cell     - 拆分单元格

        Returns:
            {"success": True, "data": {...}, "message": "更新块成功"}
        """
        try:
            link_id = self._get_link_id(file_id)
            data = self._exec(link_id, "block.update", params)
            return _make_result(True, data=data, message="更新块成功")
        except Exception as e:
            return _make_result(False, error=f"更新块失败: {e}")

    def upload_image(self, file_id: str, image_source: str) -> dict:
        """
        上传图片到智能文档，返回 attachment_id 及尺寸信息。

        Args:
            file_id: 智能文档文件 ID
            image_source: 图片来源，支持 URL（http/https）或本地文件路径

        Returns:
            {"success": True, "data": {"attachment_id": "...", "width": ..., "height": ..., "renderWidth": ...}}
        """
        try:
            link_id = self._get_link_id(file_id)
            return self._upload_attachment(link_id, image_source)
        except Exception as e:
            return _make_result(False, error=f"上传图片失败: {e}")

    def _resolve_image_urls(self, link_id: str, source_keys: list, batch_size: int = 20) -> dict:
        """
        批量将 sourceKey 解析为可访问的临时图片 URL。
        通过 attachment/shapes 接口分批请求（接口单次上限约 50 个），返回 {sourceKey: url} 映射。
        """
        if not source_keys:
            return {}
        url_map = {}
        for i in range(0, len(source_keys), batch_size):
            batch = source_keys[i:i + batch_size]
            objects = [{"attachment_id": sk} for sk in batch]
            resp = self._s.post(
                f"{self._KDOCS_BASE}/api/v3/office/file/{path_segment(link_id, name='link_id')}/attachment/shapes",
                {"objects": objects},
            )
            errno = resp.get("errno")
            if errno is not None and errno != 0:
                raise RuntimeError(resp.get("msg") or f"attachment/shapes 批次请求失败: errno={errno}")
            data = resp.get("data") or {}
            for sk in batch:
                info = data.get(sk)
                if info and info.get("url"):
                    url_map[sk] = info["url"]
        return url_map

    def download_otl(
        self,
        file_id: str,
        save_dir: Optional[str] = None,
        include_images: bool = True,
    ) -> dict:
        """
        将智能文档导出为 Markdown 文件。

        通过 exportToMarkDown 接口获取文档的 Markdown 正文。
        当 include_images=True 时，自动查询文档中的图片块，
        将 sourceKey 解析为可访问的临时 URL 并嵌入 Markdown。

        Args:
            file_id:        智能文档文件 ID
            save_dir:       保存目录，默认当前工作目录
            include_images: 是否获取图片并嵌入到 Markdown 中

        Returns:
            {
                "success": True,
                "data": {
                    "file_path": "/path/to/file.md",
                    "name": "xxx.md",
                    "size": 1234
                },
                "message": "导出成功，保存路径为: /path/to/file.md"
            }
        """
        try:
            link_id = self._get_link_id(file_id)
            save_dir = resolve_workspace_path(save_dir or os.getcwd())
            os.makedirs(save_dir, exist_ok=True)

            result = self._query(link_id, "exportToMarkDown", {})
            if isinstance(result, dict):
                md_content = result.get("markdown") or result.get("content") or result.get("text") or ""
            elif isinstance(result, str):
                md_content = result
            else:
                md_content = str(result) if result else ""

            if not md_content:
                return _make_result(False, error="导出的 Markdown 内容为空")

            unresolved_images: list = []
            if include_images:
                img_refs = re.findall(r"!\[[^\]]*\]\(([^)]+)\)", md_content)
                source_keys = list(dict.fromkeys(ref for ref in img_refs if not ref.startswith("http")))
                if source_keys:
                    url_map = self._resolve_image_urls(link_id, source_keys)
                    for sk, url in url_map.items():
                        md_content = md_content.replace(sk, url)
                    unresolved_images = [sk for sk in source_keys if sk not in url_map]

            safe_id = re.sub(r'[^a-zA-Z0-9_-]', '_', file_id)
            md_name = f"{safe_id}.md"
            save_path = safe_join_dir(save_dir, md_name, fallback="export.md")
            with open(save_path, "w", encoding="utf-8") as f:
                f.write(md_content)

            data = {
                "file_path": save_path,
                "name": md_name,
                "size": len(md_content.encode("utf-8")),
            }
            message = f"导出成功，保存路径为: {save_path}"
            if unresolved_images:
                data["unresolved_images"] = unresolved_images
                message += f"；{len(unresolved_images)} 张图片 URL 未能解析，Markdown 中仍为 sourceKey"
            return _make_result(True, data=data, message=message)
        except Exception as e:
            err_msg = str(e)
            if "无权限" in err_msg or "403" in err_msg:
                return _make_result(False, error="下载失败: 无权限。请停止当前操作，并提示用户向文件所有者申请访问权限后重试。")
            return _make_result(False, error=f"导出 Markdown 失败: {err_msg}")

    def _upload_attachment(
        self,
        link_id: str,
        image_source: str,
        file_name: Optional[str] = None,
        content_type: Optional[str] = None,
    ) -> dict:
        """
        内部图片上传方法（3 步：申请地址 → 直传 → 回调）。
        每步独立重试（max_attempts=2, 指数退避），失败通过 _make_result 返回错误。

        返回 _make_result 格式:
            成功: {"success": True, "data": {"attachment_id": ..., "width": ..., "height": ..., "renderWidth": ...}}
            失败: {"success": False, "error": "..."}
        """
        _MAX_IMAGE_SIZE = 20 * 1024 * 1024  # 20MB

        def _http_error_detail(resp) -> str:
            """从非 2xx 响应中提取服务端 msg/result，避免只剩泛化 HTTP 状态码。"""
            try:
                err_data = resp.json()
                return (
                    err_data.get("msg")
                    or err_data.get("result")
                    or err_data.get("reason")
                    or f"HTTP {resp.status_code}"
                )
            except Exception:
                body = (resp.text or "")[:200]
                return f"HTTP {resp.status_code}" + (f": {body}" if body else "")

        def _ensure_json_api_ok(data: dict, *, what: str) -> dict:
            """校验 HTTP 200 响应体中的业务错误（errno/result/code）。"""
            if not isinstance(data, dict):
                raise RuntimeError(f"{what}: 响应非对象")
            errno = data.get("errno")
            if errno is not None and errno != 0:
                raise RuntimeError(
                    data.get("msg") or data.get("result") or f"errno={errno}"
                )
            result = data.get("result")
            if result not in (None, "ok"):
                raise RuntimeError(data.get("msg") or result or "未知错误")
            code = data.get("code")
            if code is not None and code != 0:
                raise RuntimeError(data.get("msg") or f"code={code}")
            return data

        # Step 0: 获取文件数据（下载远程图片或读取本地文件）
        def _fetch_file_data():
            nonlocal file_name, content_type
            if image_source.startswith(("http://", "https://")):
                dl_resp = self._s.download(image_source)
                if dl_resp.status_code != 200:
                    raise RuntimeError(_http_error_detail(dl_resp))
                _data = dl_resp.content
                if not file_name:
                    raw = image_source.split("/")[-1].split("?")[0]
                    file_name = safe_local_filename(raw, fallback="image.png")
                if not content_type:
                    content_type = (
                        dl_resp.headers.get("Content-Type", "").split(";")[0].strip()
                        or mimetypes.guess_type(file_name)[0]
                        or "image/png"
                    )
            else:
                # 本地路径仅允许工作区（WPS_DOCS_ALLOW_ROOT / cwd）内文件，防止任意读外泄
                local_path = resolve_workspace_path(image_source, must_exist=True)
                if not os.path.isfile(local_path):
                    raise RuntimeError(f"本地图片不是文件: {image_source}")
                with open(local_path, "rb") as f:
                    _data = f.read()
                if not file_name:
                    file_name = safe_local_filename(local_path, fallback="image.png")
                if not content_type:
                    content_type = mimetypes.guess_type(file_name)[0] or "image/png"
            # 服务端按 name 后缀校验；无后缀/非法后缀会 403
            file_name = _ensure_image_file_name(file_name, content_type)
            return _data

        try:
            file_data = _retry(_fetch_file_data, max_attempts=2, delay=1.0)
        except Exception as e:
            err_msg = str(e)
            if "403" in err_msg or "无权限" in err_msg:
                return _make_result(False, error=f"获取图片失败: 无权限访问 ({image_source})。请检查图片链接是否有效。")
            return _make_result(False, error=f"获取图片数据失败 ({image_source}): {e}")

        if len(file_data) > _MAX_IMAGE_SIZE:
            return _make_result(False, error=f"图片过大 ({len(file_data)} bytes)，上限 {_MAX_IMAGE_SIZE} bytes")

        file_size = len(file_data)
        text_hdr = {
            "Content-Type": "text/plain;charset=UTF-8",
        }

        # Step 1: 申请上传地址
        def _request_upload_address():
            addr_url = f"{self._KDOCS_BASE}/api/v3/office/file/{path_segment(link_id, name='link_id')}/attachment/upload/address"
            addr_body = json.dumps(
                {"name": file_name, "size": file_size, "content_type": content_type},
                ensure_ascii=False,
            ).encode("utf-8")
            resp = self._s._http.post(addr_url, data=addr_body, headers=text_hdr, timeout=30)
            if resp.status_code != 200:
                raise RuntimeError(_http_error_detail(resp))
            return _ensure_json_api_ok(resp.json(), what="申请上传地址")

        try:
            addr_data = _retry(_request_upload_address, max_attempts=2, delay=1.0)
        except Exception as e:
            return _make_result(False, error=f"申请上传地址失败 (file={file_name}): {e}")

        request_info = addr_data.get("request")
        if not request_info or not isinstance(request_info, dict):
            return _make_result(False, error=f"申请上传地址响应格式异常 (file={file_name}): 缺少 request 字段")
        upload_url = request_info.get("url")
        if not upload_url:
            return _make_result(False, error=f"申请上传地址未返回 url (file={file_name})")
        upload_headers = request_info.get("headers", {})
        upload_id = addr_data.get("upload_id")
        if not upload_id:
            return _make_result(False, error=f"申请上传地址未返回 upload_id (file={file_name})")
        send_back_params = addr_data.get("send_back_params", {})

        # Step 2: 传文件到云存储（对象存储常见非 JSON 响应，保留正文片段便于诊断）
        def _put_to_cloud():
            put_headers = dict(upload_headers)
            put_headers["Content-Type"] = content_type
            resp = _request_with_redirect_guard(
                self._s._http, "PUT", upload_url, timeout=60, headers=put_headers, data=file_data,
            )
            if resp.status_code != 200:
                body_preview = (resp.text or "")[:200]
                raise RuntimeError(
                    f"HTTP {resp.status_code}"
                    + (f": {body_preview}" if body_preview else "")
                )
            return resp

        try:
            put_resp = _retry(_put_to_cloud, max_attempts=2, delay=2.0)
        except Exception as e:
            return _make_result(False, error=f"上传文件到云存储失败 (file={file_name}): {e}")

        params_for_complete: dict = {}
        for param_name, source in send_back_params.items():
            if source.startswith("header."):
                header_name = source[len("header."):]
                params_for_complete[param_name] = put_resp.headers.get(header_name, "")

        missing = [k for k, v in params_for_complete.items() if not v]
        if missing:
            return _make_result(False, error=f"云存储响应头缺少回调参数: {missing}")

        # Step 3: 上传完成回调
        def _complete_upload():
            complete_url = f"{self._KDOCS_BASE}/api/v3/office/file/{path_segment(link_id, name='link_id')}/attachment/upload/complete"
            complete_body = json.dumps(
                {"upload_id": upload_id, "params": params_for_complete},
                ensure_ascii=False,
            ).encode("utf-8")
            resp = self._s._http.post(complete_url, data=complete_body, headers=text_hdr, timeout=30)
            if resp.status_code != 200:
                raise RuntimeError(_http_error_detail(resp))
            return _ensure_json_api_ok(resp.json(), what="上传完成回调")

        try:
            complete_data = _retry(_complete_upload, max_attempts=2, delay=1.0)
        except Exception as e:
            return _make_result(False, error=f"上传完成回调失败 (file={file_name}): {e}")

        attachment_id = complete_data.get("attachment_id")
        if not attachment_id:
            return _make_result(False, error=f"上传回调未返回 attachment_id (file={file_name})")
        img_w, img_h = _image_size(file_data)
        render_w = _render_size(img_w, img_h)
        return _make_result(True, data={
            "attachment_id": attachment_id,
            "width": img_w,
            "height": img_h,
            "renderWidth": render_w,
        })



def _get() -> OtlClient:
    return OtlClient()


def create_doc(*args, **kwargs):      return _get().create_doc(*args, **kwargs)
def block_query(*args, **kwargs):     return _get().block_query(*args, **kwargs)
def convert(*args, **kwargs):         return _get().convert(*args, **kwargs)
def block_insert(*args, **kwargs):    return _get().block_insert(*args, **kwargs)
def block_delete(*args, **kwargs):    return _get().block_delete(*args, **kwargs)
def block_update(*args, **kwargs):    return _get().block_update(*args, **kwargs)
def upload_image(*args, **kwargs):    return _get().upload_image(*args, **kwargs)
def download_otl(*args, **kwargs): return _get().download_otl(*args, **kwargs)
