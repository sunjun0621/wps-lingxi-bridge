---
name: ap
description: "智能文档相关能力。当需要对智能文档（.otl）进行 Markdown 导出，创建、查询/插入/删除/更新和图片上传/移动时使用本技能。"
---

# AP SKILL

## 调用方式

```bash
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" ap <子命令> [参数]
```



## 块类型（Block Type）说明

智能文档内容由块（block）树组成。以下是常见块类型。

| type | 含义 | 备注 |
|------|------|------|
| doc | 文档根节点 | 顶层容器，id 固定为 "doc"，其 content 即文档所有顶层块 |
| title | 文档大标题 | 每篇文档唯一，位于 doc.content[0] |
| heading | 标题块 | attrs.level 表示层级（1~6） |
| paragraph | 段落 | 最常用的文本块；列表（无序/有序/任务）也是 paragraph，通过 attrs.listAttrs 区分 |
| picture | 图片块 | attrs.sourceKey 为附件 ID |
| table | 表格 | content 为 tableRow 数组 |
| tableRow | 表格行 | content 为 tableCell 数组 |
| tableCell | 表格单元格 | content 为段落等块数组 |
| bulletList | 无序列表 | content 为 listItem 数组 |
| orderedList | 有序列表 | content 为 listItem 数组 |
| listItem | 列表项 | |
| codeBlock | 代码块 | attrs.language 为语言名 |
| blockQuote | 引用块 | 子节点为行内节点（text 等） |
| highLightBlock | 高亮块（彩色背景容器） | 可嵌套块节点 |
| hr | 分割线 | 叶子节点，无子节点 |
| text | 行内文本节点 | 块的 content 数组中的叶子节点，content 字段为文本字符串；attrs 可含 bold、italic、color 等样式 |


## 智能文档 API

### ap download-otl

下载智能文档为 Markdown 文件。

| 参数 | 类型 | 说明 |
|------|------|------|
| `--file-id` | str | 智能文档文件 ID |
| `--save-dir` | str | 可选，保存目录，默认当前工作目录 |

**返回值**

```json
{
  "success": true,
  "data": {
    "file_path": "/path/to/file.md",
    "name": "文件名.md",
    "size": 12345
  },
  "message": "下载成功，保存路径为: /path/to/file.md"
}
```

通过该接口获取到的文档块结构与 `block-query` 返回的文档块结构一致。

**调用示例**

```bash
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" ap download-otl --file-id xxx
```

### ap create-doc

新建智能文档。

| 参数 | 类型 | 说明 |
|------|------|------|
| `--name` | str | 文件名（云文档列表中显示的名称，可省略 .otl 后缀） |
| `--title` | str | 可选，文档大标题 |
| `--content-file` | 文件 | 可选，Markdown 正文文件路径 |
| `--parent-id` | str | 可选，目标文件夹的 `file_id`;不传则创建在默认位置。如需按名称查找，先调用 `kdocs.find_folder_by_path()` |
| `--location` | str | 可选，目标文件夹路径（如 `工作/项目A`）；`--parent-id` 优先 |

**返回值**

```json
{
  "success": true,
  "data": {
    "link_id": "link_id（即 file_id，可用于后续操作）",
    "name": "文件名.otl",
    "link_url": "https://365.kdocs.cn/l/xxx"
  },
  "message": "成功创建智能文档: xxx.otl，链接: https://..."
}
```

**调用示例**

```bash
# body.md 内容示例：
# ## 截图
#
# ![示例](https://example.com/img.png)
#
# 说明文字
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" ap create-doc \
  --name "产品说明" --title "产品说明" --content-file body.md

# 按路径创建
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" ap create-doc \
  --name "产品说明" --location "工作/项目A"
```

### ap block-query

查询智能文档结构详情

**调用 `block-insert` / `block-delete` / `block-update` 前，必须先调用此接口获取块 ID 和结构。**

| 参数 | 类型 | 说明 |
|------|------|------|
| `--file-id` | str | 智能文档文件 ID |

**返回值**

```json
{
  "success": true,
  "data": {
    "blocks": [
      {
        "id": "doc",
        "type": "doc",
        "content": [
          {"id": "...", "type": "title", "attrs": {}},
          {"id": "...", "type": "paragraph", "content": [], "attrs": {}}
        ]
      }
    ]
  },
  "message": "查询文档内容成功"
}
```

**调用示例**

```bash
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" ap block-query --file-id xxx
```

### ap block-insert

在指定父块的指定索引处插入块内容


| 参数 | 类型 | 说明 |
|------|------|------|
| `--file-id` | str | 智能文档文件 ID |
| `--index` | int | 插入位置索引（block_id="doc" 时 ≥1，0 是标题） |
| `--content-file` | 文件 | Markdown 正文（段落/标题/列表/表格/图片 `![](url)` 等） |
| `--block-id` | str | 可选，父块 ID，默认 `doc` |

**返回值**

```json
{"success": true, "message": "插入成功"}
```

**调用示例**

```bash
# insert.md: Markdown 正文（列表/表格/代码块等均可）
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" ap block-insert \
  --file-id xxx --index 1 --content-file insert.md
```

### ap block-delete

删除智能文档中指定内容。

| 参数 | 类型 | 说明 |
|------|------|------|
| `--file-id` | str | 智能文档文件 ID |
| `--start-index` | int | 删除起始索引（包含） |
| `--end-index` | int | 删除末尾索引（不包含） |
| `--block-id` | str | 可选，父块 ID，默认 `doc` |

**返回值**

```json
{"success": true, "message": "删除成功"}
```

**调用示例**

```bash
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" ap block-delete \
  --file-id xxx --start-index 1 --end-index 2
```

---

### ap upload-image

上传图片到智能文档。

**更新图片块前必须先调用此接口**，将返回的 `attachment_id` 作为 `source_key` 传给 `block-update`。

| 参数 | 类型 | 说明 |
|------|------|------|
| `--file-id` | str | 智能文档文件 ID |
| `--source` | str | 图片来源，支持 URL 或本地文件路径 |

**返回值**

```json
{
  "success": true,
  "data": {
    "attachment_id": "附件 ID（即 sourceKey）",
    "width": 800,
    "height": 600,
    "renderWidth": 360
  }
}
```

**调用示例**

```bash
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" ap upload-image --file-id xxx --source https://example.com/img.png
```

---

### ap block-update

更新指定块的内容或属性。

**operation 类型**

| operation | 功能 | 附加参数 |
|-----------|------|----------|
| update_content | 更新块文本 | `text` / `content_file`，或 `--text` / `--content-file` |
| update_attrs | 更新块属性（**覆盖**） | `source_key`、`width`、`height`、`render_width`、`render_height`、`caption` 等 |

**重要**：`update_attrs` 为**覆盖**操作——未改的字段也须原样传入，否则可能被清空。更新图片时先 `upload-image` 取得 `attachment_id`，再把 `source_key` / 宽高等一并传入。

**返回值**

```json
{"success": true, "message": "更新成功"}
```

**调用示例**

```bash
# 单条：更新文本
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" ap block-update \
  --file-id xxx --operation update_content --block-id blk_xxx --text "新的文本内容"

# 批量 ops.md：每个 ## <operation> 为一条操作，其下 - key: value 为参数
# ## update_content
# - block_id: blk_xxx
# - text: 新的文本内容
# ## update_attrs
# - block_id: blk_yyy
# - source_key: att_zzz
# - width: 800
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" ap block-update \
  --file-id xxx --ops-file ops.md
```

更新图片（两步：先上传，再更新块属性）：

```bash
# 第 1 步：上传图片获取 attachment_id
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" ap upload-image --file-id xxx --source https://example.com/new.png

# 第 2 步：用上传结果更新图片块
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" ap block-update \
  --file-id xxx --operation update_attrs --block-id blk_pic \
  --source-key "<attachment_id>" --width 800 --height 600 \
  --render-width 360 --render-height 600 --caption picture
```
