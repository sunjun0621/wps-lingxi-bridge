# 公式操作

> WPS 文字文档 formulas 域相关操作。

| 工具 | 功能 |
|------|------|
| [`wps.formulas.math`](formulas.math.md) | 插入公式 |
