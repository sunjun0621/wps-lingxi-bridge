# wps.htmls.insert

## 1. wps.htmls.insert

#### 功能说明

按字符区间插入 HTML 片段。

**幂等性**：否 — unsafe

> begin/end 为 0-based 字符区间；可由 wps.texts.search 返回的 ranges 回填。

#### 调用示例

字符区间插入 HTML：

```json
{
  "file_id": "<FILE_ID>",
  "begin": 1,
  "end": 10,
  "html": "<p>smoke html</p>"
}
```

#### 参数说明

- `begin` (number, 可选): 区间起点
- `end` (number, 可选): 区间终点
- `file_id` (string, 三选一必填: `url` / `link_id` / `file_id`): 文件 id；与 url、link_id 三选一
- `html` (string, 必填): HTML 片段
- `link_id` (string, 三选一必填: `url` / `link_id` / `file_id`): 分享 id；与 url、file_id 三选一
- `url` (string, 三选一必填: `url` / `link_id` / `file_id`): 文档 URL；与 link_id、file_id 三选一

#### 返回值说明

```json
{
  "code": 0,
  "message": "成功",
  "data": {
    "begin": 1,
    "end": 15
  }
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `code` | number | 0 表示成功 |
| `data` | object | 业务数据 |
| `message` | string | 结果说明 |
