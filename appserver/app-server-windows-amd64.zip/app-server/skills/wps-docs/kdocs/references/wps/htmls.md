# HTML 插入

> WPS 文字文档 htmls 域相关操作。

| 工具 | 功能 |
|------|------|
| [`wps.htmls.insert`](htmls.insert.md) | 按字符区间插入 HTML |
