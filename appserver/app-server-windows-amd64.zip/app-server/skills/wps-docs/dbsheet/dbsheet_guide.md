
---
name: dbsheet
description: "金山多维表（.dbt）的操作与管理能力。涵盖获取 Schema、列举/检索/创建/更新/删除记录、数据表/字段/视图管理和表单元数据等。"
---

# DbSheet SKILL

## 调用方式

```bash
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet <子命令> [参数]
```

批量字段/记录用 Markdown 表格文件（`--fields-file` / `--records-file`）；嵌套请求体用 `--body-file`。多值（字段 `items`、记录 MultipleSelect / Link）统一用分号 `;` 分隔，详见 `create-records` / `update-records`。

**通用参数说明**（以下各子命令不再重复）

| 参数 | 类型 | 说明 |
|------|------|------|
| `--file-id` | str | 多维表文件 ID，可从链接 `https://365.kdocs.cn/l/{file_id}` 提取 |
| `--sheet-id` | int | 数据表 ID（整数），从 `get-schema` 结果获取；新建 `.dbt` 多维表文件后第一张表的 ID 固定为 `1` |
| `--record-id` | str | 记录 ID |
| `--record-ids` | str | 记录 ID 列表（逗号分隔） |
| `--view-id` | str | 视图 ID，从 `get-schema` 结果的 views 列表获取 |
| `--page-size` | int | 每页返回记录数；省略时使用服务端默认值（最大 1000） |
| `--page-token` | str | 翻页 token，传上一次返回的 `data.page_token`；省略或空串表示从第一页开始 |

**所有子命令返回格式统一**

成功：

```json
{"success": true, "data": {}, "message": "操作成功描述"}
```

失败：

```json
{"success": false, "error": "错误描述"}
```

**`data` 字段结构说明**

| 子命令 | `data` 内容 |
|--------|------------|
| get-schema | `{"sheets": [{"id": 1, "name": "表名", "fields": [...], "views": [...], "records_count": 10}]}` |
| list-records / search-records / create-records / update-records / delete-records | `{"records": [...], "page_token": ""}` |
| get-record | `{"record": {"id": "rec_xxx", "fields": {...}}}` |
| create-sheet | `{"sheet": {"id": 2, "name": "表名", "fields": [...], "views": [...]}}` |
| create-view | `{"view": {"id": "V", "name": "视图名", "view_type": "Grid"}}` |
| delete-empty-records | `{"deleted_count": 18, "record_ids": [...]}` |
| create-file | `{"id": "file_id", "link_id": "...", "link_url": "...", "name": "文件名"}` |

> `fields` 已由客户端自动解析为 dict，可直接用 `rec["fields"]["字段名"]` 取值。

---

## 创建多维表文档

### dbsheet create-file

在云盘新建文件，创建多维表文档（`.dbt`）时使用。

| 参数 | 说明 |
|------|------|
| `--name` | 文件名，如 `"项目任务.dbt"`（多维表）|
| `--folder-id` | 可选，目标文件夹的 `file_id`；不传则使用当前会话目录；传 `0` 为根目录 |
| `--location` | 可选，目标文件夹路径（如 `工作/项目A`）；`--folder-id` 优先 |

**返回值**

```json
{
    "success": true,
    "data": {
        "id": "file_id",
        "link_id": "...",
        "link_url": "https://...",
        "name": "文件名",
        "primary_fields": [
            {
                "sheet_id": 1,
                "field_id": "B",
                "field_name": "名称",
                "field_type": "MultiLineText",
                "undeletable_reason": "..."
            }
        ]
    },
    "message": "创建文件成功"
}
```

> **主字段说明**：创建后服务端预置了默认主字段（不可删除）。
> ⚠️ **必须复用主字段**：若业务中有字段需要新增，**必须先调用 `update-fields` 将主字段重命名为该字段名称**，再进行后续操作。禁止跳过主字段、另行新建字段替代。

> `data.primary_fields` 示例：`[{"sheet_id": 1, "field_id": "B", "field_name": "名称", "field_type": "MultiLineText", "undeletable_reason": "主字段（primary field）是数据表的唯一标识列，不支持删除。若主字段在业务中有对应用途，必须先调用 update-fields 将其重命名为目标字段名称，再继续后续操作，禁止跳过或新建替代。"}]`

**调用示例**

```bash
# 默认创建到当前会话目录
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet create-file --name "项目任务跟踪.dbt"

# 按路径创建
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet create-file --name "项目任务跟踪.dbt" --location "工作/项目A"
```

---

## Schema（表结构）

### dbsheet get-schema

获取多维表所有数据表及字段结构（包括查询视图）。

**返回值**

```json
{
  "success": true,
  "data": {
    "sheets": [
      {
        "id": 1,
        "name": "表名",
        "fields": [
          {"id": "B", "name": "字段名", "field_type": "MultiLineText"}
        ],
        "views": [
          {"id": "I", "name": "视图名", "type": "Grid"}
        ],
        "records_count": 10
      }
    ]
  },
  "message": "获取 Schema 成功"
}
```
> `field_type` 与 `type` 等价，可互换使用。


**调用示例**

```bash
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet get-schema --file-id abc123
```

### dbsheet create-fields

批量新建字段。通过 `--fields-file` Markdown 表格传入，每行必须含 `name` 和 `type`。

**fields 每项字段说明**

| 字段 | 必填 | 说明 |
|------|------|------|
| name | ✅ | 字段名（Markdown 表头列） |
| type | ✅ | 字段类型，见下方类型列表 |
| items | 选填 | 仅 `SingleSelect`/`MultipleSelect`：选项文案用分号 `;` 分隔（如 `未开始;进行中`）；更新时已有选项可写 `id=文案` |
| max | 选填 | `Rating` 的最大星级（默认 5） |
| numberFormat | 选填 | 日期/数值等显示格式（如 `yyyy/MM/dd`、`0.00`）；也可用 `number_format` |

**常用 `type`**：`MultiLineText` / `SingleLineText` / `Number` / `Date` / `Checkbox` / `SingleSelect` / `MultipleSelect` / `Rating` / `Attachment` / `Member`

**返回值**

```json
{
    "success": true,
    "data": {
        "fields": [
            {"id": "B", "name": "备注", "type": "MultiLineText"},
            {"id": "C", "name": "状态", "type": "SingleSelect", "items": [{"id": "A", "value": "未开始"}]},
            {"id": "D", "name": "评分", "type": "Rating"}
        ]
    },
    "message": "创建字段成功"
}
```

**调用示例**

```bash
# fields.md:
# | name | type | items | max | numberFormat |
# | --- | --- | --- | --- | --- |
# | 备注 | MultiLineText | | | |
# | 状态 | SingleSelect | 未开始;进行中;已完成 | | |
# | 评分 | Rating | | 5 | |
# | 日期 | Date | | | yyyy/MM/dd |
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet create-fields \
  --file-id abc123 --sheet-id 1 --fields-file fields.md
```

### dbsheet delete-fields

按字段 `id` 批量删除字段。`field_ids` 为字段 id 字符串列表（字段 id 可从 `get-schema` 获取）。

**返回值**

```json
{
    "success": true,
    "data": {
        "fields": [
            {"id": "J", "deleted": true},
            {"id": "K", "deleted": true}
        ]
    },
    "message": "删除字段成功"
}
```

**调用示例**

```bash
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet delete-fields --file-id abc123 --sheet-id 1 --field-ids J,K
```

### dbsheet update-fields

批量更新字段属性。`fields` 每项必须含 `id`，其余属性选填，只修改提供的部分（同 `create-fields` 字段属性，均变为可选）。

**选项字段 `items` 更新规则**：
- 带 `id` → 修改已有选项
- 不带 `id` → 新增选项

**重要**：`items` 采用全量覆盖语义。 调用时传入的 `items` 列表会**完整替换**原有所有选项——未出现在列表中的原有选项将被永久删除。在新增或修改选项前，必须先通过 `get-schema` 取得该字段当前的全部选项，并将它们（连同各自的 `id`）完整写入 `items`，再追加新选项（不带 `id`）。

**返回值**

```json
{
    "success": true,
    "data": {
        "fields": [
            {"id": "E", "name": "新字段名", "type": "SingleSelect",
             "items": [{"id": "B", "value": "未开始"}, {"id": "D", "value": "已完成"}]}
        ]
    },
    "message": "更新字段成功"
}
```

**调用示例**

```bash
# fields.md（items 列：已有选项写 id=文案，新选项只写文案；分号 ; 分隔）:
# | id | name | items | max | numberFormat |
# | --- | --- | --- | --- | --- |
# | E | 新字段名 | B=未开始;D=已完成;待定 | | |
# | C | | | 4 | |
# | B | | | | yyyy-MM-dd |
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet update-fields \
  --file-id abc123 --sheet-id 1 --fields-file fields.md
```

---

## 记录操作

### dbsheet list-records

列举多维表记录（支持分页与条件筛选）

| 参数 | 类型 | 默认行为 | 说明 |
|------|------|----------|------|
| `--file-id` | str | （必填） | 多维表文件 ID |
| `--sheet-id` | int | （必填） | 数据表 ID |
| `--view-id` | str | 返回全表记录 | 指定视图 ID |
| `--fields` | str | 返回所有字段 | 逗号分隔字段名/ID，如 `名称,状态` |
| `--page-size` | int | 服务端默认（最大 1000） | 每页返回记录数 |
| `--page-token` | str | 从第一页开始 | 翻页 token |
| `--max-records` | int | 不限制 | 最多返回记录总数 |
| `--text-value` | str | 默认格式 | `original` / `text` / `compound` |
| `--filter-mode` | str | `AND` | 与 `--criterion` 联用：`AND` / `OR` |
| `--criterion` | str | 无 | 可重复；格式 `字段:Operator:值`（无值如 Empty：`截止:Empty`） |

> `operator` 可选：Equals / NotEqu / Contains / Empty / NotEmpty / Greater / Less 等。

**返回值**

```json
{
    "success": true,
    "data": {
        "records": [
            {"id": "1", "fields": {"字段名": "值"}}
        ],
        "page_token": ""
    },
    "message": "获取记录成功"
}
```

> `page_token` 为空表示无更多数据。

**调用示例**

```bash
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet list-records --file-id abc123 --sheet-id 1

python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet list-records \
  --file-id abc123 --sheet-id 1 --filter-mode AND \
  --criterion "状态:Equals:进行中" --criterion "名称:Contains:测试"
```

---

### dbsheet get-record

获取单条记录详情。

**返回值**

```json
{
    "success": true,
    "data": {
        "record": {"id": "rec_xxx", "fields": {"字段名": "值"}}
    },
    "message": "获取记录成功"
}
```

**调用示例**

```bash
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet get-record --file-id abc123 --sheet-id 1 --record-id rec_xxx
```

---

### dbsheet search-records

按 ID 列表批量检索记录。

**返回值**

```json
{
    "success": true,
    "data": {
        "records": [
            {"id": "rec_xxx", "fields": {"字段名": "值"}}
        ]
    },
    "message": "查询记录成功"
}
```

**调用示例**

```bash
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet search-records --file-id abc123 --sheet-id 1 --record-ids rec_1,rec_2
```

---

### dbsheet create-records

批量创建记录。CLI 会先 `get-schema`，按字段类型转换单元格后再提交：

- MultipleSelect：选项用 `;` 分隔（与 `--fields-file` 的 `items` 相同），如 `前端;P0`
- Link / OneWayLink：关联记录 ID 用 `;` 分隔，如 `q` → `["q"]`、`q;r` → `["q","r"]`
- Checkbox：`true` / `false`
- Attachment / Member / Contact 等结构化字段：Markdown 记录表不支持，请直接调 `dbsheet` Python API

**返回值**

```json
{
    "success": true,
    "data": {
        "records": [
            {"id": "rec_xxx", "fields": {"名称": "任务A", "状态": "进行中"}}
        ]
    },
    "message": "创建记录成功"
}
```


**调用示例**

```bash
# records.md:
# | 名称 | 优先级 | 状态 | 标签 | 已完成 |
# | --- | --- | --- | --- | --- |
# | 需求评审 | 高 | 待开始 | 前端;P0 | false |
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet create-records \
  --file-id abc123 --sheet-id 1 --records-file records.md
```

---

### dbsheet update-records

批量更新记录。Markdown 表格须含 `id` 列，其余列为要更新的字段值。单元格类型规则同 `create-records`，另：

- MultipleSelect / Link **空单元格** = 清空；其它类型空单元格 = 不更新该列

**返回值**

```json
{
    "success": true,
    "data": {
        "records": [
            {"id": "rec_xxx", "fields": {"状态": "已完成"}}
        ]
    },
    "message": "已更新 N 条记录"
}
```

**调用示例**

```bash
# updates.md:
# | id | 状态 | 标签 |
# | --- | --- | --- |
# | rec_xxx | 已完成 | 前端;后端 |
# | rec_yyy |  |  |
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet update-records \
  --file-id abc123 --sheet-id 1 --records-file updates.md
# 上例 rec_yyy：若「标签」为 MultipleSelect 则清空；「状态」为空则不更新状态
```
---

### dbsheet delete-records

批量删除记录。

**返回值**

```json
{
    "success": true,
    "data": {
        "records": [
            {"id": "rec_xxx", "deleted": true}
        ]
    },
    "message": "删除记录成功"
}
```

**调用示例**

```bash
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet delete-records --file-id abc123 --sheet-id 1 --record-ids rec_1,rec_2
```

---

### dbsheet delete-empty-records

删除表中所有空记录（`fields` 为空或 `{}`）。翻页遍历、分批删除（每批 50 条）。

**返回值**

```json
{
    "success": true,
    "data": {
        "deleted_count": 18,
        "record_ids": ["rec_1", "rec_2"]
    },
    "message": "删除空记录成功"
}
```

**调用示例**

```bash
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet delete-empty-records --file-id abc123 --sheet-id 1
```

---

## 数据表管理

### dbsheet create-sheet

创建数据表。

| 参数 | 默认行为（省略时） | 说明 |
|------|----------|------|
| `--name` | 服务端自动命名 | 数据表名称 |
| `fields` | 使用服务端默认字段 | 字段列表；CLI 传 Markdown 表格文件路径（列：`name` / `field_type` 或 `type`；可选 `items` / `max` / `numberFormat`，同 `create-fields`） |
| views | 自动补一个默认表格视图 | API 强制至少一个视图；CLI 不单独传，由服务端自动处理 |
| `position` | 追加到末尾 | 插入位置；CLI 用 `--before-sheet-id` 或 `--after-sheet-id` |

**返回值**

```json
{
    "success": true,
    "data": {
        "sheet": {"id": 2, "name": "任务清单"}
    },
    "message": "创建数据表成功"
}
```

**调用示例**

```bash
# fields.md:
# | name | field_type |
# | --- | --- |
# | 名称 | MultiLineText |
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet create-sheet \
  --file-id abc123 --name "任务清单" --fields fields.md
```

---

### dbsheet update-sheet

重命名数据表。

**返回值**

```json
{
    "success": true,
    "message": "更新数据表成功"
}
```

**调用示例**

```bash
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet update-sheet --file-id abc123 --sheet-id 1 --name "新表名"
```

---

### dbsheet delete-sheet

删除数据表。

**返回值**

```json
{
    "success": true,
    "message": "删除数据表成功"
}
```

**调用示例**

```bash
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet delete-sheet --file-id abc123 --sheet-id 2
```

---

## 视图

---

### dbsheet create-view

创建视图。`view_type`：`Grid`表格视图 / `Kanban`看板视图 / `Gallery`画册视图 / `Form`表单视图 / `Gantt`甘特视图 / `Query`查询视图 / `Calendar`日历视图

**返回值**

```json
{
    "success": true,
    "data": {
        "view": {"id": "V", "name": "看板视图", "view_type": "Kanban"}
    },
    "message": "创建视图成功"
}
```

**调用示例**

```bash
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet create-view \
  --file-id abc123 --sheet-id 1 --name "看板视图" --view-type Kanban
```

> **创建甘特图视图需要两步**：`create-view` 仅完成视图创建，**必须紧接着调用 `update-view` 设置 `--begin-field` 和 `--end-field`**，否则甘特图无法正常显示时间轴。
> ⚠️ 两个字段名须从 `get-schema` 返回的 `Date` 类型字段中按语义选取，不可照抄示例。
>
> ```bash
> # 第一步：创建甘特图视图
> python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet create-view \
>   --file-id abc123 --sheet-id 1 --name "甘特图" --view-type Gantt
>
> # 第二步：配置起始和结束日期字段（必须执行）
> python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet update-view \
>   --file-id abc123 --sheet-id 1 --view-id "..." \
>   --begin-field "<起始日期字段名>" --end-field "<结束日期字段名>"
> ```

---

### dbsheet delete-view

删除视图。

**返回值**

```json
{
    "success": true,
    "data": {
        "view": {"id": "I"}
    },
    "message": "删除视图成功"
}
```

**调用示例**

```bash
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet delete-view --file-id abc123 --sheet-id 1 --view-id I
```

---

### dbsheet update-view

| 参数 | 适用视图 | 说明 |
|------|------|------|
| `--name` | 全部 | 视图重命名 |
| `--prefer-id` | 全部 | 开关；开启后下列参数中的字段标识用字段 **id**（默认用字段名）。字段名含特殊字符或存在重名时建议开启，开启后 `--order-fields` / `--hide-fields` 等须同步改为 id |
| `--order-fields` | 全部 | 逗号分隔字段名/ID，**必须包含该表全部字段**，不可只传部分，顺序即最终列顺序。示例：`名称,状态,截止日期,负责人` |
| `--hide-fields` | 全部 | 逗号分隔字段名/ID，将列出的字段在当前视图中隐藏（未列出的保持原状）。传 `""` 则取消该视图全部字段的隐藏 |
| `--begin-field` | Gantt | 甘特图时间轴**起始日期**字段名，必须是 `Date` 类型，不设置则时间轴无法显示 |
| `--end-field` | Gantt | 甘特图时间轴**结束日期**字段名，必须是 `Date` 类型，不设置则时间轴无法显示 |

**返回值**

```json
{
    "success": true,
    "data": {
        "view": {"id": "I", "name": "新视图名", "type": "Grid"}
    },
    "message": "更新视图成功"
}
```

**调用示例**

```bash
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet update-view \
  --file-id abc123 --sheet-id 1 --view-id I --name "新视图名" \
  --order-fields "B,D,F,E,C" --hide-fields D
```

---

### dbsheet get-form-meta

获取表单视图元数据。`view_id` 从 `get-schema` 的 views 中筛选 `type == "Form"` 的项获取。

**返回值**

```json
{
  "success": true,
  "data": {
    "name": "表单名称",
    "description": "表单描述"
  },
  "message": "获取表单元数据成功"
}
```
> `data` 还可能包含其他表单配置字段。

**调用示例**

```bash
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet get-form-meta --file-id abc123 --sheet-id 1 --view-id view_xxx
```

---

### dbsheet update-form-meta

更新表单视图名称/描述，name 和 description至少提供一个。

**返回值**

```json
{
    "success": true,
    "message": "更新表单视图成功"
}
```

**调用示例**

```bash
python "$SKILL_PATH_BASH/wps-docs/scripts/wps_docs_cli.py" dbsheet update-form-meta --file-id abc123 --sheet-id 1 --view-id view_xxx --name "需求收集表" --description "请填写你的需求"
```

---

## 类型参考

**字段类型（Field Type）**

普通类型：`MultiLineText`多行文本 · `Date`日期 · `Time`时间 · `Number`数值 · `Currency`货币 · `Percentage`百分比 · `ID`身份证 · `Phone`电话 · `Email`电子邮箱 · `Url`超链接 · `Checkbox`复选框 · `SingleSelect`单选项 · `MultipleSelect`多选项（旧文档也写作`MultiSelect`）· `Rating`等级 · `Complete`进度条 · `Contact`联系人 · `Attachment`附件 · `Link`关联 · `Note`富文本 · `Address`地址 · `Cascade`级联 · `Department`部门

> `Note` 的富文本正文不通过本子模块的 `update-records` 写入。

自动类型（只读/系统生成）：`AutoNumber`编号 · `CreatedBy`创建者 · `CreatedTime`创建时间 · `LastModifiedBy`最后修改者 · `LastModifiedTime`最后修改时间 · `Formula`公式 · `Lookup`引用 · `BarCode`条码 · `SearchLookup`查找引用 · `Button`按钮 · `OneWayLink`单向关联

**视图类型（View Type）**

`Grid`表格视图 · `Kanban`看板视图 · `Gallery`画册视图 · `Form`表单视图 · `Gantt`甘特视图 · `Query`查询视图 · `Calendar`日历视图

---

## 错误处理

| 常见错误 | 原因 | 解决方案 |
|----------|------|----------|
| 字段未找到 | 字段名不匹配 | 先用 `get-schema` 确认字段名，区分大小写 |
| 数据类型错误 | 值类型不符 | 数字传 int/float，日期传字符串如 `"2026-03-14"` |
| 权限不足 | 无读写权限 | 确认 `file_id` 正确且账号有访问权限 |
| SingleSelect 保存为空 | 选项值不在预定义列表 | 先用 `get-schema` 确认选项，值须完全匹配 |
