#!/usr/bin/env python3
"""
Web Builder CLI — 封装 Web 项目常用操作。

用法：
    web_builder_cli.py install  <project_dir>
    web_builder_cli.py build    <project_dir>
    web_builder_cli.py start    <project_dir> [--port PORT]
    web_builder_cli.py pip      <project_dir> <package> [<package> ...]
    web_builder_cli.py package  <project_dir> -o <output.zip> [--include-node-modules]
"""

from __future__ import annotations

import argparse
import os
import random
import re
import socket
import subprocess
import sys
import time
from pathlib import Path


def _build_env() -> dict:
    env = dict(os.environ)
    env["NODE_OPTIONS"] = ""
    return env


def cmd_install(args: argparse.Namespace) -> None:
    project_dir = Path(args.project_dir).resolve()
    env = _build_env()

    # 判断前后端分离项目
    frontend = project_dir / "frontend"
    backend = project_dir / "backend"

    if frontend.exists() and (frontend / "package.json").exists():
        print(f"[frontend] npm install ...")
        r = subprocess.run("npm install", shell=True, cwd=str(frontend), env=env,
                           encoding="utf-8", errors="replace")
        if r.returncode != 0:
            sys.exit(r.returncode)
    if backend.exists() and (backend / "package.json").exists():
        print(f"[backend] npm install ...")
        r = subprocess.run("npm install", shell=True, cwd=str(backend), env=env,
                           encoding="utf-8", errors="replace")
        if r.returncode != 0:
            sys.exit(r.returncode)
    if (project_dir / "package.json").exists():
        print(f"npm install ...")
        r = subprocess.run("npm install", shell=True, cwd=str(project_dir), env=env,
                           encoding="utf-8", errors="replace")
        if r.returncode != 0:
            sys.exit(r.returncode)

    print("依赖安装完成")


def cmd_build(args: argparse.Namespace) -> None:
    project_dir = Path(args.project_dir).resolve()
    env = _build_env()

    dirs = []
    frontend = project_dir / "frontend"
    if frontend.exists() and (frontend / "package.json").exists():
        dirs.append(frontend)
    elif (project_dir / "package.json").exists():
        dirs.append(project_dir)

    for d in dirs:
        print(f"npm run build ({d}) ...")
        r = subprocess.run("npm run build", shell=True, cwd=str(d), env=env,
                           encoding="utf-8", errors="replace")
        if r.returncode != 0:
            sys.exit(r.returncode)

    print("构建完成")


def _get_free_port() -> int:
    for _ in range(10):
        port = random.randint(10000, 65535)
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return port
    return 5173


def cmd_start(args: argparse.Namespace) -> None:
    project_dir = Path(args.project_dir).resolve()
    env = _build_env()
    port = args.port or _get_free_port()

    process = subprocess.Popen(
        f"npx vite --port {port} --host",
        shell=True,
        cwd=str(project_dir),
        env=env,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )

    time.sleep(6)
    output = process.stdout.read1(65536).decode("utf-8", errors="replace")
    print(output)

    local_url = network_url = None
    for line in output.splitlines():
        m = re.search(r"https?://[^\s]+", line)
        if m:
            if "localhost" in line or "127.0.0.1" in line or "Local" in line:
                local_url = m.group()
            elif "Network" in line:
                network_url = m.group()

    if local_url:
        print(f"本地访问: {local_url}")
    if network_url:
        print(f"局域网访问: {network_url}")


def cmd_package(args: argparse.Namespace) -> None:
    import zipfile

    project_dir = Path(args.project_dir).resolve()
    out = Path(args.output).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)

    # 默认排除列表
    _EXCLUDE_DIRS = {".git", ".web_builder", "__pycache__", ".cache", ".vite", ".next", ".nuxt"}
    _EXCLUDE_FILES = {".DS_Store", "Thumbs.db"}
    if not args.include_node_modules:
        _EXCLUDE_DIRS.add("node_modules")

    def _should_skip(rel: Path) -> bool:
        for part in rel.parts:
            if part in _EXCLUDE_DIRS or part in _EXCLUDE_FILES:
                return True
        return False

    count = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        for file in project_dir.rglob("*"):
            if not file.is_file():
                continue
            rel = file.relative_to(project_dir)
            if _should_skip(rel):
                continue
            zf.write(file, rel)
            count += 1

    size_kb = out.stat().st_size // 1024
    print(f"已打包 {count} 个文件 → {out}（{size_kb} KB）")


def cmd_pip(args: argparse.Namespace) -> None:
    packages = " ".join(args.packages)
    print(f"pip install {packages} ...")
    r = subprocess.run(
        f"pip install {packages}",
        shell=True,
        encoding="utf-8",
        errors="replace",
    )
    sys.exit(r.returncode)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="web_builder_cli.py",
        description="Web Builder 常用操作封装",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_install = sub.add_parser("install", help="安装 npm 依赖")
    p_install.add_argument("project_dir", help="项目根目录")

    p_build = sub.add_parser("build", help="构建项目")
    p_build.add_argument("project_dir", help="项目根目录")

    p_start = sub.add_parser("start", help="启动开发服务器")
    p_start.add_argument("project_dir", help="项目根目录")
    p_start.add_argument("--port", type=int, default=0, help="端口（默认随机）")

    p_pip = sub.add_parser("pip", help="安装 Python 包")
    p_pip.add_argument("project_dir", help="项目根目录（仅用于定位）")
    p_pip.add_argument("packages", nargs="+", help="要安装的包名")

    p_pkg = sub.add_parser("package", help="打包项目为 zip 文件交付")
    p_pkg.add_argument("project_dir", help="项目根目录")
    p_pkg.add_argument("-o", "--output", required=True, help="输出 zip 文件路径")
    p_pkg.add_argument("--include-node-modules", action="store_true",
                       help="包含 node_modules（默认排除）")

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    commands = {
        "install": cmd_install,
        "build": cmd_build,
        "start": cmd_start,
        "pip": cmd_pip,
        "package": cmd_package,
    }
    commands[args.command](args)


if __name__ == "__main__":
    main()
