#!/usr/bin/env bash
python "$(dirname "$0")/web_builder_cli.py" "$@" 2>&1
