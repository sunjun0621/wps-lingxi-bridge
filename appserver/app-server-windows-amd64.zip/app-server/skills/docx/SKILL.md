---
name: docx
description: 创建、导出、下载或编辑 Word (.docx) 文档；用于新建文档、文本替换及 OOXML 解包或重新打包。用户仅要求交付文档且未指定格式时，默认使用 DOCX。不支持批注、修订、复杂样式重构、复杂目录或域代码处理。
---

# DOCX 文档创建与编辑

按任务完整阅读对应指南后执行：

- 新建、生成、导出、下载，以及修改已有 DOCX JavaScript：[create-docx.md](create-docx.md)（视觉细则：[references/design.md](references/design.md)）
- 编辑、文本替换、解包或重新打包 DOCX：[edit-docx.md](edit-docx.md)
