from __future__ import annotations

import hashlib
import json
import math
import mimetypes
import os
import posixpath
import re
import subprocess
import sys
import urllib.parse
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path

import requests

DOCX_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
# 与 pptx transcoder_api 对齐：写死公网入口。
BASE_URL = "https://lingxi.wps.cn"
CREATE_PATH = "/api/transcoder/docx/create"
DEFAULT_TIMEOUT_SECONDS = 600
DEFAULT_LOCAL_VALIDATE_TIMEOUT_SECONDS = 15
MAX_VALIDATE_DIAGNOSTIC_CHARS = 4096
MAX_REF_BYTES = 20 * 1024 * 1024
# JS 在子目录（如 output/）而 references.json 在会话根时，向上查找的最大层数。
REFERENCES_WALK_UP_LEVELS = 3

_NODE_LOCATION_PATTERN = re.compile(r"^\[stdin\]:(\d+)$")
_NODE_SYNTAX_ERROR_PATTERN = re.compile(r"^SyntaxError:\s*(.*)$")


_RESOURCE_CALL_PATTERNS = (
    ("h.img", re.compile(r"(?<![\w$])h\s*\.\s*img\s*\("), False, "h.img('images/photo.jpg')"),
    (
        "h.coverBg",
        re.compile(r"(?<![\w$])h\s*\.\s*coverBg\s*\("),
        False,
        "h.coverBg('images/cover.jpg')",
    ),
    (
        "autoBibliography",
        re.compile(r"(?<![\w$])autoBibliography\s*\("),
        True,
        "refs.autoBibliography('references.json')",
    ),
    (
        "readFileSync",
        re.compile(r"(?<![\w$])readFileSync\s*\("),
        False,
        "readFileSync('data/input.json')",
    ),
)
_RESOURCE_PROPERTY_PATTERNS = (
    (
        "imagePath",
        re.compile(r"(?<![\w$])imagePath\s*:"),
        "imagePath: 'images/background.jpg'",
    ),
)

_ALLOWED_RESOURCE_FORMS = (
    "a string literal, e.g. 'images/photo.jpg'",
    "a single-assignment const/let/var alias",
    "path.join(__dirname, ...string literals)",
    "process.cwd() or process.env.OUTPUT / process.env.OUTPUT_DIR",
    "a + concatenation of the forms above",
)


@dataclass(frozen=True)
class _ResourceExpression:
    label: str
    expression: str
    start: int
    end: int


def create_docx(
    script_path: str | Path,
    output: str | Path,
    cwd: str | Path | None = None,
    ref_specs: Sequence[str] | None = None,
    asset_manifest: str | Path | Mapping[str, object] | None = None,
) -> Path:
    script = Path(script_path).expanduser()
    if not script.exists():
        raise FileNotFoundError(f"JS file does not exist: {script}")
    if not script.is_file():
        raise ValueError(f"JS path is not a file: {script}")

    output_path = Path(output).expanduser()
    if output_path.exists() and output_path.is_dir():
        raise ValueError(f"output is a directory, expected a .docx path: {output_path}")
    output_path.parent.mkdir(parents=True, exist_ok=True)

    working_dir = Path(cwd).expanduser() if cwd else script.parent

    # Thin local preflight before any remote call (not a model-facing CLI step).
    scripts_dir = str(Path(__file__).resolve().parent)
    if scripts_dir not in sys.path:
        sys.path.insert(0, scripts_dir)
    from docx_lint import format_lint_failure, lint_docx_script

    lint_result = lint_docx_script(
        script,
        cwd=working_dir,
        output=output_path,
        ref_specs=list(ref_specs) if ref_specs is not None else None,
        asset_manifest=asset_manifest,
    )
    if not lint_result["ok"]:
        raise ValueError(format_lint_failure(lint_result))

    code = script.read_text(encoding="utf-8")
    code, refs = _prepare_remote_payload(
        code,
        script,
        output_path,
        working_dir,
        ref_specs=ref_specs,
        asset_manifest=asset_manifest,
    )

    url = _build_url(CREATE_PATH)
    timeout = float(os.environ.get("DOCX_TRANSCODER_TIMEOUT", DEFAULT_TIMEOUT_SECONDS))

    # 始终走 multipart：无 ref 时若只用 data=，requests 会发 form-urlencoded，
    # 而服务端只接受 JSON 或 multipart/form-data。
    file_handles: list = []
    files: list[tuple] = [
        ("code", (None, code)),
        ("filename", (None, output_path.name)),
    ]
    try:
        for remote_path, local_path in sorted(refs.items()):
            fh = open(local_path, "rb")
            file_handles.append(fh)
            content_type = mimetypes.guess_type(local_path.name)[0] or "application/octet-stream"
            files.append((f"ref:{remote_path}", (local_path.name, fh, content_type)))

        resp = requests.post(
            url,
            headers=_build_headers(),
            cookies=_build_cookies(),
            files=files,
            timeout=timeout,
        )
    except requests.RequestException as exc:
        status = getattr(exc.response, "status_code", None)
        body = _response_error_detail(exc.response, limit=2000) if exc.response is not None else ""
        raise RuntimeError(
            f"office-transcoder DOCX create request failed: {exc}"
            + (f"\nstatus={status}" if status is not None else "")
            + (f"\n{body}" if body else "")
        ) from exc
    finally:
        for fh in file_handles:
            fh.close()

    if resp.status_code >= 400:
        detail = _response_error_detail(resp, limit=4000)
        raise RuntimeError(
            f"office-transcoder DOCX create failed: HTTP {resp.status_code}\n{detail}"
        )

    data_bytes = resp.content
    resp_content_type = resp.headers.get("Content-Type", "")
    if not data_bytes.startswith(b"PK"):
        preview = data_bytes[:1000].decode("utf-8", errors="replace")
        raise RuntimeError(
            "office-transcoder returned non-DOCX response "
            f"(Content-Type={resp_content_type!r}):\n{preview}"
        )

    output_path.write_bytes(data_bytes)
    print(f"DOCX created by office-transcoder: {output_path} ({len(data_bytes) / 1024:.1f} KB)")
    stats = (resp.headers.get("X-Docx-Stats") or resp.headers.get("x-docx-stats") or "").strip()
    if stats:
        # Same language as DELIVER: one English STATS line for the model; omit zeros.
        compact = _compact_docx_stats(stats)
        if compact:
            print(f"[docx-helpers] STATS {compact}")
    print(
        "DELIVER: create succeeded. Ship this .docx; "
        "trust STATS above — do not rework for counts."
    )
    return output_path


def _compact_docx_stats(stats_line: str) -> str:
    """Keep non-zero key=value fields for the model."""
    parts: list[str] = []
    for part in stats_line.split(";"):
        part = part.strip()
        if not part or "=" not in part:
            continue
        key, value = part.split("=", 1)
        key, value = key.strip(), value.strip()
        try:
            if int(value) == 0:
                continue
        except ValueError:
            pass
        parts.append(f"{key}={value}")
    return ";".join(parts)


def validate_docx_source(source: str) -> dict[str, object]:
    """Local `node --check` only. Create already syntax-checks on the server."""
    if not source.strip():
        raise ValueError("DOCX JavaScript source is empty")

    executable = os.environ.get("DOCX_NODE_EXE", "").strip() or "node"
    timeout_value = os.environ.get(
        "DOCX_LOCAL_NODE_CHECK_TIMEOUT",
        str(DEFAULT_LOCAL_VALIDATE_TIMEOUT_SECONDS),
    )
    try:
        timeout = float(timeout_value)
    except ValueError:
        timeout = float(DEFAULT_LOCAL_VALIDATE_TIMEOUT_SECONDS)
    if not math.isfinite(timeout) or timeout <= 0:
        timeout = float(DEFAULT_LOCAL_VALIDATE_TIMEOUT_SECONDS)
    source_bytes = source.encode("utf-8")
    digest = hashlib.sha256(source_bytes).hexdigest()
    node_env = os.environ.copy()
    node_env.pop("NODE_OPTIONS", None)
    try:
        completed = subprocess.run(
            [executable, "--check", "-"],
            input=source_bytes,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            check=False,
            env=node_env,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise RuntimeError(
            f"local node unavailable for syntax check ({executable}): {exc}"
        ) from exc

    if completed.returncode == 0:
        return {"valid": True, "sha256": digest, "validator": "local"}

    stderr = completed.stderr.decode("utf-8", errors="replace")
    diagnostic = _parse_node_syntax_diagnostic(stderr)
    if completed.returncode != 1 or diagnostic is None:
        detail = stderr.strip() or f"exit {completed.returncode}"
        raise RuntimeError(f"local node --check failed unexpectedly: {detail}")
    return {
        "valid": False,
        "sha256": digest,
        "diagnostic": diagnostic,
        "validator": "local",
    }


def _parse_node_syntax_diagnostic(stderr: str) -> dict[str, object] | None:
    lines = stderr.replace("\r\n", "\n").split("\n")
    line_number = 0
    column = 0
    context = ""
    for index, line in enumerate(lines):
        match = _NODE_LOCATION_PATTERN.fullmatch(line.strip())
        if not match:
            continue
        line_number = int(match.group(1))
        if index + 1 < len(lines):
            context = lines[index + 1]
        if index + 2 < len(lines):
            caret = lines[index + 2].find("^")
            if caret >= 0:
                column = caret + 1
        break

    message = ""
    for line in reversed(lines):
        match = _NODE_SYNTAX_ERROR_PATTERN.fullmatch(line.strip())
        if match:
            message = match.group(1).strip() or "Node.js syntax check failed"
            break
    if line_number <= 0 or not message:
        return None
    return {
        "code": "SyntaxError",
        "line": line_number,
        "column": column,
        "message": message[:MAX_VALIDATE_DIAGNOSTIC_CHARS],
        "context": context[:MAX_VALIDATE_DIAGNOSTIC_CHARS],
    }


def _response_error_detail(response: requests.Response, limit: int) -> str:
    try:
        payload = response.json()
    except (ValueError, requests.RequestException):
        payload = None

    hint = _find_json_hint(payload)
    if hint:
        return hint[:limit]
    try:
        return response.text[:limit]
    except Exception:
        return ""


def _find_json_hint(value: object) -> str:
    if isinstance(value, Mapping):
        hint = value.get("hint")
        if isinstance(hint, str) and hint.strip():
            return hint.strip()
        for nested in value.values():
            found = _find_json_hint(nested)
            if found:
                return found
    elif isinstance(value, list):
        for nested in value:
            found = _find_json_hint(nested)
            if found:
                return found
    return ""


def _build_url(path: str) -> str:
    """与 pptx transcoder_api 对齐：仅当 SERVER_BRANCH 有值时带 x_cc_region。"""
    url = BASE_URL.rstrip("/") + path
    branch = os.environ.get("SERVER_BRANCH", "").strip()
    if branch:
        separator = "&" if "?" in url else "?"
        url += f"{separator}x_cc_region={branch}"
    return url


def _build_headers() -> dict[str, str]:
    # Align with pptx transcoder_api on master.
    return {
        "Accept": DOCX_CONTENT_TYPE,
        "Connection": "keep-alive",
    }


def _build_cookies() -> dict[str, str]:
    return {"wps_sid": _get_wps_sid()}


def _get_wps_sid() -> str:
    sid = os.environ.get("TMP_LX_UUID", "").strip()
    if not sid:
        raise ValueError("环境变量 TMP_LX_UUID 未设置，请设置后使用")
    return sid


def _prepare_remote_payload(
    code: str,
    script: Path,
    output_path: Path,
    working_dir: Path,
    ref_specs: Sequence[str] | None = None,
    asset_manifest: str | Path | Mapping[str, object] | None = None,
) -> tuple[str, dict[str, Path]]:
    script_dir = script.parent.expanduser().resolve()
    working_dir = working_dir.expanduser().resolve()
    output_dir = output_path.parent.expanduser().resolve()
    search_dirs = _resource_search_dirs(script_dir, working_dir, output_dir)
    refs = _load_explicit_refs(ref_specs, asset_manifest, search_dirs, working_dir)
    replacements: list[tuple[int, int, str]] = []

    references = _find_references_json(search_dirs, script_dir)
    if references and "references.json" not in refs:
        _check_ref_size(references)
        refs["references.json"] = references
        if references.parent.resolve() not in {path.resolve() for path in search_dirs}:
            print(f"[INFO] using references.json from {references}")

    evaluator = _StaticJsPathEvaluator(
        code,
        script_dir=script_dir,
        working_dir=working_dir,
        output_dir=output_dir,
    )
    for resource in _extract_resource_expressions(code):
        try:
            lookup_path = evaluator.evaluate(resource.expression)
        except _StaticPathError as exc:
            raise ValueError(_unresolved_resource_message(code, resource, str(exc))) from None
        if not lookup_path.strip():
            raise ValueError(_unresolved_resource_message(code, resource, "the path is empty"))

        if _is_remote_or_data(lookup_path):
            raise ValueError(
                _unsupported_remote_resource_message(code, resource, lookup_path)
            )

        normalized_lookup = _normalize_js_path(lookup_path)
        if _is_safe_ref_path(normalized_lookup) and normalized_lookup in refs:
            remote_path = normalized_lookup
            local = refs[remote_path]
        else:
            local = _resolve_resource_path(lookup_path, search_dirs)
            remote_path = _remote_ref_path(lookup_path, local, search_dirs) if local else ""
        if not local:
            # references.json 缺失时不阻断 create：远端 helper 会跳过空文献表
            if resource.label == "autoBibliography" and Path(
                _path_from_js_string(lookup_path) or "references.json"
            ).name == "references.json":
                print(
                    "[WARN] references.json not found for autoBibliography; "
                    "continuing without bibliography file"
                )
                continue
            raise FileNotFoundError(
                _missing_resource_message(code, resource, lookup_path, search_dirs)
            )
        _check_ref_size(local)
        _add_ref(refs, remote_path, local, source=f"{resource.label} expression")
        replacements.append(
            (resource.start, resource.end, _quote_js_string(remote_path))
        )

    for start, end, new_value in sorted(replacements, reverse=True):
        code = code[:start] + new_value + code[end:]

    return code, refs


def _extract_resource_expressions(code: str) -> list[_ResourceExpression]:
    masked = _mask_js_non_code(code)
    found: list[_ResourceExpression] = []

    for label, pattern, allow_empty, _example in _RESOURCE_CALL_PATTERNS:
        for match in pattern.finditer(masked):
            value_start = _skip_js_space_and_comments(code, match.end())
            if allow_empty and value_start < len(code) and code[value_start] == ")":
                found.append(
                    _ResourceExpression(
                        label=label,
                        expression="'references.json'",
                        start=value_start,
                        end=value_start,
                    )
                )
                continue
            value_end = _scan_js_expression_end(code, value_start, {",", ")"})
            found.append(
                _ResourceExpression(
                    label=label,
                    expression=code[value_start:value_end].strip(),
                    start=value_start,
                    end=value_end,
                )
            )

    for label, pattern, _example in _RESOURCE_PROPERTY_PATTERNS:
        for match in pattern.finditer(masked):
            value_start = _skip_js_space_and_comments(code, match.end())
            value_end = _scan_js_expression_end(code, value_start, {",", "}", "\n", "\r"})
            found.append(
                _ResourceExpression(
                    label=label,
                    expression=code[value_start:value_end].strip(),
                    start=value_start,
                    end=value_end,
                )
            )

    return sorted(set(found), key=lambda item: item.start)


class _StaticPathError(ValueError):
    pass


class _StaticJsPathEvaluator:
    def __init__(
        self,
        code: str,
        script_dir: Path,
        working_dir: Path,
        output_dir: Path,
    ):
        self.code = code
        self.masked = _mask_js_non_code(code)
        self.script_dir = script_dir.resolve()
        self.working_dir = working_dir.resolve()
        self.output_dir = output_dir.resolve()
        self.bindings = self._collect_bindings()
        self._resolving: set[str] = set()

    def evaluate(self, expression: str) -> str:
        if re.match(r"^[rR]\s*['\"]", expression):
            raise _StaticPathError(
                "Python raw-string prefixes such as r'...' are not valid JavaScript"
            )
        return _StaticJsPathParser(expression, self)._parse()

    def resolve_identifier(self, name: str) -> str:
        entries = self.bindings.get(name, [])
        if not entries:
            raise _StaticPathError(f"identifier {name!r} has no supported static declaration")
        if len(entries) != 1 or not self._is_single_assignment(name):
            raise _StaticPathError(
                f"identifier {name!r} is not a single-assignment static alias"
            )
        if name in self._resolving:
            raise _StaticPathError(f"cyclic static aliases include {name!r}")
        self._resolving.add(name)
        try:
            return _StaticJsPathParser(entries[0], self)._parse()
        finally:
            self._resolving.remove(name)

    def environment_path(self, name: str) -> str:
        value = os.environ.get(name, "")
        if not value:
            return str(self.output_dir)
        path = Path(value).expanduser()
        if not path.is_absolute():
            path = self.working_dir / path
        return str(path.resolve())

    def _collect_bindings(self) -> dict[str, list[str]]:
        bindings: dict[str, list[str]] = {}
        declaration = re.compile(
            r"\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*="
        )
        for match in declaration.finditer(self.masked):
            start = _skip_js_space_and_comments(self.code, match.end())
            end = _scan_js_expression_end(self.code, start, {";", "\n", "\r"})
            bindings.setdefault(match.group(1), []).append(self.code[start:end].strip())
        return bindings

    def _is_single_assignment(self, name: str) -> bool:
        escaped = re.escape(name)
        assignments = re.findall(
            rf"(?<![=!<>])\b{escaped}\s*=(?!=|>)",
            self.masked,
        )
        assignment_operator = (
            r"(?:>>>=|\*\*=|>>=|<<=|&&=|\|\|=|\?\?=|[+\-*/%&|^]=|\+\+|--)"
        )
        mutations = re.search(
            rf"(?:\b{escaped}\s*{assignment_operator}|(?:\+\+|--)\s*\b{escaped}\b)",
            self.masked,
        )
        return len(assignments) == 1 and mutations is None


class _StaticJsPathParser:
    def __init__(self, expression: str, evaluator: _StaticJsPathEvaluator):
        self.expression = expression
        self.evaluator = evaluator
        self.i = 0

    def _parse(self) -> str:
        value = self._parse_concat()
        self._skip_space_and_comments()
        if self.i != len(self.expression):
            raise _StaticPathError(
                f"unsupported syntax near {self.expression[self.i:self.i + 40]!r}"
            )
        return value

    def _parse_concat(self) -> str:
        value = self._parse_primary()
        while True:
            self._skip_space_and_comments()
            if not self._consume("+"):
                return value
            value += self._parse_primary()

    def _parse_primary(self) -> str:
        self._skip_space_and_comments()
        if self.i >= len(self.expression):
            raise _StaticPathError("the expression is empty or incomplete")
        if self.expression[self.i] in ("'", '"', "`"):
            return self._parse_string()
        if self._consume("("):
            value = self._parse_concat()
            self._skip_space_and_comments()
            self._expect(")")
            return value

        name = self._parse_identifier()
        if name == "__dirname":
            return str(self.evaluator.script_dir)
        if name == "path":
            self._expect_member("join")
            return self._parse_path_join()
        if name == "process":
            member = self._parse_member()
            if member == "cwd":
                self._skip_space_and_comments()
                self._expect("(")
                self._skip_space_and_comments()
                self._expect(")")
                return str(self.evaluator.working_dir)
            if member == "env":
                env_name = self._parse_member()
                if env_name not in {"OUTPUT", "OUTPUT_DIR"}:
                    raise _StaticPathError(
                        "only process.env.OUTPUT and process.env.OUTPUT_DIR are allowed"
                    )
                return self.evaluator.environment_path(env_name)
            raise _StaticPathError(
                "only process.cwd(), process.env.OUTPUT, and process.env.OUTPUT_DIR are allowed"
            )
        return self.evaluator.resolve_identifier(name)

    def _parse_path_join(self) -> str:
        self._skip_space_and_comments()
        self._expect("(")
        parts: list[str] = []
        while True:
            self._skip_space_and_comments()
            if self._consume(")"):
                break
            parts.append(self._parse_concat())
            self._skip_space_and_comments()
            if self._consume(")"):
                break
            self._expect(",")
        if not parts:
            raise _StaticPathError("path.join() needs at least one static path part")
        return os.path.join(*parts)

    def _parse_string(self) -> str:
        quote = self.expression[self.i]
        self.i += 1
        out: list[str] = []
        escapes = {
            "b": "\b",
            "f": "\f",
            "n": "\n",
            "r": "\r",
            "t": "\t",
            "v": "\v",
            "0": "\0",
        }
        while self.i < len(self.expression):
            ch = self.expression[self.i]
            self.i += 1
            if ch == quote:
                return "".join(out)
            if quote == "`" and ch == "$" and self._peek("{"):
                raise _StaticPathError("template expressions (${...}) are not supported")
            if ch in "\r\n" and quote != "`":
                raise _StaticPathError("an unterminated JavaScript string was found")
            if ch != "\\":
                out.append(ch)
                continue
            if self.i >= len(self.expression):
                raise _StaticPathError("an unterminated JavaScript escape was found")
            escaped = self.expression[self.i]
            self.i += 1
            if escaped in ("\\", "'", '"', "`"):
                out.append(escaped)
            elif escaped in escapes:
                out.append(escapes[escaped])
            elif escaped in "\r\n":
                if escaped == "\r" and self._peek("\n"):
                    self.i += 1
            elif escaped == "x":
                out.append(self._parse_hex_escape(2))
            elif escaped == "u":
                out.append(self._parse_hex_escape(4))
            else:
                out.append(escaped)
        raise _StaticPathError("an unterminated JavaScript string was found")

    def _parse_hex_escape(self, length: int) -> str:
        raw = self.expression[self.i:self.i + length]
        if len(raw) != length or not re.fullmatch(r"[0-9A-Fa-f]+", raw):
            raise _StaticPathError("an invalid JavaScript hexadecimal escape was found")
        self.i += length
        return chr(int(raw, 16))

    def _parse_identifier(self) -> str:
        self._skip_space_and_comments()
        match = re.match(r"[A-Za-z_$][\w$]*", self.expression[self.i:])
        if not match:
            raise _StaticPathError(
                f"expected a supported path value near {self.expression[self.i:self.i + 40]!r}"
            )
        self.i += len(match.group(0))
        return match.group(0)

    def _parse_member(self) -> str:
        self._skip_space_and_comments()
        self._expect(".")
        return self._parse_identifier()

    def _expect_member(self, expected: str) -> None:
        actual = self._parse_member()
        if actual != expected:
            raise _StaticPathError(f"only path.join(...) is allowed, not path.{actual}")

    def _skip_space_and_comments(self) -> None:
        while self.i < len(self.expression):
            if self.expression[self.i].isspace():
                self.i += 1
            elif self.expression.startswith("//", self.i):
                newline = self.expression.find("\n", self.i + 2)
                self.i = len(self.expression) if newline < 0 else newline + 1
            elif self.expression.startswith("/*", self.i):
                end = self.expression.find("*/", self.i + 2)
                if end < 0:
                    raise _StaticPathError("an unterminated JavaScript comment was found")
                self.i = end + 2
            else:
                return

    def _consume(self, value: str) -> bool:
        self._skip_space_and_comments()
        if self.expression.startswith(value, self.i):
            self.i += len(value)
            return True
        return False

    def _expect(self, value: str) -> None:
        if not self._consume(value):
            raise _StaticPathError(f"expected {value!r}")

    def _peek(self, value: str) -> bool:
        return self.expression.startswith(value, self.i)


def _scan_js_expression_end(code: str, start: int, terminators: set[str]) -> int:
    i = start
    depth = 0
    quote = ""
    while i < len(code):
        ch = code[i]
        if quote:
            if ch == "\\":
                i += 2
                continue
            if ch == quote:
                quote = ""
            i += 1
            continue
        if code.startswith("//", i):
            newline = code.find("\n", i + 2)
            i = len(code) if newline < 0 else newline
            continue
        if code.startswith("/*", i):
            end = code.find("*/", i + 2)
            i = len(code) if end < 0 else end + 2
            continue
        if ch in ("'", '"', "`"):
            quote = ch
        elif ch in "([{":
            depth += 1
        elif ch in ")]}" and depth:
            depth -= 1
        elif depth == 0 and ch in terminators:
            break
        i += 1
    while i > start and code[i - 1].isspace():
        i -= 1
    return i


def _skip_js_space_and_comments(code: str, start: int) -> int:
    i = start
    while i < len(code):
        if code[i].isspace():
            i += 1
            continue
        if code.startswith("//", i):
            newline = code.find("\n", i + 2)
            return len(code) if newline < 0 else _skip_js_space_and_comments(code, newline + 1)
        if code.startswith("/*", i):
            end = code.find("*/", i + 2)
            return len(code) if end < 0 else _skip_js_space_and_comments(code, end + 2)
        break
    return i


def _mask_js_non_code(code: str) -> str:
    masked = list(code)
    i = 0
    while i < len(code):
        if code.startswith("//", i):
            end = code.find("\n", i + 2)
            end = len(code) if end < 0 else end
            for pos in range(i, end):
                masked[pos] = " "
            i = end
            continue
        if code.startswith("/*", i):
            end = code.find("*/", i + 2)
            end = len(code) if end < 0 else end + 2
            for pos in range(i, end):
                if masked[pos] not in "\r\n":
                    masked[pos] = " "
            i = end
            continue
        if code[i] in ("'", '"', "`"):
            quote = code[i]
            masked[i] = " "
            i += 1
            while i < len(code):
                ch = code[i]
                if ch == "\\":
                    masked[i] = " "
                    if i + 1 < len(code):
                        masked[i + 1] = " "
                    i += 2
                    continue
                if ch == quote:
                    masked[i] = " "
                    i += 1
                    break
                if ch not in "\r\n":
                    masked[i] = " "
                i += 1
            continue
        i += 1
    return "".join(masked)


def _load_explicit_refs(
    ref_specs: Sequence[str] | None,
    asset_manifest: str | Path | Mapping[str, object] | None,
    search_dirs: list[Path],
    working_dir: Path,
) -> dict[str, Path]:
    refs: dict[str, Path] = {}

    if asset_manifest is not None:
        manifest, manifest_base, manifest_source = _read_asset_manifest(
            asset_manifest, search_dirs, working_dir
        )
        files = manifest.get("files")
        if not isinstance(files, Mapping):
            raise ValueError(
                "[DOCX_ASSET_MANIFEST_INVALID]\n"
                f"source: {manifest_source}\n"
                "reason: top-level 'files' must be a remote-path to local-path mapping"
            )
        for raw_remote, descriptor in files.items():
            if not isinstance(raw_remote, str):
                raise ValueError(
                    "[DOCX_ASSET_MANIFEST_INVALID]\n"
                    f"source: {manifest_source}\n"
                    "reason: every files key must be a string remote path"
                )
            raw_local = _manifest_local_path(descriptor, raw_remote, manifest_source)
            local = _resolve_declared_local_path(raw_local, [manifest_base])
            if local is None:
                raise FileNotFoundError(
                    "[DOCX_REF_LOCAL_NOT_FOUND]\n"
                    f"source: {manifest_source}\n"
                    f"remote: {raw_remote}\n"
                    f"local: {raw_local}\n"
                    f"resolved_from: {manifest_base}"
                )
            remote = _validate_remote_ref_path(raw_remote, manifest_source)
            _check_ref_size(local)
            _add_ref(refs, remote, local, source=manifest_source)

    if ref_specs is not None:
        if isinstance(ref_specs, (str, bytes)):
            raise ValueError(
                "[DOCX_REF_INVALID]\nreason: ref_specs must be a sequence of remote=local strings"
            )
        for spec in ref_specs:
            if not isinstance(spec, str) or "=" not in spec:
                raise ValueError(
                    "[DOCX_REF_INVALID]\n"
                    f"spec: {spec!r}\n"
                    "reason: each ref must use remote=local format"
                )
            raw_remote, raw_local = spec.split("=", 1)
            remote = _validate_remote_ref_path(raw_remote.strip(), f"ref {spec!r}")
            raw_local = raw_local.strip()
            if not raw_local:
                raise ValueError(
                    "[DOCX_REF_INVALID]\n"
                    f"spec: {spec!r}\n"
                    "reason: local path cannot be empty"
                )
            local = _resolve_declared_local_path(raw_local, [working_dir, *search_dirs])
            if local is None:
                searched = ", ".join(
                    str(path) for path in _dedupe_dirs([working_dir, *search_dirs])
                )
                raise FileNotFoundError(
                    "[DOCX_REF_LOCAL_NOT_FOUND]\n"
                    f"spec: {spec!r}\n"
                    f"local: {raw_local}\n"
                    f"searched: {searched}"
                )
            _check_ref_size(local)
            _add_ref(refs, remote, local, source=f"ref {spec!r}")

    return refs


def _read_asset_manifest(
    asset_manifest: str | Path | Mapping[str, object],
    search_dirs: list[Path],
    working_dir: Path,
) -> tuple[Mapping[str, object], Path, str]:
    if isinstance(asset_manifest, Mapping):
        return asset_manifest, working_dir, "in-memory asset manifest"

    raw_path = Path(asset_manifest).expanduser()
    candidates = (
        [raw_path]
        if raw_path.is_absolute()
        else [working_dir / raw_path, *(base / raw_path for base in search_dirs)]
    )
    manifest_path = _first_existing_file(candidates)
    if manifest_path is None:
        raise FileNotFoundError(
            "[DOCX_ASSET_MANIFEST_NOT_FOUND]\n"
            f"path: {asset_manifest}\n"
            f"searched: {', '.join(str(path) for path in candidates)}"
        )
    try:
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError(
            "[DOCX_ASSET_MANIFEST_INVALID]\n"
            f"source: {manifest_path}\n"
            f"reason: {exc}"
        ) from exc
    if not isinstance(data, Mapping):
        raise ValueError(
            "[DOCX_ASSET_MANIFEST_INVALID]\n"
            f"source: {manifest_path}\n"
            "reason: the JSON root must be an object"
        )
    return data, manifest_path.parent, str(manifest_path)


def _manifest_local_path(descriptor: object, remote: str, source: str) -> str:
    if isinstance(descriptor, str):
        return descriptor
    if isinstance(descriptor, Mapping):
        for key in ("local", "path", "source"):
            value = descriptor.get(key)
            if isinstance(value, str) and value.strip():
                return value
    raise ValueError(
        "[DOCX_ASSET_MANIFEST_INVALID]\n"
        f"source: {source}\n"
        f"remote: {remote}\n"
        "reason: files values must be local path strings or objects with local/path/source"
    )


def _resolve_declared_local_path(raw_path: str, bases: list[Path]) -> Path | None:
    normalized = raw_path.replace("\\", os.sep).replace("/", os.sep)
    candidate = Path(normalized).expanduser()
    candidates = [candidate] if candidate.is_absolute() else [base / candidate for base in bases]
    return _first_existing_file(candidates)


def _validate_remote_ref_path(raw_path: str, source: str) -> str:
    normalized = _normalize_js_path(raw_path.strip())
    parts = raw_path.replace("\\", "/").split("/")
    if chr(0) in raw_path or ".." in parts or not _is_safe_ref_path(normalized):
        raise ValueError(
            "[DOCX_REF_INVALID]\n"
            f"source: {source}\n"
            f"remote: {raw_path!r}\n"
            "reason: remote path must be a safe POSIX relative path without '..'"
        )
    return normalized


def _add_ref(refs: dict[str, Path], remote: str, local: Path, source: str) -> None:
    existing = refs.get(remote)
    if existing is not None and existing.resolve() != local.resolve():
        raise ValueError(
            "[DOCX_RESOURCE_CONFLICT]\n"
            f"remote: {remote}\n"
            f"existing_local: {existing}\n"
            f"new_local: {local}\n"
            f"new_source: {source}"
        )
    refs[remote] = local


def _unresolved_resource_message(
    code: str,
    resource: _ResourceExpression,
    reason: str,
) -> str:
    line = code.count("\n", 0, resource.start) + 1
    allowed = "\n".join(f"  - {form}" for form in _ALLOWED_RESOURCE_FORMS)
    return (
        "[DOCX_RESOURCE_PATH_UNRESOLVED]\n"
        f"call: {resource.label}\n"
        f"line: {line}\n"
        f"expression: {resource.expression or '<empty>'}\n"
        f"reason: {reason}\n"
        f"allowed_forms:\n{allowed}\n"
        "fallback: use a remote relative string in JS and pass "
        "--ref 'images/photo.jpg=/local/photo.jpg', or use --asset-manifest"
    )


def _missing_resource_message(
    code: str,
    resource: _ResourceExpression,
    resolved_path: str,
    search_dirs: list[Path],
) -> str:
    line = code.count("\n", 0, resource.start) + 1
    return (
        "[DOCX_RESOURCE_NOT_FOUND]\n"
        f"call: {resource.label}\n"
        f"line: {line}\n"
        f"expression: {resource.expression}\n"
        f"resolved_path: {resolved_path}\n"
        f"searched: {', '.join(str(path) for path in search_dirs)}\n"
        "fallback: place the file under a searched directory, or use a remote relative "
        "string in JS with --ref REMOTE=LOCAL or --asset-manifest"
    )


def _unsupported_remote_resource_message(
    code: str,
    resource: _ResourceExpression,
    resolved_path: str,
) -> str:
    line = code.count("\n", 0, resource.start) + 1
    return (
        "[DOCX_REMOTE_RESOURCE_UNSUPPORTED]\n"
        f"call: {resource.label}\n"
        f"line: {line}\n"
        f"expression: {resource.expression}\n"
        f"resolved_path: {resolved_path}\n"
        "reason: DOCX helpers read uploaded local files and cannot fetch http, data, "
        "or blob URLs\n"
        "fallback: download the resource first, use a relative path in JS, and pass "
        "--ref REMOTE=LOCAL or --asset-manifest"
    )


def _quote_js_string(value: str) -> str:
    escaped = (
        value.replace("\\", "\\\\")
        .replace("'", "\\'")
        .replace("\r", "\\r")
        .replace("\n", "\\n")
    )
    return f"'{escaped}'"


def _resolve_resource_path(raw_path: str, search_dirs: list[Path]) -> Path | None:
    path_value = _path_from_js_string(raw_path)
    if not path_value:
        return None

    path_value = path_value.replace("\\", os.sep).replace("/", os.sep)
    candidate = Path(path_value).expanduser()
    if candidate.is_absolute():
        return _first_existing_file([candidate])

    candidates = [base / candidate for base in search_dirs]
    found = _first_existing_file(candidates)
    if found:
        return found

    # 脚本已在 novel/ 下时，模型仍写 novel/images/x.jpg → 再试 images/x.jpg
    parts = Path(path_value).parts
    if len(parts) >= 2:
        stripped = Path(*parts[1:])
        extra = []
        for base in search_dirs:
            extra.append(base / stripped)
            if parts[0].lower() == base.name.lower():
                extra.append(base / stripped)
        found = _first_existing_file(extra)
        if found:
            return found

    return None


def _path_from_js_string(value: str) -> str | None:
    value = value.strip()
    if _is_remote_or_data(value):
        return None
    if value.startswith("file://"):
        return urllib.parse.unquote(urllib.parse.urlparse(value).path)
    return value


def _is_remote_or_data(value: str) -> bool:
    lower = value.lower()
    return lower.startswith(("http://", "https://", "data:", "blob:"))


def _first_existing_file(candidates: list[Path]) -> Path | None:
    for candidate in candidates:
        path = candidate.expanduser()
        if path.is_file():
            return path
    return None


def _workspace_dir() -> Path | None:
    raw = (os.environ.get("WORKSPACE_DIR") or "").strip()
    if not raw:
        return None
    path = Path(raw).expanduser().resolve()
    return path if path.is_dir() else None


def _resource_search_dirs(
    script_dir: Path,
    working_dir: Path,
    output_dir: Path,
) -> list[Path]:
    """JS 常在 js/、script/；generate_image 落在工作区 images/。向上找到会话根。

    h.img / --ref 禁止 ``..``，所以必须在客户端把工作区 images/ 收进搜索路径，
    否则模型只能拷图或重写路径再 create。
    """
    workspace = _workspace_dir()
    if workspace is not None:
        extra = [workspace, *_script_ancestor_dirs(script_dir)]
    else:
        extra = _script_ancestor_dirs(script_dir, max_levels=1)
    return _dedupe_dirs(
        [path.resolve() for path in (script_dir, working_dir, output_dir, *extra)]
    )


def _script_ancestor_dirs(
    script_dir: Path,
    *,
    max_levels: int = REFERENCES_WALK_UP_LEVELS,
) -> list[Path]:
    """Parents of script_dir, capped by max_levels and WORKSPACE_DIR (if set)."""
    workspace = _workspace_dir()
    ancestors: list[Path] = []
    current = script_dir.resolve()
    for _ in range(max(0, max_levels)):
        parent = current.parent
        if parent == current:
            break
        if workspace is not None:
            try:
                parent.relative_to(workspace)
            except ValueError:
                break
        ancestors.append(parent)
        if workspace is not None and parent == workspace:
            break
        current = parent
    return ancestors


def _find_references_json(search_dirs: list[Path], script_dir: Path) -> Path | None:
    """Locate references.json beside the script, then walk up toward the workspace root."""
    candidates = [directory / "references.json" for directory in search_dirs]
    found = _first_existing_file(candidates)
    if found:
        return found
    return _first_existing_file(
        [directory / "references.json" for directory in _script_ancestor_dirs(script_dir)]
    )


def _remote_ref_path(raw_path: str, local: Path, roots: list[Path]) -> str:
    if local.name == "references.json":
        return "references.json"

    normalized = _normalize_js_path(raw_path)
    if normalized and _is_safe_ref_path(normalized):
        return normalized

    relative_candidates: list[str] = []
    for root in roots:
        try:
            rel = local.relative_to(root).as_posix()
        except ValueError:
            continue
        if _is_safe_ref_path(rel):
            relative_candidates.append(rel)
    if relative_candidates:
        return min(
            relative_candidates,
            key=lambda value: (len(value.split("/")), len(value), value),
        )

    digest = hashlib.sha256(str(local).encode("utf-8")).hexdigest()[:12]
    safe_name = re.sub(r"[^A-Za-z0-9._-]+", "_", local.name) or "asset"
    return f"assets/{digest}_{safe_name}"


def _normalize_js_path(path_value: str) -> str:
    normalized = path_value.replace("\\", "/")
    while normalized.startswith("./"):
        normalized = normalized[2:]
    return posixpath.normpath(normalized)


def _is_safe_ref_path(path_value: str) -> bool:
    path_value = path_value.replace("\\", "/")
    if not path_value or path_value in {".", ".."}:
        return False
    if path_value.startswith("/") or re.match(r"^[A-Za-z]:/", path_value):
        return False
    normalized = posixpath.normpath(path_value)
    return normalized != ".." and not normalized.startswith("../")


def _dedupe_dirs(paths: list[Path]) -> list[Path]:
    out: list[Path] = []
    seen: set[str] = set()
    for path in paths:
        expanded = path.expanduser()
        key = str(expanded)
        if key not in seen:
            out.append(expanded)
            seen.add(key)
    return out


def _check_ref_size(path: Path) -> None:
    max_bytes = int(os.environ.get("DOCX_TRANSCODER_MAX_REF_BYTES", MAX_REF_BYTES))
    size = path.stat().st_size
    if size > max_bytes:
        raise ValueError(f"reference file is too large: {path} ({size} bytes > {max_bytes})")


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if len(argv) != 2:
        print("usage: docx_transcoder_client.py <script.js> <output.docx>", file=sys.stderr)
        return 2
    create_docx(argv[0], argv[1])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
