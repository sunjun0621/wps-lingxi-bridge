from __future__ import annotations

import hashlib
import json
import os
import re
import stat
import tempfile
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable


PATCH_BEGIN = "*** Begin Patch"
PATCH_END = "*** End Patch"
UPDATE_PREFIX = "*** Update File: "
HISTORY_DIR = ".docx-source-history"
_REVISION_RE = re.compile(r"^[0-9a-f]{64}$")


class SourcePatchError(ValueError):
    """Raised when a source transaction cannot be committed safely."""


@dataclass(frozen=True)
class PatchHunk:
    before: tuple[str, ...]
    after: tuple[str, ...]
    context_lines: int


@dataclass(frozen=True)
class ParsedPatch:
    target: str
    hunks: tuple[PatchHunk, ...]


Validator = Callable[[str], dict[str, Any]]


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def source_status(script_path: str | Path) -> dict[str, Any]:
    script = _source_path(script_path)
    data = script.read_bytes()
    source = _decode_source(data, script)
    return {
        "ok": True,
        "path": str(script),
        "revision": sha256_bytes(data),
        "bytes": len(data),
        "lines": len(source.splitlines()),
    }


def parse_patch(patch_text: str) -> ParsedPatch:
    lines = patch_text.splitlines()
    if len(lines) < 5 or lines[0] != PATCH_BEGIN or lines[-1] != PATCH_END:
        raise SourcePatchError(
            f"Patch must start with {PATCH_BEGIN!r} and end with {PATCH_END!r}."
        )
    if not lines[1].startswith(UPDATE_PREFIX):
        raise SourcePatchError(f"Patch must declare one {UPDATE_PREFIX.strip()!r} target.")

    target = lines[1][len(UPDATE_PREFIX) :].strip()
    if not target:
        raise SourcePatchError("Patch target is empty.")

    body = lines[2:-1]
    hunks: list[PatchHunk] = []
    index = 0
    while index < len(body):
        if body[index] != "@@":
            raise SourcePatchError(
                f"Expected '@@' before hunk {len(hunks) + 1}; got {body[index]!r}."
            )
        index += 1
        before: list[str] = []
        after: list[str] = []
        context_lines = 0
        changed = False

        while index < len(body) and body[index] != "@@":
            line = body[index]
            if not line or line[0] not in " +-":
                raise SourcePatchError(
                    "Every hunk line must start with one context (' '), add ('+'), "
                    "or remove ('-') marker."
                )
            marker, content = line[0], line[1:]
            if marker == " ":
                before.append(content)
                after.append(content)
                context_lines += 1
            elif marker == "-":
                before.append(content)
                changed = True
            else:
                after.append(content)
                changed = True
            index += 1

        if not changed:
            raise SourcePatchError(f"Hunk {len(hunks) + 1} does not change any lines.")
        if not context_lines:
            raise SourcePatchError(
                f"Hunk {len(hunks) + 1} needs at least one unchanged context line."
            )
        if not before:
            raise SourcePatchError(f"Hunk {len(hunks) + 1} has no source context to match.")
        hunks.append(PatchHunk(tuple(before), tuple(after), context_lines))

    if not hunks:
        raise SourcePatchError("Patch contains no hunks.")
    return ParsedPatch(target=target, hunks=tuple(hunks))


def apply_source_patch(
    script_path: str | Path,
    patch_path: str | Path,
    *,
    base_sha256: str,
    validator: Validator,
) -> dict[str, Any]:
    script = _source_path(script_path)
    patch_file = Path(patch_path).expanduser().resolve()
    if not patch_file.is_file():
        raise FileNotFoundError(f"Patch file does not exist: {patch_file}")

    patch = parse_patch(patch_file.read_text(encoding="utf-8"))
    _check_patch_target(script, patch.target)
    original = script.read_bytes()
    previous_revision = sha256_bytes(original)
    _check_base_revision(base_sha256, previous_revision)

    source = _decode_source(original, script)
    candidate_source = _apply_hunks(source, patch.hunks)
    candidate = candidate_source.encode("utf-8")
    revision = sha256_bytes(candidate)
    if revision == previous_revision:
        raise SourcePatchError("Patch produced no source change.")

    validation = _validate_candidate(
        candidate_source,
        revision,
        validator,
        require_valid=True,
    )
    _commit(script, original, candidate, previous_revision)
    result = {
        "ok": True,
        "path": str(script),
        "previous_revision": previous_revision,
        "revision": revision,
        "hunks": len(patch.hunks),
    }
    if validation.get("validator"):
        result["validator"] = validation["validator"]
    return result


def undo_source_patch(
    script_path: str | Path,
    revision: str,
    *,
    base_sha256: str,
    validator: Validator,
) -> dict[str, Any]:
    script = _source_path(script_path)
    if not _REVISION_RE.fullmatch(revision):
        raise SourcePatchError("Undo revision must be a 64-character lowercase SHA-256.")

    current = script.read_bytes()
    current_revision = sha256_bytes(current)
    _check_base_revision(base_sha256, current_revision)
    history_file = _history_file(script, revision)
    if not history_file.is_file():
        raise SourcePatchError(f"Revision is not available for {script.name}: {revision}")

    restored = history_file.read_bytes()
    if sha256_bytes(restored) != revision:
        raise SourcePatchError(f"Stored revision failed its SHA-256 check: {revision}")
    restored_source = _decode_source(restored, history_file)
    validation = _validate_candidate(
        restored_source,
        revision,
        validator,
        require_valid=False,
    )
    _commit(script, current, restored, current_revision)
    result = {
        "ok": True,
        "path": str(script),
        "previous_revision": current_revision,
        "revision": revision,
        "action": "undo",
        "valid": bool(validation.get("valid")),
    }
    if validation.get("validator"):
        result["validator"] = validation["validator"]
    if validation.get("diagnostic"):
        result["diagnostic"] = validation["diagnostic"]
    return result


def _source_path(script_path: str | Path) -> Path:
    script = Path(script_path).expanduser().resolve()
    if not script.is_file():
        raise FileNotFoundError(f"JS source file does not exist: {script}")
    if script.suffix.lower() not in {".js", ".cjs"}:
        raise SourcePatchError(f"DOCX source must be a JavaScript file: {script}")
    return script


def _decode_source(data: bytes, path: Path) -> str:
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise SourcePatchError(f"DOCX source must be UTF-8: {path}: {exc}") from None


def _check_base_revision(expected: str, actual: str) -> None:
    if not _REVISION_RE.fullmatch(expected or ""):
        raise SourcePatchError("base_sha256 must be a 64-character lowercase SHA-256.")
    if expected != actual:
        raise SourcePatchError(
            "Source revision changed; read the current context and status again. "
            f"expected={expected} actual={actual}"
        )


def _check_patch_target(script: Path, declared: str) -> None:
    target = Path(declared).expanduser()
    candidates = []
    if target.is_absolute():
        candidates.append(target.resolve())
    else:
        candidates.extend(
            ((script.parent / target).resolve(), (Path.cwd() / target).resolve())
        )
    if script not in candidates:
        raise SourcePatchError(
            f"Patch target {declared!r} does not match requested source {str(script)!r}."
        )


def _split_source_lines(source: str) -> tuple[list[str], list[str]]:
    raw_lines = source.splitlines(keepends=True)
    contents: list[str] = []
    endings: list[str] = []
    for raw in raw_lines:
        content = raw.rstrip("\r\n")
        contents.append(content)
        endings.append(raw[len(content) :])
    return contents, endings


def _apply_hunks(source: str, hunks: tuple[PatchHunk, ...]) -> str:
    contents, endings = _split_source_lines(source)
    newline = next((ending for ending in endings if ending), "\n")
    matches: list[tuple[int, int, PatchHunk]] = []

    for number, hunk in enumerate(hunks, start=1):
        width = len(hunk.before)
        positions = [
            start
            for start in range(0, len(contents) - width + 1)
            if tuple(contents[start : start + width]) == hunk.before
        ]
        if not positions:
            raise SourcePatchError(
                f"Hunk {number} context was not found; read the current source and rebuild the patch."
            )
        if len(positions) > 1:
            raise SourcePatchError(
                f"Hunk {number} context matched {len(positions)} locations; include more unchanged lines."
            )
        start = positions[0]
        matches.append((start, start + width, hunk))

    ordered = sorted(matches, key=lambda item: (item[0], item[1]))
    for previous, current in zip(ordered, ordered[1:]):
        if current[0] < previous[1]:
            raise SourcePatchError("Patch hunks overlap; combine them into one contextual hunk.")

    offsets = [0]
    for content, ending in zip(contents, endings):
        offsets.append(offsets[-1] + len(content) + len(ending))

    candidate = source
    for start, end, hunk in sorted(
        matches, key=lambda item: (item[0], item[1]), reverse=True
    ):
        replacement = newline.join(hunk.after)
        if end > start and endings[end - 1]:
            replacement += endings[end - 1]
        candidate = candidate[: offsets[start]] + replacement + candidate[offsets[end] :]
    return candidate


def _validate_candidate(
    source: str,
    revision: str,
    validator: Validator,
    *,
    require_valid: bool,
) -> dict[str, Any]:
    try:
        from .docx_lint import scan_js_structure
    except ImportError:
        from docx_lint import scan_js_structure

    _, structure_errors = scan_js_structure(source)
    result = validator(source)
    server_revision = str(result.get("sha256") or "")
    if server_revision != revision:
        raise SourcePatchError(
            "Server validated a different source revision; the local file was not changed. "
            f"expected={revision} server={server_revision or '<missing>'}"
        )
    if require_valid and not result.get("valid"):
        diagnostic: dict[str, Any] = {"server": result.get("diagnostic") or {}}
        if structure_errors:
            diagnostic["local_structure"] = structure_errors
        raise SourcePatchError(
            "Candidate failed server JavaScript syntax validation:\n"
            + json.dumps(diagnostic, ensure_ascii=False, indent=2)
        )
    return result


def _history_file(script: Path, revision: str) -> Path:
    return script.parent / HISTORY_DIR / script.name / f"{revision}.js"


def _commit(script: Path, expected: bytes, candidate: bytes, previous_revision: str) -> None:
    history_file = _history_file(script, previous_revision)
    history_file.parent.mkdir(parents=True, exist_ok=True)
    with _transaction_lock(history_file.parent / ".lock"):
        if script.read_bytes() != expected:
            raise SourcePatchError(
                "Source changed while the candidate was being validated; no changes were committed."
            )

        mode = stat.S_IMODE(script.stat().st_mode)
        if history_file.exists():
            if history_file.read_bytes() != expected:
                raise SourcePatchError(f"Revision history collision: {history_file}")
        else:
            _atomic_write(history_file, expected, 0o600)

        if script.read_bytes() != expected:
            raise SourcePatchError(
                "Source changed while revision history was being saved; no source change was committed."
            )
        _atomic_write(script, candidate, mode)


@contextmanager
def _transaction_lock(lock_path: Path):
    with lock_path.open("a+b") as handle:
        if os.name == "nt":
            try:
                import msvcrt
            except ImportError as exc:
                raise SourcePatchError("Source transaction locking is unavailable.") from exc

            handle.seek(0, os.SEEK_END)
            if handle.tell() == 0:
                handle.write(b"\0")
                handle.flush()
            handle.seek(0)
            try:
                msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
            except OSError as exc:
                raise SourcePatchError(f"Could not lock DOCX source transaction: {exc}") from None
            try:
                yield
            finally:
                handle.seek(0)
                try:
                    msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
                except OSError:
                    pass
            return

        try:
            import fcntl
        except ImportError as exc:
            raise SourcePatchError("Source transaction locking is unavailable.") from exc

        try:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        except OSError as exc:
            raise SourcePatchError(f"Could not lock DOCX source transaction: {exc}") from None
        try:
            yield
        finally:
            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
            except OSError:
                pass


def _atomic_write(path: Path, data: bytes, mode: int) -> None:
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    temp_path = Path(temp_name)
    try:
        with os.fdopen(fd, "wb") as handle:
            try:
                os.fchmod(handle.fileno(), mode)
            except (AttributeError, OSError):
                try:
                    os.chmod(temp_path, mode)
                except OSError:
                    pass
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, path)
        try:
            dir_fd = os.open(path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        except OSError:
            return
        try:
            try:
                os.fsync(dir_fd)
            except OSError:
                pass
        finally:
            os.close(dir_fd)
    finally:
        if temp_path.exists():
            temp_path.unlink()


__all__ = [
    "SourcePatchError",
    "apply_source_patch",
    "parse_patch",
    "sha256_bytes",
    "source_status",
    "undo_source_patch",
]
