from __future__ import annotations

import bisect
import re
from collections.abc import Mapping
from pathlib import Path
from typing import Any


_OPEN_TO_CLOSE = {"(": ")", "[": "]", "{": "}"}
_CLOSE_TO_OPEN = {value: key for key, value in _OPEN_TO_CLOSE.items()}
_REGEX_PREFIX_KEYWORDS = {
    "await",
    "case",
    "delete",
    "do",
    "else",
    "in",
    "instanceof",
    "of",
    "return",
    "throw",
    "typeof",
    "void",
    "yield",
}


def _issue(code: str, message: str, source: str, index: int | None = None) -> dict[str, Any]:
    issue: dict[str, Any] = {"code": code, "message": message}
    if index is not None:
        line, column = _line_column(source, index)
        issue.update({"line": line, "column": column})
    return issue


def _line_column(source: str, index: int) -> tuple[int, int]:
    newlines = [-1]
    newlines.extend(pos for pos, char in enumerate(source) if char == "\n")
    line_index = bisect.bisect_left(newlines, index)
    return line_index, index - newlines[line_index - 1]


def _mask_range(masked: list[str], start: int, end: int) -> None:
    for index in range(start, min(end, len(masked))):
        if masked[index] not in "\r\n":
            masked[index] = " "


def _consume_quoted(source: str, start: int, quote: str) -> tuple[int, bool]:
    index = start + 1
    while index < len(source):
        char = source[index]
        if char == "\\":
            index += 2
            continue
        if char == quote:
            return index + 1, True
        if char in "\r\n" and quote != "`":
            return index, False
        index += 1
    return len(source), False


def _consume_regex(source: str, start: int) -> tuple[int, bool]:
    index = start + 1
    in_character_class = False
    while index < len(source):
        char = source[index]
        if char == "\\":
            index += 2
            continue
        if char in "\r\n":
            return index, False
        if char == "[":
            in_character_class = True
        elif char == "]":
            in_character_class = False
        elif char == "/" and not in_character_class:
            index += 1
            while index < len(source) and (source[index].isalpha() or source[index].isdigit()):
                index += 1
            return index, True
        index += 1
    return len(source), False


def scan_js_structure(source: str) -> tuple[str, list[dict[str, Any]]]:
    """Mask JS strings/comments/regexes and report incomplete delimiters.

    Lightweight client-side gate for truncated appends. Authoritative JS syntax
    checking stays on the office-transcoder runner.
    """

    masked = list(source)
    errors: list[dict[str, Any]] = []
    stack: list[tuple[str, int]] = []
    index = 0
    can_start_regex = True

    while index < len(source):
        char = source[index]
        following = source[index + 1] if index + 1 < len(source) else ""

        if char.isspace():
            index += 1
            continue

        if char == "/" and following == "/":
            end = source.find("\n", index + 2)
            end = len(source) if end < 0 else end
            _mask_range(masked, index, end)
            index = end
            continue

        if char == "/" and following == "*":
            closing = source.find("*/", index + 2)
            if closing < 0:
                _mask_range(masked, index, len(source))
                errors.append(
                    _issue("UNCLOSED_COMMENT", "Unclosed block comment.", source, index)
                )
                break
            end = closing + 2
            _mask_range(masked, index, end)
            index = end
            continue

        if char in "'\"`":
            end, closed = _consume_quoted(source, index, char)
            _mask_range(masked, index, end)
            if not closed:
                label = "template string" if char == "`" else "string literal"
                errors.append(
                    _issue("UNCLOSED_STRING", f"Unclosed {label}.", source, index)
                )
                break
            index = end
            can_start_regex = False
            continue

        if char == "/" and following not in "/=*" and can_start_regex:
            end, closed = _consume_regex(source, index)
            _mask_range(masked, index, end)
            if not closed:
                errors.append(
                    _issue("UNCLOSED_REGEX", "Unclosed regular expression literal.", source, index)
                )
                break
            index = end
            can_start_regex = False
            continue

        if char.isalpha() or char in "_$":
            end = index + 1
            while end < len(source) and (source[end].isalnum() or source[end] in "_$"):
                end += 1
            token = source[index:end]
            can_start_regex = token in _REGEX_PREFIX_KEYWORDS
            index = end
            continue

        if char.isdigit():
            end = index + 1
            while end < len(source) and (source[end].isalnum() or source[end] in "._"):
                end += 1
            index = end
            can_start_regex = False
            continue

        if char in _OPEN_TO_CLOSE:
            stack.append((char, index))
            can_start_regex = True
        elif char in _CLOSE_TO_OPEN:
            expected_open = _CLOSE_TO_OPEN[char]
            if not stack or stack[-1][0] != expected_open:
                expected = _OPEN_TO_CLOSE[stack[-1][0]] if stack else "no closing delimiter"
                errors.append(
                    _issue(
                        "MISMATCHED_BRACKET",
                        f"Unexpected {char!r}; expected {expected!r}.",
                        source,
                        index,
                    )
                )
            else:
                stack.pop()
            can_start_regex = False
        else:
            can_start_regex = char in ",:;=!?&|+-*%^~<>"
        index += 1

    for opening, opening_index in reversed(stack):
        errors.append(
            _issue(
                "UNCLOSED_BRACKET",
                f"Unclosed {opening!r}; expected {_OPEN_TO_CLOSE[opening]!r}.",
                source,
                opening_index,
            )
        )

    return "".join(masked), errors


def _top_level_h_calls(masked: str, source: str) -> list[dict[str, Any]]:
    calls: list[dict[str, Any]] = []
    depth = 0
    line_start = 0
    index = 0

    while index < len(masked):
        char = masked[index]
        if char == "\n":
            line_start = index + 1
        if char in "([{":
            depth += 1
        elif char in ")]}" and depth:
            depth -= 1

        if depth == 0 and char == "h" and (index == 0 or not (masked[index - 1].isalnum() or masked[index - 1] in "_$")):
            match = re.match(r"h\s*\.\s*([A-Za-z_$][\w$]*)\s*\(", masked[index:])
            if match:
                prefix = masked[line_start:index].strip()
                method = match.group(1)
                if not prefix and method != "build":
                    calls.append(
                        _issue(
                            "TOP_LEVEL_HELPER_CALL",
                            f"Top-level h.{method}() is not attached to a children array. "
                            "Return it from a complete function block or include it in h.build().",
                            source,
                            index,
                        )
                    )
                index += match.end()
                continue
        index += 1
    return calls


def _has_top_level_build(masked: str) -> bool:
    depth = 0
    index = 0
    while index < len(masked):
        char = masked[index]
        if char in "([{":
            depth += 1
        elif char in ")]}" and depth:
            depth -= 1
        elif depth == 0 and char == "h":
            if re.match(r"h\s*\.\s*build\s*\(", masked[index:]):
                return True
        index += 1
    return False


def format_lint_failure(result: dict[str, Any]) -> str:
    """Human-readable summary for create preflight failures."""
    lines = [f"DOCX script preflight failed ({len(result.get('errors') or [])} issue(s)):"]
    for error in result.get("errors") or []:
        loc = ""
        if "line" in error:
            loc = f"line {error['line']}"
            if "column" in error:
                loc += f":{error['column']}"
            loc += " "
        code = error.get("code", "ERROR")
        message = error.get("message", "")
        lines.append(f"  • [{code}] {loc}{message}".rstrip())
    lines.append(
        "Read the reported source context, then use file(action=edit) with "
        "exact find/replace; re-run docx.sh create after the edit."
    )
    return "\n".join(lines)


def lint_docx_script(
    script_path: str | Path,
    *,
    cwd: str | Path | None = None,
    output: str | Path | None = None,
    partial: bool = False,
    ref_specs: list[str] | None = None,
    asset_manifest: str | Path | Mapping[str, object] | None = None,
) -> dict[str, Any]:
    """Thin client preflight: structure, helper placement, h.build, local resources.

    Intended to run automatically inside ``docx.sh create`` before the remote call.
    Does not require local Node; authoritative syntax checks stay server-side.
    ``partial=True`` is for internal/tests only (allows a missing ``h.build()``).
    """
    script = Path(script_path).expanduser()
    mode = "partial" if partial else "final"
    result: dict[str, Any] = {
        "ok": False,
        "path": str(script),
        "mode": mode,
        "checks": {
            "structure": False,
            "top_level_helpers": False,
            "build": False,
            "resources": False,
        },
        "resources": [],
        "errors": [],
        "warnings": [],
    }

    if not script.is_file():
        result["errors"].append(
            {
                "code": "SCRIPT_NOT_FOUND",
                "message": (
                    f"JS script does not exist: {script}. Pass the path directly to "
                    "docx.sh create; do not embed Windows or Git Bash paths inside python -c."
                ),
            }
        )
        return result

    source = script.read_text(encoding="utf-8")
    masked, structure_errors = scan_js_structure(source)
    result["errors"].extend(structure_errors)
    result["checks"]["structure"] = not structure_errors

    top_level_errors = _top_level_h_calls(masked, source)
    result["errors"].extend(top_level_errors)
    result["checks"]["top_level_helpers"] = not top_level_errors

    has_build = _has_top_level_build(masked)
    if has_build:
        result["checks"]["build"] = True
    elif partial:
        result["checks"]["build"] = True
        result["warnings"].append(
            {
                "code": "BUILD_PENDING",
                "message": "h.build() is not present yet; allowed only in partial mode.",
            }
        )
    else:
        result["errors"].append(
            {
                "code": "BUILD_MISSING",
                "message": "DOCX script must call h.build() before create.",
            }
        )

    try:
        from docx_transcoder_client import _prepare_remote_payload

        working_dir = Path(cwd).expanduser() if cwd else script.parent
        output_path = Path(output).expanduser() if output else script.with_suffix(".docx")
        _, resources = _prepare_remote_payload(
            source,
            script,
            output_path,
            working_dir,
            ref_specs=ref_specs,
            asset_manifest=asset_manifest,
        )
        result["resources"] = [
            {"remote": remote, "local": str(local)}
            for remote, local in sorted(resources.items())
        ]
        result["checks"]["resources"] = True
    except (FileNotFoundError, ValueError, OSError) as exc:
        result["errors"].append({"code": "RESOURCE_ERROR", "message": str(exc)})

    result["ok"] = not result["errors"]
    return result


__all__ = ["format_lint_failure", "lint_docx_script", "scan_js_structure"]
