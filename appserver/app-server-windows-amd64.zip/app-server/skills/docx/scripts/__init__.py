"""DOCX skill sandbox entrypoints.

DOCX implementation code lives in office-transcoder.  The sandbox package only
contains a thin client used by docx_cli.py.
"""

from .docx_transcoder_client import create_docx

__all__ = ["create_docx"]
