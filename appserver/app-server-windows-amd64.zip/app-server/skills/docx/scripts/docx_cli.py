#!/usr/bin/env python3
"""DOCX CLI: remote creation and local editing utilities."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def _insert_scripts() -> None:
    scripts_dir = Path(__file__).parent
    if str(scripts_dir) not in sys.path:
        sys.path.insert(0, str(scripts_dir))


def cmd_create(args: argparse.Namespace) -> None:
    _insert_scripts()
    from docx_transcoder_client import create_docx

    create_docx(
        args.script,
        args.output,
        cwd=args.cwd,
        ref_specs=args.ref_specs,
        asset_manifest=args.asset_manifest,
    )


def cmd_lint(args: argparse.Namespace) -> None:
    _insert_scripts()
    from docx_lint import lint_docx_script

    result = lint_docx_script(
        args.script,
        cwd=args.cwd,
        output=args.output,
        partial=args.partial,
        ref_specs=args.ref_specs,
        asset_manifest=args.asset_manifest,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if not result["ok"]:
        raise SystemExit(1)


def cmd_inspect(args: argparse.Namespace) -> None:
    _insert_scripts()
    from inspect_docx import inspect_docx

    result = inspect_docx(args.input)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if not result["ok"]:
        raise SystemExit(1)


def cmd_source_status(args: argparse.Namespace) -> None:
    _insert_scripts()
    from source_patch import source_status

    print(json.dumps(source_status(args.script), ensure_ascii=False, indent=2))


def _source_validator():
    from docx_transcoder_client import validate_docx_source

    return validate_docx_source


def cmd_source_patch(args: argparse.Namespace) -> None:
    _insert_scripts()
    from source_patch import apply_source_patch

    result = apply_source_patch(
        args.script,
        args.patch,
        base_sha256=args.base_sha256,
        validator=_source_validator(),
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


def cmd_source_undo(args: argparse.Namespace) -> None:
    _insert_scripts()
    from source_patch import undo_source_patch

    result = undo_source_patch(
        args.script,
        args.revision,
        base_sha256=args.base_sha256,
        validator=_source_validator(),
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


def _unsupported(command: str) -> None:
    print(f"[ERROR] DOCX {command} is not available.", file=sys.stderr)
    sys.exit(2)


def cmd_edit(args: argparse.Namespace) -> None:
    _insert_scripts()
    from edit_docx import edit_docx

    replacements = []
    for item in args.replace:
        if "=" not in item:
            raise ValueError(f"--replace must use OLD=NEW format: {item!r}")
        old, new = item.split("=", 1)
        replacements.append({"from": old, "to": new})

    result = edit_docx(
        input_docx=args.input,
        output_docx=args.output,
        replacements=replacements,
        parts=args.parts or None,
        match_mode="regex" if args.regex else "literal",
        ignore_case=args.ignore_case,
    )
    for replacement in result.get("replacements_applied", []):
        print(
            f"  {replacement['from']!r} -> {replacement['to']!r}: "
            f"{replacement['count']} matches"
        )
    print(f"DOCX edited: {result['output_path']}")


def cmd_unpack(args: argparse.Namespace) -> None:
    _insert_scripts()
    from office.unpack import unpack_docx

    output = args.output or args.output_pos
    if not output:
        raise ValueError("unpack requires an output directory")
    unpack_docx(args.input, output)
    print(f"DOCX unpacked: {output}")


def cmd_pack(args: argparse.Namespace) -> None:
    _insert_scripts()
    from office.pack import pack_docx

    output = args.output or args.output_pos
    if not output:
        raise ValueError("pack requires an output DOCX path")
    pack_docx(args.input, output)
    print(f"DOCX packed: {output}")


def cmd_restore(args: argparse.Namespace) -> None:
    _unsupported("restore")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="docx_cli.py",
        description="DOCX creation and editing client",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_create = sub.add_parser("create", help="send JS code to office-transcoder to create DOCX")
    p_create.add_argument("script", help="JS script path")
    p_create.add_argument("-o", "--output", required=True, help="output DOCX file path")
    p_create.add_argument("--cwd", help="resource lookup directory; defaults to script directory")
    p_create.add_argument(
        "--ref",
        dest="ref_specs",
        action="append",
        default=[],
        metavar="REMOTE=LOCAL",
        help="explicit resource mapping; may be repeated",
    )
    p_create.add_argument(
        "--asset-manifest",
        help="JSON resource manifest path; pass the path as a CLI argument",
    )

    p_lint = sub.add_parser(
        "lint",
        help=argparse.SUPPRESS,  # internal; create runs this automatically
    )
    p_lint.add_argument(
        "script",
        help="JS script path; pass Windows/Git Bash paths directly",
    )
    p_lint.add_argument(
        "-o",
        "--output",
        help="planned output DOCX path used for resource lookup; defaults beside the script",
    )
    p_lint.add_argument("--cwd", help="resource lookup directory; defaults to script directory")
    p_lint.add_argument(
        "--partial",
        action="store_true",
        help="allow a missing h.build(); all JavaScript must still be complete and parseable",
    )
    p_lint.add_argument(
        "--ref",
        dest="ref_specs",
        action="append",
        default=[],
        metavar="REMOTE=LOCAL",
        help="explicit resource mapping; may be repeated",
    )
    p_lint.add_argument(
        "--asset-manifest",
        help="JSON resource manifest path; pass the path as a CLI argument",
    )

    p_inspect = sub.add_parser(
        "inspect",
        help="report DOCX completeness (refs/images/headings); see delivery_hint",
    )
    p_inspect.add_argument(
        "input",
        help="input DOCX path; pass Windows/Git Bash paths directly",
    )

    p_source_status = sub.add_parser(
        "source-status",
        help="report the current DOCX JavaScript source revision",
    )
    p_source_status.add_argument("script", help="DOCX JavaScript source path")

    p_source_patch = sub.add_parser(
        "source-patch",
        help="validate and atomically apply a contextual patch to DOCX JavaScript",
    )
    p_source_patch.add_argument("script", help="DOCX JavaScript source path")
    p_source_patch.add_argument("--patch", required=True, help="contextual patch file path")
    p_source_patch.add_argument(
        "--base-sha256",
        required=True,
        help="revision returned by source-status before the edit",
    )

    p_source_undo = sub.add_parser(
        "source-undo",
        help="validate and atomically restore a saved DOCX JavaScript revision",
    )
    p_source_undo.add_argument("script", help="DOCX JavaScript source path")
    p_source_undo.add_argument("--revision", required=True, help="saved revision to restore")
    p_source_undo.add_argument(
        "--base-sha256",
        required=True,
        help="current revision returned by source-status",
    )

    p_edit = sub.add_parser("edit", help="replace text in a local DOCX")
    p_edit.add_argument("input", help="input DOCX path")
    p_edit.add_argument("-o", "--output", required=True, help="output DOCX path")
    p_edit.add_argument(
        "--replace",
        metavar="OLD=NEW",
        action="append",
        default=[],
        help="replacement rule; may be repeated",
    )
    p_edit.add_argument("--regex", action="store_true", help="treat OLD as a regular expression")
    p_edit.add_argument("--ignore-case", action="store_true", help="ignore case while matching")
    p_edit.add_argument(
        "--parts",
        metavar="GLOB",
        action="append",
        default=[],
        help="limit edited XML parts; may be repeated",
    )

    p_unpack = sub.add_parser("unpack", help="unpack a local DOCX into XML parts")
    p_unpack.add_argument("input", help="input DOCX path")
    p_unpack.add_argument("output_pos", nargs="?", help="output directory")
    p_unpack.add_argument("-o", "--output", help="output directory")

    p_pack = sub.add_parser("pack", help="pack local XML parts into a DOCX")
    p_pack.add_argument("input", help="input directory")
    p_pack.add_argument("output_pos", nargs="?", help="output DOCX path")
    p_pack.add_argument("-o", "--output", help="output DOCX path")

    p_restore = sub.add_parser("restore", help="unsupported in sandbox")
    p_restore.add_argument("script", nargs="?")

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    commands = {
        "create": cmd_create,
        "lint": cmd_lint,
        "inspect": cmd_inspect,
        "source-status": cmd_source_status,
        "source-patch": cmd_source_patch,
        "source-undo": cmd_source_undo,
        "edit": cmd_edit,
        "unpack": cmd_unpack,
        "pack": cmd_pack,
        "restore": cmd_restore,
    }
    try:
        commands[args.command](args)
    except (FileNotFoundError, ValueError, RuntimeError, OSError) as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        raise SystemExit(1) from None


if __name__ == "__main__":
    main()
