from __future__ import annotations

import re
import zipfile
from collections import Counter
from pathlib import Path
from typing import Any

from lxml import etree

from office.validate import validate_docx


W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": W_NS}
IMAGE_EXTENSIONS = {
    ".avif",
    ".bmp",
    ".emf",
    ".gif",
    ".heic",
    ".jpeg",
    ".jpg",
    ".png",
    ".svg",
    ".tif",
    ".tiff",
    ".webp",
    ".wmf",
}
REFERENCE_HEADINGS = re.compile(
    r"^(?:(?:主要)?参考文献|references|bibliography)(?:\s|$|[:：(（])",
    re.I,
)
HEADING_STYLE = re.compile(r"(?:^|\s)(?:heading|标题)\s*([1-9])(?:\s|$)", re.I)


def _qn(local_name: str) -> str:
    return f"{{{W_NS}}}{local_name}"


def _paragraph_text(paragraph: etree._Element) -> str:
    return "".join(paragraph.xpath(".//w:t/text()", namespaces=NS)).strip()


def _style_metadata(archive: zipfile.ZipFile) -> tuple[dict[str, str], dict[str, int]]:
    names: dict[str, str] = {}
    levels: dict[str, int] = {}
    if "word/styles.xml" not in archive.namelist():
        return names, levels

    root = etree.fromstring(archive.read("word/styles.xml"))
    for style in root.xpath(".//w:style", namespaces=NS):
        style_id = style.get(_qn("styleId")) or ""
        if not style_id:
            continue
        name_nodes = style.xpath("./w:name", namespaces=NS)
        style_name = (name_nodes[0].get(_qn("val")) if name_nodes else "") or ""
        names[style_id] = style_name
        outline_nodes = style.xpath("./w:pPr/w:outlineLvl", namespaces=NS)
        outline_value = (outline_nodes[0].get(_qn("val")) if outline_nodes else "") or ""
        if outline_value.isdigit() and int(outline_value) < 9:
            levels[style_id] = int(outline_value) + 1
            continue
        heading_match = HEADING_STYLE.search(f"{style_id} {style_name}")
        if heading_match:
            levels[style_id] = int(heading_match.group(1))
    return names, levels


def _paragraph_heading_level(
    paragraph: etree._Element,
    style_names: dict[str, str],
    style_levels: dict[str, int],
) -> int | None:
    outline_nodes = paragraph.xpath("./w:pPr/w:outlineLvl", namespaces=NS)
    outline_value = (outline_nodes[0].get(_qn("val")) if outline_nodes else "") or ""
    if outline_value.isdigit() and int(outline_value) < 9:
        return int(outline_value) + 1

    style_nodes = paragraph.xpath("./w:pPr/w:pStyle", namespaces=NS)
    style_id = (style_nodes[0].get(_qn("val")) if style_nodes else "") or ""
    if style_id in style_levels:
        return style_levels[style_id]
    match = HEADING_STYLE.search(f"{style_id} {style_names.get(style_id, '') or ''}")
    return int(match.group(1)) if match else None


def _reference_count(texts: list[str], heading_levels: list[int | None]) -> int:
    count = 0
    in_references = False
    reference_level: int | None = None

    for text, level in zip(texts, heading_levels):
        normalized = re.sub(r"\s+", " ", text).strip()
        if REFERENCE_HEADINGS.match(normalized):
            in_references = True
            reference_level = level
            continue
        if not in_references:
            continue
        if level is not None and (reference_level is None or level <= reference_level):
            in_references = False
            reference_level = None
            continue
        if normalized:
            count += 1
    return count


def inspect_docx(path: str | Path) -> dict[str, Any]:
    """Report DOCX completeness for the model; no numeric acceptance thresholds."""
    docx_path = Path(path).expanduser().resolve()
    result: dict[str, Any] = {
        "ok": False,
        "valid": False,
        "path": str(docx_path),
        "parts": 0,
        "paragraphs": 0,
        "tables": 0,
        "images": 0,
        "chinese_characters": 0,
        "english_words": 0,
        "words": 0,
        "headings": 0,
        "heading_levels": {},
        "references": 0,
        "errors": [],
        "warnings": [],
    }

    validation = validate_docx(docx_path)
    result["parts"] = validation.get("parts", 0)
    result["warnings"].extend(validation.get("warnings", []))
    if not validation.get("ok"):
        result["errors"].extend(validation.get("errors", ["DOCX validation failed"]))
        return result
    result["valid"] = True

    try:
        with zipfile.ZipFile(docx_path, "r") as archive:
            names = archive.namelist()
            document = etree.fromstring(archive.read("word/document.xml"))
            paragraphs = document.xpath(".//w:p", namespaces=NS)
            tables = document.xpath(".//w:tbl", namespaces=NS)
            texts = [_paragraph_text(paragraph) for paragraph in paragraphs]
            style_names, style_levels = _style_metadata(archive)
            heading_levels = [
                _paragraph_heading_level(paragraph, style_names, style_levels)
                for paragraph in paragraphs
            ]
            image_names = {
                name
                for name in names
                if name.startswith("word/media/")
                and not name.endswith("/")
                and Path(name).suffix.lower() in IMAGE_EXTENSIONS
            }
    except (KeyError, zipfile.BadZipFile, etree.XMLSyntaxError, OSError) as exc:
        result["errors"].append(f"Unable to inspect DOCX contents: {exc}")
        return result

    full_text = "\n".join(texts)
    chinese_characters = len(re.findall(r"[\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF]", full_text))
    english_words = len(re.findall(r"[A-Za-z]+(?:['’-][A-Za-z]+)*", full_text))
    level_counts = Counter(level for level in heading_levels if level is not None)

    references = _reference_count(texts, heading_levels)
    images = len(image_names)
    result.update(
        {
            "paragraphs": len(paragraphs),
            "tables": len(tables),
            "images": images,
            "chinese_characters": chinese_characters,
            "english_words": english_words,
            "words": chinese_characters + english_words,
            "headings": sum(level_counts.values()),
            "heading_levels": {
                str(level): level_counts[level] for level in sorted(level_counts)
            },
            "references": references,
            "has_references": references > 0,
            "has_images": images > 0,
            "has_headings": sum(level_counts.values()) > 0,
        }
    )

    if references == 0:
        result["warnings"].append(
            "references is 0: check [@key] and refs.autoBibliography()"
        )
        result["delivery_hint"] = "REFERENCES_MISSING"
    else:
        result["delivery_hint"] = "DELIVER"

    result["ok"] = not result["errors"]
    return result


__all__ = ["inspect_docx"]
