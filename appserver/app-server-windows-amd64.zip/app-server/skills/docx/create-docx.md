# 创建 DOCX 文档

**流程**：定设计 → 写 JS → `docx.sh create`；已有 JS 用 `file edit` 定点改后再 `create`。

**必读**：[helpers-api.md](references/helpers-api.md) · [design.md](references/design.md)

`docx-helper` 仅在远程 `create` 可用。

---

## 1. 设计

气质 / 色板 / 字体 / 封面 / A4 见 design.md。

---

## 2. 写 JS

**短文**：一次 `file(action=write, ...)` 写完整脚本。  
**长文（正文 >2000 字，含论文）**：`write` 骨架 + 按章 `append` 完整函数，最后再 `append` `h.build()`。

- 中文写原始字符，勿 `\uXXXX`；避免 emoji / 生僻符号
- 中文正文用中文标点：引号用「」或“”，不要用 ASCII `"` / `'`；英文专名、代码、西文文献条目除外
- `file` 的 `content` 不能为空串（否则 0 字节文件）
- 按区块拆函数（`coverSection` / `chapter1`…），便于定点修复
- 同一文件追加时：`h` / `refs` / `hf` / `COLORS` 只定义一次；每次 append 必须语法闭合（禁止跨次续写字符串或 `return [`）

### 骨架示例

```javascript
const path = require('path');
const h = require(path.join(process.env.SKILL_PATH, 'docx', 'scripts', 'docx-helper'))({
  fonts: { heading: 'Microsoft YaHei', body: 'Microsoft YaHei' },
  colors: { primary: '2B579A', accent: '4A90D9', text: '333333', light: 'F2F6FC' },
});

const C = h.colors;
const hf = h.headerFooter('文档标题');

function coverSection() { return [/* 封面用 h.p，不要 h.h1 */]; }
function tocSection() { return [h.h1('目  录', { align: 'center' }), h.spacer(200), h.toc()]; }
function chapter1() { return [h.h1('第一章 …'), h.h2('1.1 …'), h.p('…')]; }

// 封面 / 目录 / 正文分节；页码：封面无、目录大罗马、正文阿拉伯从 1
h.build({
  sections: [
    { role: 'cover', children: coverSection() },
    { role: 'front', ...hf, children: tocSection() },
    { role: 'body', ...hf, children: [...chapter1()] },
  ],
});
```

补丁（水印、图表、`coverColor` 等）放在 `h.build` 第二参数，详见 helpers-api。论文公式/三线表等也见 helpers-api。

### 长文 append

```javascript
// write：骨架（可暂无 h.build）
const refs = h.refTracker();
function coverSection() { return [...]; }

// append：每次一个完整函数
function chapter1Part1() {
  return [h.h1('第一章 绪论'), h.p('正文[@wang2024]。')];
}

// 最后 append
h.build({
  sections: [
    { role: 'cover', children: coverSection() },
    { role: 'body', ...hf, children: [...chapter1Part1(), h.h1('参考文献'), ...refs.autoBibliography()] },
  ],
});
```

### 图片与资源

`generate_image` 落到工作区根的 `images/`。**JS 也写在工作区根**（不要放到 `js/`、`script/`），路径用 `images/文件名`：

```javascript
h.img('images/chart.png', { width: 480 });
h.coverBg('images/cover.jpg');
```

禁止：`../`、本机绝对路径、函数返回值、动态拼接写进 JS（`..` 会被拒）。HTTP/data/blob 须先下成本地。  
JS 已在子目录时：把图拷到「脚本同级/images/」，或 `--ref "images/xxx.png=本地绝对路径"`（等号左边不要带 `..`）。  
解析失败时给 `create` 加 `--ref "远端=本地"` 或 `--asset-manifest`。路径作带引号的 CLI 参数传入，勿嵌进 `python -c` / here-doc。

---

## 3. 执行

```bash
bash "$SKILL_PATH_BASH/docx/scripts/docx.sh" create "/path/to/script.js" -o "/path/to/output.docx"
```

**必须前台执行**：不要对 `create` 设 `run_in_background=true`。

成功时会打印 `STATS`（字数/引用，零值省略）和 `DELIVER:`。看到即可交付；不要自行解 docx 数字数，不要在成品里搜 `[@key]`。

---

## 4. 修改已有 JS

排错与内容调整**优先局部修改**；**禁止**不加思考的整文件重写，也禁止 `sed`、Python/`open()` 旁路写文件。

1. `file(action=read, ...)` 读报错行或目标附近原文  
2. `file(action=edit, ...)` 用精确 `find` / `replace` 改  
3. 再跑 `docx.sh create`

要点：

- `find` 必须是文件里的精确原文（含缩进）；先 read 再抄  
- 默认只替换首次匹配；`find` 带够上下文（函数名、相邻行），勿轻易 `all: true`  
- 删除：`replace` 为空串；插入：`find` 锚住附近原文，`replace` 写成「原文 + 新增」  
- 未匹配则重读后改 `find`  
- 确需大范围调整时，先想清楚改动边界，再考虑 `write` 重写

```text
file(
  action=edit,
  path=/path/to/script.js,
  edits=[{
    find: "    h.p('原来的段落'),",
    replace: "    h.p('修改后的段落'),"
  }]
)
```

---

## 5. 硬约束

### 禁止

- TypeScript 语法（`as any`、类型标注、`interface` 等）
- `require('docx')` / `new Table()` / `new Paragraph()` 等 — 一律 `h.xxx()`；例外从 `h.raw` 解构
- 用 `h.p()` + `indent` 冒充列表 — 用 `h.bullet()` / `h.numbered()`
- section 之间再加 `h.pageBreak()`（报告封面/目录/正文必须分节，用 `role`，不要分页符凑合）
- 用 `h.p({ bold, size })` 冒充各级标题（导航窗格会空；必须 `h.h1`–`h.h4`）
- 默认给封面加 `coverColor` / `h.coverBg`
- 中文句子里用英文直引号 `"..."` / `'...'`
- 写入 JS 的同一轮里跑 bash；先写完再 `create`
- 先 `creative` 再包装成 JS
- 非 `docx.sh create` 的旁路生成
- 顶层悬空 `h.p()` / `h.img()` / `h.table()` — 必须在函数返回的 children 或 `h.build` 内
- 再封装一层「自动缩进段落函数」— `h.p()` 已吃全局 `indent` / `spacing.body`

### 注意

- `h.numbered()` 默认全文一条编号链；要从 1 重计时传不同 `{ ref: 'xxx' }`
- 同级标题同一 API

### 文体速查

| 文体 | 字体 | 缩进 | 注意 |
|------|------|------|------|
| 公文 | 标题 SimHei，正文 FangSong(32) | `firstLine: 480` | 标题居中；签发/日期右对齐；不要封面 |
| 书信 | KaiTi / FangSong | `firstLine: 480` | 「此致」缩进，「敬礼！」顶格；不要封面 |
| 合同 | SimSun / FangSong | `firstLine: 480` | 条款 `h.numbered()`；签章区留空 |
| 报告/论文 | 标题 SimHei，正文 SimSun | `firstLine: 480` | 摘要 KaiTi；参考文献 `hanging: 480` |
| 新闻/自媒体 | YaHei | 不缩进 | 短段 + 大行距 |
| 小说/散文 | SimSun / YaHei | `firstLine: 480` | 行距 ≥ 400；长文用 append |
| 简历 | YaHei / SimHei | 不缩进 | 表格布局；≤ 两页；不要封面 |

---

## 6. Troubleshooting

| 问题 | 处理 |
|------|------|
| JS 为 0 字节 | `content` 空了；删掉重写。禁止用 Python `open()` 写 JS |
| `UNCLOSED_STRING` / `UNCLOSED_BRACKET` | read 报错上下文 → `file edit` 定点改 → 再 `create` |
| `RESOURCE_ERROR` / 缺图缺文献 | JS 放到工作区根并对准 `images/`；或拷图到脚本旁；或 `--ref`（remote 不要 `..`） |
| 无参考文献 | 正文有 `[@key]` 时文末 `refs.autoBibliography()`；检查 `references.json` |
