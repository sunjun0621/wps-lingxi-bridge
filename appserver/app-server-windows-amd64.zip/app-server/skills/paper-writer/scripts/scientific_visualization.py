"""
科研可视化 — 公式渲染、化学结构、学术图表
中英文论文共享。图表标签语言应与论文语言一致。
"""

import io
import numpy as np
import platform
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm


# ─── 1. 化学结构式（RDKit，可选依赖） ──────────────────────────

def render_molecule(smiles: str, size=(400, 300)):
    """SMILES → PNG 图片。RDKit 不可用时返回 None。"""
    try:
        from rdkit import Chem
        from rdkit.Chem import Draw
    except ImportError:
        return None
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None
    img = Draw.MolToImage(mol, size=size)
    buf = io.BytesIO()
    img.save(buf, format='PNG')
    buf.seek(0)
    return buf


# ─── 2. 字体初始化（中英文通用，必须在所有绑图代码之前调用）───

def _ensure_cjk_font():
    """确保系统有可用的 CJK 字体，没有则自动下载。返回字体名或 None。"""
    available = {f.name for f in fm.fontManager.ttflist}
    system = platform.system()
    cjk_candidates = {
        'Windows': ['Microsoft YaHei', 'SimHei', 'SimSun', 'KaiTi'],
        'Darwin': ['PingFang SC', 'Heiti SC', 'STHeiti', 'Arial Unicode MS'],
        'Linux': ['WenQuanYi Micro Hei', 'Noto Sans CJK SC', 'Noto Sans SC',
                  'Droid Sans Fallback', 'AR PL UMing CN'],
    }.get(system, [])
    found = next((f for f in cjk_candidates if f in available), None)
    if found:
        return found

    import subprocess, os, glob
    font_dir = os.path.join(os.path.expanduser('~'), '.local', 'share', 'fonts')
    os.makedirs(font_dir, exist_ok=True)

    for ttf in glob.glob(os.path.join(font_dir, '*.ttf')) + glob.glob(os.path.join(font_dir, '*.otf')):
        try:
            fm.fontManager.addfont(ttf)
        except Exception:
            pass
    available = {f.name for f in fm.fontManager.ttflist}
    found = next((f for f in cjk_candidates if f in available), None)
    if found:
        return found

    if system == 'Linux':
        try:
            subprocess.run(['apt-get', 'install', '-y', 'fonts-wqy-microhei'],
                           capture_output=True, timeout=120)
            subprocess.run(['fc-cache', '-f'], capture_output=True)
        except Exception:
            pass

        font_url = 'https://github.com/google/fonts/raw/main/ofl/notosanssc/NotoSansSC%5Bwght%5D.ttf'
        dest = os.path.join(font_dir, 'NotoSansSC.ttf')
        if not os.path.exists(dest):
            try:
                import urllib.request
                print(f"[matplotlib] Downloading CJK font to {dest} ...")
                urllib.request.urlretrieve(font_url, dest)
            except Exception as e:
                print(f"[matplotlib] Font download failed: {e}")

        for ttf in glob.glob(os.path.join(font_dir, '*.ttf')) + glob.glob(os.path.join(font_dir, '*.otf')):
            try:
                fm.fontManager.addfont(ttf)
            except Exception:
                pass

        for d in ['/usr/share/fonts', '/usr/local/share/fonts']:
            for root, _, files in os.walk(d):
                for f in files:
                    if f.endswith(('.ttf', '.otf')) and any(k in f.lower() for k in ['cjk', 'wqy', 'noto', 'hei', 'song', 'kai']):
                        try:
                            fm.fontManager.addfont(os.path.join(root, f))
                        except Exception:
                            pass

    available = {f.name for f in fm.fontManager.ttflist}
    all_cjk = cjk_candidates + ['Noto Sans SC', 'Noto Sans CJK SC']
    return next((f for f in all_cjk if f in available), None)


_font_initialized = False
_font_primary = None


def setup_chart_font(paper_lang='auto'):
    """配置 matplotlib 字体，防止□□□。
    paper_lang: 'zh' 中文论文, 'en' 英文论文, 'auto' 自动检测。
    MUST be called before any plotting code.
    """
    global _font_initialized, _font_primary
    if _font_initialized:
        return _font_primary
    system = platform.system()
    sans_map = {
        'Windows': ['Arial', 'Calibri'],
        'Darwin': ['Helvetica Neue', 'Arial'],
        'Linux': ['DejaVu Sans', 'Liberation Sans'],
    }
    serif_candidates = ['Times New Roman', 'DejaVu Serif', 'Liberation Serif']

    chosen_cjk = _ensure_cjk_font()
    available = {f.name for f in fm.fontManager.ttflist}
    sans_list = sans_map.get(system, sans_map['Linux'])
    chosen_sans = next((f for f in sans_list if f in available), 'DejaVu Sans')
    chosen_serif = next((f for f in serif_candidates if f in available), 'DejaVu Serif')

    cjk_list = [chosen_cjk] if chosen_cjk else []
    if paper_lang == 'zh' or (paper_lang == 'auto' and chosen_cjk):
        primary = chosen_cjk or chosen_sans
        fallback = cjk_list + [chosen_sans, 'DejaVu Sans']
    else:
        primary = chosen_sans
        fallback = [chosen_sans] + cjk_list + ['DejaVu Sans']

    matplotlib.rcParams['font.sans-serif'] = [primary] + fallback
    matplotlib.rcParams['font.family'] = 'sans-serif'
    matplotlib.rcParams['font.serif'] = [chosen_serif] + serif_candidates
    matplotlib.rcParams['axes.unicode_minus'] = False
    matplotlib.rcParams['mathtext.fontset'] = 'cm'
    matplotlib.rcParams['mathtext.rm'] = 'serif'

    if chosen_cjk is None and paper_lang in ('zh', 'auto'):
        print("[WARNING] No CJK font found. Chinese text may show as □□□.")
        print("  Fix: pip install matplotlib && apt-get install -y fonts-wqy-microhei")
    print(f"[matplotlib] primary={primary}, serif={chosen_serif}, CJK={chosen_cjk or 'N/A'}")
    _font_initialized = True
    _font_primary = primary
    return primary


# ─── Unicode 上下标 → mathtext 转换 ─────────────────────────────

_SUPER_MAP = {
    '\u207A': '+', '\u207B': '-', '\u2070': '0', '\u00B9': '1',
    '\u00B2': '2', '\u00B3': '3', '\u2074': '4', '\u2075': '5',
    '\u2076': '6', '\u2077': '7', '\u2078': '8', '\u2079': '9',
    '\u207F': 'n', '\u2071': 'i',
}
_SUB_MAP = {
    '\u2080': '0', '\u2081': '1', '\u2082': '2', '\u2083': '3',
    '\u2084': '4', '\u2085': '5', '\u2086': '6', '\u2087': '7',
    '\u2088': '8', '\u2089': '9', '\u2090': 'a', '\u2091': 'e',
    '\u2092': 'o', '\u2093': 'x', '\u2095': 'h', '\u2096': 'k',
    '\u2097': 'l', '\u2098': 'm', '\u2099': 'n', '\u209A': 'p',
    '\u209B': 's', '\u209C': 't',
}
_SUPER_CHARS = set(_SUPER_MAP.keys())
_SUB_CHARS = set(_SUB_MAP.keys())

def _to_mathtext(text):
    """将含 Unicode 上下标的文本转为 matplotlib mathtext 混排格式。
    纯 ASCII 文本原样返回，避免不必要的 mathtext 开销。"""
    if not any(c in _SUPER_CHARS | _SUB_CHARS for c in text):
        return text

    parts = []
    i = 0
    while i < len(text):
        ch = text[i]
        if ch in _SUPER_CHARS:
            run = []
            while i < len(text) and text[i] in _SUPER_CHARS:
                run.append(_SUPER_MAP[text[i]])
                i += 1
            parts.append('$^{' + ''.join(run) + '}$')
        elif ch in _SUB_CHARS:
            run = []
            while i < len(text) and text[i] in _SUB_CHARS:
                run.append(_SUB_MAP[text[i]])
                i += 1
            parts.append('$_{' + ''.join(run) + '}$')
        else:
            parts.append(ch)
            i += 1
    return ''.join(parts)


# ─── 3. 学术配色方案 ────────────────────────────────────────────

SCIENCE_COLORS = {
    'nature': ['#E64B35', '#4DBBD5', '#00A087', '#3C5488', '#F39B7F',
               '#8491B4', '#91D1C2', '#DC0000', '#7E6148', '#B09C85'],
    'science': ['#3B4992', '#EE0000', '#008B45', '#631879', '#008280',
                '#BB0021', '#5F559B', '#A20056', '#808180', '#1B1919'],
    'lancet':  ['#00468B', '#ED0000', '#42B540', '#0099B4', '#925E9F',
                '#FDAF91', '#AD002A', '#ADB6B6'],
    'nejm':    ['#BC3C29', '#0072B5', '#E18727', '#20854E', '#7876B1',
                '#6F99AD', '#FFDC91', '#EE4C97'],
}


def science_style():
    return {
        'figure.dpi': 300, 'figure.figsize': (8, 5),
        'font.size': 12, 'axes.labelsize': 14, 'axes.titlesize': 16,
        'axes.linewidth': 1.2, 'lines.linewidth': 2, 'lines.markersize': 8,
        'xtick.labelsize': 11, 'ytick.labelsize': 11,
        'legend.fontsize': 11, 'legend.framealpha': 0.8, 'grid.alpha': 0.3,
        'savefig.bbox': 'tight', 'savefig.pad_inches': 0.1,
        'svg.fonttype': 'none',
        'axes.spines.top': False, 'axes.spines.right': False,
        'legend.frameon': False,
    }


# ─── 4. 图表模板 ────────────────────────────────────────────────

def _tighten_ylim(ax, margin_ratio=0.1):
    """收紧 Y 轴范围，避免数据集中在窄区间时浪费大量空白。"""
    lo, hi = ax.get_ylim()
    data_range = hi - lo
    if data_range <= 0:
        return
    margin = data_range * margin_ratio
    ax.set_ylim(lo - margin, hi + margin)


def create_bar_chart(categories, values_dict, title='', xlabel='', ylabel='', palette='nature'):
    plt.rcParams.update(science_style())
    colors = SCIENCE_COLORS[palette]
    fig, ax = plt.subplots()
    x = np.arange(len(categories))
    n = len(values_dict)
    width = 0.8 / n
    for i, (label, vals) in enumerate(values_dict.items()):
        ax.bar(x + i * width - 0.4 + width/2, vals, width,
               label=label, color=colors[i], edgecolor='white', linewidth=0.5)
    ax.set_xlabel(xlabel); ax.set_ylabel(ylabel)
    ax.set_xticks(x); ax.set_xticklabels(categories)
    ax.legend()
    fig.tight_layout()
    return fig


def create_line_chart(x_data, lines_dict, title='', xlabel='', ylabel='',
                      palette='nature', markers=True):
    """折线图。

    Args:
        x_data: x 轴数据（列表）
        lines_dict: {'系列名': [y 值], ...}
        markers: 是否显示数据点标记
    """
    plt.rcParams.update(science_style())
    colors = SCIENCE_COLORS[palette]
    marker_list = ['o', 's', '^', 'D', 'v', 'P', 'X', 'h']
    fig, ax = plt.subplots()
    for i, (label, vals) in enumerate(lines_dict.items()):
        mk = marker_list[i % len(marker_list)] if markers else None
        ax.plot(x_data, vals, label=label, color=colors[i % len(colors)],
                marker=mk, markerfacecolor='white', markeredgewidth=1.5)
    ax.set_xlabel(xlabel); ax.set_ylabel(ylabel)
    ax.legend()
    ax.grid(True, alpha=0.3, linestyle='--')
    _tighten_ylim(ax)
    fig.tight_layout()
    return fig


def create_scatter_chart(datasets, title='', xlabel='', ylabel='',
                         palette='nature', trendline=False):
    """散点图。

    Args:
        datasets: {'系列名': {'x': [...], 'y': [...]}, ...}
        trendline: 是否绘制线性趋势线
    """
    plt.rcParams.update(science_style())
    colors = SCIENCE_COLORS[palette]
    marker_list = ['o', 's', '^', 'D', 'v', 'P']
    fig, ax = plt.subplots()
    for i, (label, data) in enumerate(datasets.items()):
        c = colors[i % len(colors)]
        mk = marker_list[i % len(marker_list)]
        ax.scatter(data['x'], data['y'], label=label, color=c, marker=mk,
                   edgecolors='white', linewidths=0.5, s=60, alpha=0.8)
        if trendline:
            x_arr = np.array(data['x'], dtype=float)
            y_arr = np.array(data['y'], dtype=float)
            if len(x_arr) >= 2:
                z = np.polyfit(x_arr, y_arr, 1)
                p = np.poly1d(z)
                x_line = np.linspace(x_arr.min(), x_arr.max(), 100)
                ax.plot(x_line, p(x_line), color=c, linestyle='--', linewidth=1.2, alpha=0.6)
    ax.set_xlabel(xlabel); ax.set_ylabel(ylabel)
    ax.legend()
    fig.tight_layout()
    return fig


def create_pie_chart(labels, values, title='', palette='nature', donut=False):
    """饼图 / 环形图。

    Args:
        labels: 类别标签列表
        values: 对应数值列表
        donut: True 时绘制环形图
    """
    plt.rcParams.update(science_style())
    colors = SCIENCE_COLORS[palette]
    fig, ax = plt.subplots()
    wedgeprops = {'edgecolor': 'white', 'linewidth': 1.5}
    if donut:
        wedgeprops['width'] = 0.4
    wedges, texts, autotexts = ax.pie(
        values, labels=labels, colors=colors[:len(labels)],
        autopct='%1.1f%%', pctdistance=0.75 if donut else 0.6,
        wedgeprops=wedgeprops, startangle=90)
    for t in autotexts:
        t.set_fontsize(10)
        t.set_fontweight('bold')
    ax.set_aspect('equal')
    fig.tight_layout()
    return fig


def create_radar_chart(categories, series_dict, title='', palette='nature'):
    """雷达图。

    Args:
        categories: 维度名列表
        series_dict: {'系列名': [各维度值], ...}
    """
    plt.rcParams.update(science_style())
    colors = SCIENCE_COLORS[palette]
    n = len(categories)
    angles = np.linspace(0, 2 * np.pi, n, endpoint=False).tolist()
    angles += angles[:1]

    fig, ax = plt.subplots(subplot_kw={'polar': True})
    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)
    ax.set_thetagrids(np.degrees(angles[:-1]), categories)

    for i, (label, vals) in enumerate(series_dict.items()):
        data = vals + vals[:1]
        c = colors[i % len(colors)]
        ax.plot(angles, data, 'o-', label=label, color=c, linewidth=2, markersize=6)
        ax.fill(angles, data, alpha=0.15, color=c)

    ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1),
              frameon=True, fancybox=True, shadow=True)
    fig.tight_layout()
    return fig


def create_heatmap(data, row_labels, col_labels, title='', palette='nature',
                   annotate=True, cmap='YlOrRd'):
    """热力图。

    Args:
        data: 2D 列表或 numpy 数组
        row_labels: 行标签
        col_labels: 列标签
        annotate: 是否在格内显示数值
        cmap: matplotlib colormap 名称
    """
    plt.rcParams.update(science_style())
    data = np.array(data, dtype=float)
    fig, ax = plt.subplots()
    im = ax.imshow(data, cmap=cmap, aspect='auto')
    fig.colorbar(im, ax=ax, shrink=0.8)

    ax.set_xticks(np.arange(len(col_labels)))
    ax.set_yticks(np.arange(len(row_labels)))
    ax.set_xticklabels(col_labels)
    ax.set_yticklabels(row_labels)
    plt.setp(ax.get_xticklabels(), rotation=45, ha='right')

    if annotate:
        for i in range(len(row_labels)):
            for j in range(len(col_labels)):
                val = data[i, j]
                threshold = (data.max() + data.min()) / 2
                color = 'white' if val > threshold else 'black'
                ax.text(j, i, f'{val:.2g}', ha='center', va='center',
                        color=color, fontsize=9)
    fig.tight_layout()
    return fig

