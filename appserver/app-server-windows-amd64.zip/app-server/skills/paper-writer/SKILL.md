---
name: paper-writer
description: "撰写中英文学术论文的技能，支持docx文档导出。支持毕业论文、课程论文、开题报告、文献综述、文献精读、选题报告、thesis、journal article、conference paper、research proposal 等学术文体。覆盖完整流程：学术文献检索 → 分章节写作 → 科研图表 → DOCX 排版与导出。"
---

# 学术论文写作

端到端论文写作流程。支持中文学术论文（GB/T 7714 引用）和英文学术论文（APA/IEEE/Chicago 等引用）。本技能按 docx-helper API 编写 JS 脚本，并通过 `docx.sh create` 生成文档。下文提到的 `multi_round_search`、`search_and_save` 等均为**技能脚本目录中的函数**，在 `python_cell_exec` 中 import 后调用，不是需要单独具备的外部工具。

## 重要规则
1. 读取参考文件完整读取，不要截断；保留最后的 JS 文件

---

## 执行流程

按顺序执行，每步完成后再进入下一步。

开始前一次性读取对应语言的参考文档和 DOCX API 参考：

- **[中文]** [chinese-paper-reference.md](references/chinese-paper-reference.md) + [docx-api.md](references/docx-api.md)
- **[EN]** [international-paper-reference.md](references/international-paper-reference.md) + [docx-api.md](references/docx-api.md)

### 步骤 1：文献检索

导入 `academic_search` 模块，调用 `await ac.multi_round_search()` 一次完成全部检索（导入和调用代码见参考文档"检索代码模板"），**必须传 `refs_json` 参数落盘**。中文论文**必须传 `zh_ratio`**（从参考文档字数表查值），不足时自动追加中文检索。

检索预算、代码模板、数据源选择见参考文档"文献检索"章节。

写作中引用不足时，调用 `await ac.search_and_save()` 补检索（传相同 `refs_json` 追加）。只引用学术来源，禁止 CSDN/知乎/百度百科等非学术网页。

**此步骤不可跳过**。`refs_json` 强制规则见参考文档「文献检索」；搜索不理想时调整关键词/数据源，勿手写覆盖。

### 步骤 2：写作规划

1. **确定文体**：根据用户描述匹配（提到"毕业"→学位论文，"课程/作业"→课程论文，"开题"→开题报告……），无法判断时询问用户
2. **章节结构以参考文档为准**：从参考文档查该文体的章节模板和各章字数分配，严格按此结构写作

### 步骤 3：分章节写作与 DOCX 排版

按已读的 docx-api 写 JS，逐章写入；文风与引用规范见参考文档。

写作规则：
- **按章节分批写入**：`write` 骨架 + 按章 `append` 完整函数；`h` / `refs` 只定义一次，`h.build()` 只在最后一次 append；禁止章节函数闭合后再裸追加 `h.p()`；中文写原始字符，勿 `\uXXXX`
- **段落 ≥ 250 字**（英文 ≥ 180 words）；写作前规划好每章篇幅，一次写到位
- **引用**：综述章每主题段建议 ≥ 3 篇；文末 `refs.autoBibliography()`（无参）；其余见参考文档
- **图表**：数据图用 `scientific_visualization`（300dpi PNG）；流程图/框架图用 `generate_image`。API 见 docx-api 第七节

### 步骤 4：修改已有 JS / 排错

`create` 报错或需改已写章节时，**优先局部修改**；**禁止**不加思考的整文件重写，也禁止 `sed`、Python/`open()` 旁路写文件。

1. `file(action=read, ...)` 读报错行或目标附近原文  
2. `file(action=edit, ...)` 精确 `find` / `replace`  
3. 再跑 `docx.sh create`

- `find` 必须是文件里的精确原文（含缩进）；先 read 再抄  
- 默认只替换首次匹配；`find` 带够上下文（函数名、相邻行），勿轻易 `all: true`  
- 删除：`replace` 为空串；插入：锚住附近原文，`replace` 写成「原文 + 新增」  
- 确需大范围调整时，先想清楚改动边界，再考虑 `write` 重写；写完再 `create`

```text
file(
  action=edit,
  path=/path/to/paper.js,
  edits=[{
    find: "    h.p('原来的段落'),",
    replace: "    h.p('修改后的段落'),"
  }]
)
```

### 步骤 5：产物交付

```bash
bash "$SKILL_PATH_BASH/docx/scripts/docx.sh" create "output/paper.js" -o "output/paper.docx"
```

`docx.sh create` **必须前台执行**（不要 `run_in_background=true`）。成功看 `STATS` / `DELIVER` 即交付；不要自行解 docx 或搜 `[@key]` 验收。
